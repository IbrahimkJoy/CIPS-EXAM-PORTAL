# CIPS Exam Portal LMS & Admin Console - Master Documentation

Welcome to the **Chartered Institute of Procurement & Supply (CIPS) Exam Portal LMS**. This platform is a full-stack web application providing a proctored learning and examination environment for students, alongside an Admin Console for access control, content management, security monitoring, and Google integrations.

---

## 📁 File Organization & Sorting Guide

All files in this project are organized logically by responsibility. Here is how the workspace files are structured and sorted into functional categories:

```
├── 📄 server.ts                    # Main Express backend server entry point (Port 3000)
├── 📂 shared-backend/              # Persistent Database Engine & Data Files
│   ├── db.js                       # Database helper module (CRUD, auth, device locking, audit logging)
│   └── data.json                   # File-backed JSON database store (Auto-created if missing)
│
├── 📂 Student Portal (UI & Logic)
│   ├── student-login.html          # Student Authentication & Device Lock Login Page
│   ├── student-login.css           # Styling for student login interface
│   ├── student-auth.js             # Client authentication & device fingerprinting logic
│   ├── dashboard.html              # CIPS Qualifications Dashboard (Levels 2-6)
│   ├── dashboard.css               # Dashboard grid & lock overlay styles
│   ├── access-control.js           # Student permission verification & level/module lock handler
│   ├── module-content.html         # Study Materials & Video Lecture Viewer
│   ├── module-content.css          # Content viewer layout & anti-copy watermark styles
│   ├── content-protection.js       # Security engine (disables right-click, F12, print, lost-focus blur)
│   ├── quiz-login.html             # Proctored Exam Authorization Login Gate
│   ├── quiz-login.js               # Exam password verification & attempt counter logic
│   ├── quiz.html                   # Exam Engine Interface (MCQ Objective & Long-form CR)
│   ├── quiz.css                    # Quiz timer, question palette & option styles
│   └── quiz-engine.js              # Timer countdown, auto-submit, & question renderer
│
├── 📂 Admin Console (UI & Logic)
│   ├── admin-login.html            # Admin Portal Login Page (Enforces initial password change)
│   ├── admin-login.css             # Admin login dark theme styling
│   ├── admin-auth.js               # Admin authentication handler
│   ├── student-management.html     # Student Access & Device Lock Management
│   ├── student-management.css      # Admin panel layout & accordion styles
│   ├── access-control-admin.js     # Student account creator & CIPS permission matrix manager
│   ├── content-manager.html        # Module Materials & CSV Quiz Bank Importer
│   ├── quiz-importer.js            # CSV parser for Google Sheets exports & Drive video selector
│   ├── quiz-password-manager.html  # Quiz Passcode & Student Attempt Limits Manager
│   ├── monitoring-dashboard.html   # Real-Time Security Alerts & Exam Results Audit
│   ├── monitoring-dashboard.css    # Security alert cards & audit feed styles
│   ├── alerts.js                   # Live alert feed & active session revocation logic
│   ├── reports-export.js           # Exam submission score renderer & CSV export trigger
│   └── integrations-settings.html  # Google Sheets & Google Drive config panel
│
├── 📂 Shared Assets & Data Sets
│   ├── shared-styles.css           # Global CIPS corporate design tokens, fonts, & modal overlays
│   ├── api-config.js               # Centralized REST API client & fetch wrappers
│   └── modules-data.json           # Default CIPS syllabus dataset (Levels 2–6 modules & topics)
│
├── 📂 Configuration & Project Files
│   ├── package.json                # Project dependencies and script definitions
│   ├── tsconfig.json               # TypeScript compiler configuration
│   ├── vite.config.ts              # Vite bundle configuration
│   ├── metadata.json               # Platform metadata & title settings
│   ├── .env.example                # Template for environment variables (Google Service Account, secrets)
│   └── README.md                   # Complete system documentation (This file)
```

---

## 🛠️ Requirements & Installation

To run the application and the database backend on your machine or server, you need Node.js installed.

### 1. Prerequisites
- **Node.js**: Version `18.x` or higher
- **npm**: Version `9.x` or higher (or `bun` / `yarn`)

### 2. Installing Dependencies
Run the following command in the project root directory:

```bash
npm install
```

#### Dependencies Installed:
- **`express`**: Fast HTTP backend server for REST API endpoints
- **`bcryptjs`**: Password hashing for secure admin authentication
- **`dotenv`**: Environment variable loader
- **`tsx`**: TypeScript execute CLI for running `server.ts` seamlessly
- **`lucide-react`**, **`motion`**, **`react`**, **`react-dom`**: Frontend utilities & icons

---

## 🗄️ Database Setup & Architecture

### **Built-in Persistent Database Engine**
The database for this application is **fully included and self-contained**. No external SQL server (PostgreSQL, MySQL) or NoSQL database server (MongoDB) installation is required!

- **Database File Location**: `shared-backend/data.json`
- **Database Logic Module**: `shared-backend/db.js`
- **How It Works**: On server startup, `shared-backend/db.js` automatically creates `shared-backend/data.json` if it does not exist, initializing default collections for:
  - Admin credentials
  - Student user records & approved level/module permission matrices
  - Active device fingerprints and conflict lock events
  - Quiz authorization passcodes and student attempt limits
  - Security alerts (DevTools detections, screenshot attempts, lost-focus events)
  - Custom study materials & CSV quiz question banks
  - Google Sheets & Drive integration configurations

Data updates are saved to `shared-backend/data.json` synchronously on every API write request, ensuring full persistence across server restarts.

---

## 🚀 Running the Application

To start the full-stack server (handling both API endpoints and serving the web portal):

```bash
npm run dev
```
*(or `npm start`)*

The server will launch on port **`3000`**:
```
Server running on http://0.0.0.0:3000
```

Access the portal in your web browser at:
- **Student Portal**: `http://localhost:3000/student-login.html`
- **Admin Console**: `http://localhost:3000/admin-login.html`

---

## 🔑 Initial Admin Credentials

When accessing the Admin Console for the first time:

- **Login URL**: `http://localhost:3000/admin-login.html`
- **Default Username**: `admincipsadmin`
- **Default Password**: `admin@cips@11089`

> **Note**: Upon logging in with default credentials, the system will prompt you to immediately set a new, secure custom admin password.

---

## 🌟 Key Functional Features

### 👤 Student Portal
1. **Single-Device Lock**: Students log in using their Student UserID and Email. The device fingerprint (Browser + OS + Device Token) is registered. Secondary device logins are blocked with the notice: *"This account is already active on another device. Contact your administrator."*
2. **Interactive Qualifications Dashboard**: Displays CIPS Levels 2 through 6. Unauthorized levels are locked behind paywall notices. Approved modules display study progress and exam entry buttons.
3. **Protected Study Materials**: In-browser document viewer and embedded lecture video player with anti-copy protection (disables right-click, F12 inspect element, print screen, and renders dynamic student email watermarks).
4. **Proctored Quiz Engine**: Separate quiz passcode gate. Timed exam environment supporting Objective Response (60 MCQs) and Constructive Response (Case Studies) with automatic submission.

### 🛡️ Admin Console
1. **Student Management & Access Matrix**: Create student accounts, customize individual level/module approvals, and clear active device locks.
2. **Content Manager & CSV Quiz Importer**: Upload study guides, link lecture recordings, and bulk-import quiz question banks directly from Google Sheets CSV exports.
3. **Quiz Passwords & Attempt Limits**: Set module authorization keys and grant custom attempt extensions to specific students beyond the default 3-attempt cap.
4. **Monitoring & Security Feed**: Real-time security alert stream tracking DevTools inspection attempts, screenshot key presses, and unauthorized device logins. Includes a one-click **Revoke Session** button.
5. **Google Integrations**: Configure Google Sheet IDs for real-time exam score mirroring and Google Drive Folder IDs for lecture video libraries.

---

## ⚙️ Google Integrations Setup (Optional)

To enable automatic Google Sheet row appending and Google Drive file fetching:

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Paste your Google Service Account JSON in `.env`:
   ```env
   GOOGLE_SERVICE_ACCOUNT={"type":"service_account","project_id":"...","private_key":"..."}
   ```
3. Open the Admin Console under **⚙️ Google Integrations** and set your target Google Sheet ID and Google Drive Folder ID.
