/**
 * Searchable Country Code Dropdown Component
 * Features ISO 3166-1 alpha-2 flags, real-time live search, keyboard navigation,
 * and dark/light theme support.
 */

(function(global) {
  'use strict';

  class SearchableCountryDropdown {
    constructor(containerElement, options = {}) {
      if (!containerElement) {
        throw new Error('Container element is required for SearchableCountryDropdown');
      }

      this.container = containerElement;
      this.options = Object.assign({
        defaultCode: 'AE', // Default to UAE
        name: 'countryCode',
        id: 'regCountryCode',
        onChange: null
      }, options);

      this.isOpen = false;
      this.countries = (global.CIPS_COUNTRIES && global.CIPS_COUNTRIES.getAll()) || [];
      this.filteredCountries = [...this.countries];
      this.selectedCountry = (global.CIPS_COUNTRIES && global.CIPS_COUNTRIES.getByCode(this.options.defaultCode)) || this.countries[0] || {
        code: 'AE',
        name: 'United Arab Emirates',
        dialCode: '+971',
        flag: '🇦🇪'
      };
      this.highlightedIndex = 0;

      this.init();
    }

    init() {
      this.container.classList.add('country-dropdown-root');
      this.render();
      this.bindEvents();
    }

    render() {
      this.container.innerHTML = `
        <div class="c-dropdown-wrapper">
          <!-- Hidden Native Input for standard form compatibility -->
          <input type="hidden" id="${this.options.id}" name="${this.options.name}" value="${this.selectedCountry.dialCode}" data-country-code="${this.selectedCountry.code}" data-country-name="${this.selectedCountry.name}">
          
          <!-- Trigger Button -->
          <button type="button" class="c-dropdown-trigger" id="${this.options.id}-trigger" aria-haspopup="listbox" aria-expanded="false" title="Select Country Code">
            <span class="c-trigger-flag">${this.selectedCountry.flag}</span>
            <span class="c-trigger-dial">${this.selectedCountry.dialCode}</span>
            <span class="c-trigger-iso">${this.selectedCountry.code}</span>
            <svg class="c-trigger-arrow" viewBox="0 0 20 20" fill="currentColor" width="16" height="16">
              <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
            </svg>
          </button>

          <!-- Dropdown Popup Panel -->
          <div class="c-dropdown-panel" id="${this.options.id}-panel" role="listbox" style="display: none;">
            
            <!-- Sticky Search Header -->
            <div class="c-dropdown-search-wrap">
              <span class="c-search-icon">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="11" cy="11" r="8"/>
                  <path d="m21 21-4.3-4.3"/>
                </svg>
              </span>
              <input 
                type="text" 
                class="c-dropdown-search-input" 
                placeholder="Search country, code (+44), or ISO..." 
                autocomplete="off" 
                spellcheck="false"
                aria-label="Search Country"
              />
              <button type="button" class="c-search-clear" style="display: none;" title="Clear search">&times;</button>
            </div>

            <!-- Country List Results -->
            <div class="c-dropdown-list" id="${this.options.id}-list" tabindex="-1">
              <!-- Rendered dynamically -->
            </div>
            
            <div class="c-dropdown-footer">
              <span>Showing ${this.countries.length} ISO 3166-1 countries</span>
            </div>
          </div>
        </div>
      `;

      this.hiddenInput = this.container.querySelector(`#${this.options.id}`);
      this.triggerBtn = this.container.querySelector('.c-dropdown-trigger');
      this.panel = this.container.querySelector('.c-dropdown-panel');
      this.searchInput = this.container.querySelector('.c-dropdown-search-input');
      this.clearBtn = this.container.querySelector('.c-search-clear');
      this.listContainer = this.container.querySelector('.c-dropdown-list');

      this.renderList();
    }

    renderList() {
      if (!this.listContainer) return;

      if (this.filteredCountries.length === 0) {
        this.listContainer.innerHTML = `
          <div class="c-dropdown-empty">
            <div style="font-size: 1.5rem; margin-bottom: 0.25rem;">🔍</div>
            <div>No matching countries found</div>
            <div style="font-size: 0.75rem; color: var(--text-subtle, #94a3b8); margin-top: 0.2rem;">Try searching by country name or dial code</div>
          </div>
        `;
        return;
      }

      const isSearchActive = this.searchInput && this.searchInput.value.trim().length > 0;
      let html = '';

      // If not searching, show Popular/Suggested header first
      if (!isSearchActive && global.CIPS_COUNTRIES) {
        const popular = global.CIPS_COUNTRIES.getPopular();
        if (popular.length > 0) {
          html += `<div class="c-list-section-header">Popular for CIPS Enrollees</div>`;
          popular.forEach(c => {
            const isSelected = c.code === this.selectedCountry.code;
            html += this.buildItemHtml(c, isSelected, 'pop_');
          });
          html += `<div class="c-list-section-header">All Countries &amp; Territories (A-Z)</div>`;
        }
      }

      this.filteredCountries.forEach((c, index) => {
        const isSelected = c.code === this.selectedCountry.code;
        html += this.buildItemHtml(c, isSelected, 'all_', index);
      });

      this.listContainer.innerHTML = html;

      // Ensure highlighted item is visible
      this.updateHighlight();
    }

    buildItemHtml(country, isSelected, prefix = '', index = 0) {
      return `
        <div 
          class="c-dropdown-item ${isSelected ? 'selected' : ''}" 
          data-code="${country.code}" 
          data-dial="${country.dialCode}"
          role="option" 
          aria-selected="${isSelected ? 'true' : 'false'}"
          id="${this.options.id}-opt-${prefix}${country.code}"
        >
          <span class="c-item-flag">${country.flag}</span>
          <span class="c-item-name">${escapeHtml(country.name)}</span>
          <span class="c-item-badges">
            <span class="c-item-dial">${country.dialCode}</span>
            <span class="c-item-iso">${country.code}</span>
          </span>
          ${isSelected ? `<span class="c-item-check">✓</span>` : ''}
        </div>
      `;
    }

    bindEvents() {
      // Toggle dropdown
      this.triggerBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.toggle();
      });

      // Search input typing
      this.searchInput.addEventListener('input', () => {
        const query = this.searchInput.value;
        this.clearBtn.style.display = query.length > 0 ? 'block' : 'none';
        this.filter(query);
      });

      // Clear search button
      this.clearBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.searchInput.value = '';
        this.clearBtn.style.display = 'none';
        this.filter('');
        this.searchInput.focus();
      });

      // Click on country item in list
      this.listContainer.addEventListener('click', (e) => {
        const item = e.target.closest('.c-dropdown-item');
        if (item) {
          const code = item.getAttribute('data-code');
          this.selectByCode(code);
          this.close();
        }
      });

      // Close when clicking outside
      document.addEventListener('click', (e) => {
        if (this.isOpen && !this.container.contains(e.target)) {
          this.close();
        }
      });

      // Keyboard navigation
      this.container.addEventListener('keydown', (e) => {
        if (!this.isOpen) {
          if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
            e.preventDefault();
            this.open();
          }
          return;
        }

        const items = this.listContainer.querySelectorAll('.c-dropdown-item');
        if (items.length === 0) return;

        if (e.key === 'ArrowDown') {
          e.preventDefault();
          this.highlightedIndex = (this.highlightedIndex + 1) % items.length;
          this.updateHighlight();
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          this.highlightedIndex = (this.highlightedIndex - 1 + items.length) % items.length;
          this.updateHighlight();
        } else if (e.key === 'Enter') {
          e.preventDefault();
          if (items[this.highlightedIndex]) {
            const code = items[this.highlightedIndex].getAttribute('data-code');
            this.selectByCode(code);
            this.close();
          }
        } else if (e.key === 'Escape') {
          e.preventDefault();
          this.close();
          this.triggerBtn.focus();
        }
      });
    }

    updateHighlight() {
      const items = this.listContainer.querySelectorAll('.c-dropdown-item');
      items.forEach((it, idx) => {
        if (idx === this.highlightedIndex) {
          it.classList.add('highlighted');
          it.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
        } else {
          it.classList.remove('highlighted');
        }
      });
    }

    filter(query) {
      if (!query || !query.trim()) {
        this.filteredCountries = [...this.countries];
      } else {
        this.filteredCountries = (global.CIPS_COUNTRIES && global.CIPS_COUNTRIES.search(query)) || [];
      }
      this.highlightedIndex = 0;
      this.renderList();
    }

    selectByCode(countryCode) {
      const found = (global.CIPS_COUNTRIES && global.CIPS_COUNTRIES.getByCode(countryCode)) || 
                    this.countries.find(c => c.code === countryCode);
      if (!found) return;

      this.selectedCountry = found;

      // Update hidden input
      this.hiddenInput.value = found.dialCode;
      this.hiddenInput.setAttribute('data-country-code', found.code);
      this.hiddenInput.setAttribute('data-country-name', found.name);

      // Update trigger button UI
      this.triggerBtn.querySelector('.c-trigger-flag').textContent = found.flag;
      this.triggerBtn.querySelector('.c-trigger-dial').textContent = found.dialCode;
      this.triggerBtn.querySelector('.c-trigger-iso').textContent = found.code;

      // Dispatch change event on hidden input for form listeners
      const event = new CustomEvent('change', { bubbles: true });
      this.hiddenInput.dispatchEvent(event);

      if (typeof this.options.onChange === 'function') {
        this.options.onChange(found);
      }
    }

    selectByDialCode(dialCode) {
      const found = (global.CIPS_COUNTRIES && global.CIPS_COUNTRIES.getByDialCode(dialCode)) || 
                    this.countries.find(c => c.dialCode === dialCode);
      if (found) {
        this.selectByCode(found.code);
      }
    }

    toggle() {
      if (this.isOpen) {
        this.close();
      } else {
        this.open();
      }
    }

    open() {
      if (this.isOpen) return;
      this.isOpen = true;
      this.panel.style.display = 'flex';
      this.triggerBtn.setAttribute('aria-expanded', 'true');
      this.triggerBtn.classList.add('active');

      // Reset search on open
      this.searchInput.value = '';
      this.clearBtn.style.display = 'none';
      this.filteredCountries = [...this.countries];
      this.renderList();

      // Scroll to currently selected item
      setTimeout(() => {
        this.searchInput.focus();
        const selectedItem = this.listContainer.querySelector('.c-dropdown-item.selected');
        if (selectedItem) {
          selectedItem.scrollIntoView({ block: 'center' });
        }
      }, 50);
    }

    close() {
      if (!this.isOpen) return;
      this.isOpen = false;
      this.panel.style.display = 'none';
      this.triggerBtn.setAttribute('aria-expanded', 'false');
      this.triggerBtn.classList.remove('active');
    }

    getValue() {
      return this.selectedCountry.dialCode;
    }

    getSelectedCountry() {
      return this.selectedCountry;
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  global.SearchableCountryDropdown = SearchableCountryDropdown;
})(typeof window !== 'undefined' ? window : globalThis);
