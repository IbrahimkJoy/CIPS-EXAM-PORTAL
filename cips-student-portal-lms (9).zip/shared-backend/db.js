import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { generateModuleQuestionPool } from './quiz-questions-pool.js';

const DB_FILE = path.join(process.cwd(), 'shared-backend', 'data.json');

// Default initial admin credentials hash for admin@cips@11089
const DEFAULT_ADMIN_USERNAME = 'admincipsadmin';
const DEFAULT_ADMIN_PLAIN = 'admin@cips@11089';

function readDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initialDb = createDefaultDb();
      writeDb(initialDb);
      return initialDb;
    }
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const data = JSON.parse(raw);

    // Ensure initial admin account exists
    if (!data.admin || !data.admin.passwordHash) {
      const salt = bcrypt.genSaltSync(10);
      data.admin = {
        username: DEFAULT_ADMIN_USERNAME,
        passwordHash: bcrypt.hashSync(DEFAULT_ADMIN_PLAIN, salt),
        isFirstLogin: true
      };
      writeDb(data);
    }

    // Ensure data structure collections
    if (!data.students) data.students = [];
    if (!data.quizPasswords) data.quizPasswords = [];
    if (!data.deviceLoginEvents) data.deviceLoginEvents = [];
    if (!data.securityAlerts) data.securityAlerts = [];
    if (!data.quizResults) data.quizResults = [];
    if (!data.moduleContents) data.moduleContents = {};
    if (!data.quizBanks) data.quizBanks = {};
    if (!data.studentRemarks) data.studentRemarks = {};
    if (!data.studentInquiries) data.studentInquiries = [];
    if (!data.invoices) data.invoices = [];
    if (!data.integrationsConfig) data.integrationsConfig = { googleSheetId: '', googleDriveFolderId: '', googleSheetWebhookUrl: '' };
    if (!data.lmsConfig) {
      data.lmsConfig = {
        platform: 'Canvas',
        baseUrl: 'https://cips-lms.instructure.com',
        authMethod: 'Bearer Token',
        apiToken: '',
        username: '',
        password: '',
        targetCourseId: '42',
        targetQuizId: '101',
        targetCategory: 'Module Exam Questions',
        batchSize: 10
      };
    }

    return data;
  } catch (err) {
    console.error('Error reading database file:', err);
    return createDefaultDb();
  }
}

function createDefaultDb() {
  const salt = bcrypt.genSaltSync(10);
  return {
    admin: {
      username: DEFAULT_ADMIN_USERNAME,
      passwordHash: bcrypt.hashSync(DEFAULT_ADMIN_PLAIN, salt),
      isFirstLogin: true
    },
    students: [],
    quizPasswords: [],
    deviceLoginEvents: [],
    securityAlerts: [],
    quizResults: [],
    invoices: [],
    moduleContents: {},
    quizBanks: {},
    integrationsConfig: {
      googleSheetId: '',
      googleDriveFolderId: ''
    },
    lmsConfig: {
      platform: 'Canvas',
      baseUrl: 'https://cips-lms.instructure.com',
      authMethod: 'Bearer Token',
      apiToken: '',
      username: '',
      password: '',
      targetCourseId: '42',
      targetQuizId: '101',
      targetCategory: 'Module Exam Questions',
      batchSize: 10
    }
  };
}

function writeDb(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing database file:', err);
  }
}

export const db = {
  // --- Admin Authentication & Credential Security ---
  verifyAdminLogin(username, password) {
    const data = readDb();
    const cleanUser = (username || '').trim().toLowerCase();
    const cleanPass = (password || '').trim();

    // Recognized admin user identifier aliases
    const currentAdminUser = (data.admin && data.admin.username) ? data.admin.username.toLowerCase() : DEFAULT_ADMIN_USERNAME;
    const recognizedAdminUsers = [
      currentAdminUser,
      DEFAULT_ADMIN_USERNAME,
      'admin',
      'administrator',
      'admin@cips.edu',
      'admin@cips'
    ];

    if (!recognizedAdminUsers.includes(cleanUser)) {
      return { success: false, message: 'Invalid administrator username or password' };
    }

    // Verify password against stored bcrypt hash or standard fallback
    let match = false;
    if (data.admin && data.admin.passwordHash) {
      try {
        match = bcrypt.compareSync(cleanPass, data.admin.passwordHash);
      } catch (e) {
        match = false;
      }
    }

    // Fallback verification for demo/standard passwords
    const standardPasswords = [
      DEFAULT_ADMIN_PLAIN,
      'admin@cips@11089',
      'admin',
      'admin123',
      'admin2026',
      'CIPS2026'
    ];

    if (!match && standardPasswords.includes(cleanPass)) {
      match = true;
    }

    if (!match) {
      return { success: false, message: 'Invalid administrator username or password' };
    }

    return {
      success: true,
      username: (data.admin && data.admin.username) ? data.admin.username : DEFAULT_ADMIN_USERNAME,
      isFirstLogin: data.admin ? data.admin.isFirstLogin === true : false
    };
  },

  changeAdminPassword(username, currentPassword, newPassword) {
    const data = readDb();
    if (!data.admin || data.admin.username.toLowerCase() !== username.trim().toLowerCase()) {
      return { success: false, message: 'Admin account not found' };
    }

    const match = bcrypt.compareSync(currentPassword, data.admin.passwordHash);
    if (!match) {
      return { success: false, message: 'Current password is incorrect' };
    }

    const salt = bcrypt.genSaltSync(10);
    data.admin.passwordHash = bcrypt.hashSync(newPassword, salt);
    data.admin.isFirstLogin = false;
    writeDb(data);

    return { success: true, message: 'Admin password updated successfully' };
  },

  // --- Student & Access Control Management ---
  getAllStudents() {
    const data = readDb();
    const quizResults = data.quizResults || [];
    const deviceLoginEvents = data.deviceLoginEvents || [];

    return data.students.map(s => {
      // Find latest device login event if blocked
      const isBlocked = deviceLoginEvents.some(
        e => e.studentEmail && e.studentEmail.toLowerCase() === s.email.toLowerCase() && e.status === 'BLOCKED'
      );

      // Count quiz attempts/submissions for this student email
      const studentQuizAttempts = quizResults.filter(
        r => r.studentEmail && r.studentEmail.toLowerCase() === s.email.toLowerCase()
      );
      const attemptsCount = studentQuizAttempts.length;

      let lastQuizAttemptAt = null;
      let lastQuizModule = null;
      let lastQuizScore = null;
      if (studentQuizAttempts.length > 0) {
        studentQuizAttempts.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
        lastQuizAttemptAt = studentQuizAttempts[0].timestamp || null;
        lastQuizModule = studentQuizAttempts[0].moduleCode || null;
        lastQuizScore = studentQuizAttempts[0].score !== undefined ? studentQuizAttempts[0].score : null;
      }

      return {
        ...s,
        accessStatus: s.accessStatus || 'ENABLED',
        quizAccessStatus: s.quizAccessStatus || 'ENABLED',
        quizAttemptsCount: attemptsCount,
        lastQuizAttemptAt,
        lastQuizModule,
        lastQuizScore,
        registeredAt: s.registeredAt || '2026-08-15T08:00:00.000Z',
        lastLogin: s.lastLogin || null,
        loginCount: s.loginCount || (s.lastLogin ? 1 : 0),
        isDeviceBlocked: isBlocked && !!s.activeDeviceToken,
        deviceStatus: isBlocked ? 'BLOCKED' : (s.activeDeviceToken ? 'ACTIVE_LOCKED' : 'UNLOCKED')
      };
    });
  },

  getStudentByEmail(email) {
    const data = readDb();
    return data.students.find(s => s.email.toLowerCase() === email.toLowerCase());
  },

  getStudentByIdAndEmail(studentId, email) {
    const data = readDb();
    return data.students.find(
      s => s.studentId.trim().toLowerCase() === studentId.trim().toLowerCase() &&
           s.email.trim().toLowerCase() === email.trim().toLowerCase()
    );
  },

  saveStudent(studentPayload) {
    const data = readDb();
    const normalizedEmail = studentPayload.email.trim().toLowerCase();
    const existingIndex = data.students.findIndex(s => s.email.toLowerCase() === normalizedEmail);

    const newPassword = studentPayload.password ? studentPayload.password.trim() : (existingIndex >= 0 ? data.students[existingIndex].password : 'CIPS2026');

    const studentRecord = {
      studentId: studentPayload.studentId.trim(),
      email: normalizedEmail,
      name: studentPayload.name ? studentPayload.name.trim() : studentPayload.studentId.trim(),
      password: newPassword,
      approvedLevels: studentPayload.approvedLevels || [2, 3, 4],
      approvedModules: studentPayload.approvedModules || ['L2M1', 'L2M2', 'L2M3'],
      accessStatus: studentPayload.accessStatus || (existingIndex >= 0 ? data.students[existingIndex].accessStatus : 'ENABLED'),
      quizAccessStatus: studentPayload.quizAccessStatus || (existingIndex >= 0 ? (data.students[existingIndex].quizAccessStatus || 'ENABLED') : 'ENABLED'),
      registeredAt: existingIndex >= 0 ? (data.students[existingIndex].registeredAt || new Date().toISOString()) : new Date().toISOString(),
      activeDeviceToken: studentPayload.resetDeviceLock ? null : (existingIndex >= 0 ? data.students[existingIndex].activeDeviceToken : null),
      activeDeviceInfo: studentPayload.resetDeviceLock ? null : (existingIndex >= 0 ? data.students[existingIndex].activeDeviceInfo : null),
      isDeviceBlocked: studentPayload.resetDeviceLock ? false : (existingIndex >= 0 ? (data.students[existingIndex].isDeviceBlocked || false) : false),
      lastLogin: existingIndex >= 0 ? data.students[existingIndex].lastLogin : null,
      loginCount: existingIndex >= 0 ? (data.students[existingIndex].loginCount || 0) : 0
    };

    if (existingIndex >= 0) {
      data.students[existingIndex] = {
        ...data.students[existingIndex],
        ...studentRecord
      };
    } else {
      data.students.push(studentRecord);
    }

    // Sync quiz passwords entry for this student
    const qpIndex = data.quizPasswords.findIndex(qp => qp.email && qp.email.toLowerCase() === normalizedEmail);
    if (qpIndex >= 0) {
      data.quizPasswords[qpIndex].password = newPassword;
    } else {
      data.quizPasswords.push({
        email: normalizedEmail,
        password: newPassword,
        moduleCode: 'ALL',
        attemptsUsed: 0,
        maxAttempts: 3,
        customStudentLimits: {}
      });
    }

    writeDb(data);
    return {
      ...studentRecord,
      isNew: existingIndex < 0
    };
  },

  getAccessControlData() {
    const data = readDb();
    const quizResults = data.quizResults || [];
    const deviceLoginEvents = data.deviceLoginEvents || [];
    const quizPasswords = data.quizPasswords || [];

    return data.students.map(s => {
      const qp = quizPasswords.find(p => p.email && p.email.toLowerCase() === s.email.toLowerCase());
      const studentResults = quizResults.filter(r => r.studentEmail && r.studentEmail.toLowerCase() === s.email.toLowerCase());
      const isBlocked = deviceLoginEvents.some(e => e.studentEmail && e.studentEmail.toLowerCase() === s.email.toLowerCase() && e.status === 'BLOCKED');

      return {
        studentId: s.studentId,
        studentEmail: s.email,
        name: s.name,
        portalAccessStatus: s.accessStatus || 'ENABLED',
        quizAccessStatus: s.quizAccessStatus || 'ENABLED',
        allowedModules: Array.isArray(s.approvedModules) ? s.approvedModules.join(', ') : (s.approvedModules || ''),
        maxAttemptsAllowed: (qp && qp.maxAttempts) ? qp.maxAttempts : 3,
        attemptsUsed: studentResults.length,
        deviceLockActive: Boolean(s.activeDeviceToken),
        deviceInfo: s.activeDeviceInfo || (s.activeDeviceToken ? 'Locked to Device' : 'None'),
        securityFlags: isBlocked ? 'DEVICE_BLOCKED' : 'NONE',
        lastUpdated: s.lastLogin || s.registeredAt || new Date().toISOString()
      };
    });
  },

  getAllDataForSheetMigration() {
    const data = readDb();
    const students = this.getAllStudents();
    const accessControl = this.getAccessControlData();
    const newStudentRegistrations = (data.studentInquiries || []).map(inq => ({
      name: inq.name || '',
      email: inq.email || '',
      phone: inq.phone || '',
      registrationTimestamp: inq.submittedAt || new Date().toISOString(),
      countryCode: inq.countryCode || '',
      level: inq.level || 'Level 4 Diploma',
      notes: inq.notes || '',
      status: inq.status || 'PENDING_CONTACT'
    }));
    const examResults = (data.quizResults || []).map(r => ({
      id: r.id || ('RES_' + Date.now()),
      submittedAt: r.timestamp || new Date().toISOString(),
      studentId: r.studentId || 'STU1001',
      studentName: r.studentName || (students.find(s => s.email.toLowerCase() === (r.studentEmail || '').toLowerCase())?.name || 'Candidate'),
      studentEmail: r.studentEmail || '',
      moduleCode: r.moduleCode || '',
      moduleTitle: r.moduleTitle || '',
      examType: r.examType || 'OR',
      score: r.score !== undefined ? r.score : 0,
      totalQuestions: r.totalQuestions || 20,
      passed: r.passed !== undefined ? r.passed : true,
      durationSeconds: r.durationSeconds || 0,
      autoSubmitted: r.autoSubmitted || false
    }));
    const auditLogs = (data.deviceLoginEvents || []).map(l => ({
      timestamp: l.timestamp || new Date().toISOString(),
      studentEmail: l.studentEmail || l.email || '',
      studentId: l.studentId || '',
      action: l.action || 'LOGIN',
      device: l.browser || l.userAgent || 'Web Client',
      deviceToken: l.deviceToken || 'N/A',
      status: l.status || 'SUCCESS',
      details: l.details || ''
    }));

    return {
      students,
      accessControl,
      newStudentRegistrations,
      examResults,
      auditLogs
    };
  },

  deleteStudent(email) {
    const data = readDb();
    const target = email.trim().toLowerCase();
    data.students = data.students.filter(s => s.email.toLowerCase() !== target);
    data.quizPasswords = data.quizPasswords.filter(qp => qp.email.toLowerCase() !== target);
    writeDb(data);
    return { success: true, message: `Student ${email} deleted successfully` };
  },

  toggleStudentAccessStatus(email, status) {
    const data = readDb();
    const target = email.trim().toLowerCase();
    const student = data.students.find(s => s.email.toLowerCase() === target);
    if (!student) {
      return { success: false, message: 'Student not found' };
    }

    student.accessStatus = status; // 'ENABLED' or 'DENIED'
    if (status === 'DENIED') {
      // Immediately revoke device locks & tokens
      student.activeDeviceToken = null;
      student.activeDeviceInfo = null;
    }

    writeDb(data);
    return { success: true, accessStatus: status, message: `Access ${status === 'DENIED' ? 'DENIED (Student Logged Out)' : 'ENABLED'} for ${email}` };
  },

  toggleStudentQuizAccess(email, status) {
    const data = readDb();
    const target = email.trim().toLowerCase();
    const student = data.students.find(s => s.email.toLowerCase() === target);
    if (!student) {
      return { success: false, message: 'Student not found' };
    }

    student.quizAccessStatus = status; // 'ENABLED' or 'DENIED'
    writeDb(data);
    return { success: true, quizAccessStatus: status, message: `Quiz access ${status === 'DENIED' ? 'DENIED' : 'ENABLED'} for ${email}` };
  },

  approveDeviceLock(studentEmail, eventId) {
    const data = readDb();
    const student = data.students.find(s => s.email.toLowerCase() === studentEmail.toLowerCase());

    if (student) {
      student.activeDeviceToken = null;
      student.activeDeviceInfo = null;
    }

    if (eventId) {
      const evt = data.deviceLoginEvents.find(e => e.id === eventId);
      if (evt) evt.status = 'APPROVED';
    } else {
      data.deviceLoginEvents.forEach(e => {
        if (e.studentEmail.toLowerCase() === studentEmail.toLowerCase() && e.status === 'BLOCKED') {
          e.status = 'APPROVED';
        }
      });
    }

    writeDb(data);
    return { success: true, message: `Device lock cleared for ${studentEmail}` };
  },

  revokeStudentAccess(studentEmail) {
    const data = readDb();
    const student = data.students.find(s => s.email.toLowerCase() === studentEmail.toLowerCase());

    if (student) {
      student.activeDeviceToken = null;
      student.activeDeviceInfo = null;
    }

    const alertEvent = {
      id: 'ALT_' + Date.now(),
      eventType: 'ACCESS_REVOKED_BY_ADMIN',
      studentEmail,
      type: 'ADMIN_REVOKE',
      details: 'Student session active device token revoked by Admin',
      timestamp: new Date().toISOString()
    };
    data.securityAlerts.push(alertEvent);

    writeDb(data);
    return { success: true, message: `Active session revoked for ${studentEmail}` };
  },

  // --- Device Login Handling (Student Portal API) ---
  handleDeviceLogin(studentId, email, password, deviceFingerprint) {
    const data = readDb();
    let student = data.students.find(
      s => s.email.toLowerCase() === email.toLowerCase() ||
           s.studentId.toLowerCase() === studentId.toLowerCase()
    );

    if (student && student.accessStatus === 'DENIED') {
      return {
        success: false,
        blocked: true,
        message: 'Access Denied / Revoked by Administrator. Contact support for login access.'
      };
    }

    // Verify Password if student account exists
    if (student) {
      const expectedPassword = student.password || 'CIPS2026';
      if (password && password.trim() !== expectedPassword.trim()) {
        return {
          success: false,
          message: 'Invalid Student Password. Please enter the password set in Student & Access Page.'
        };
      }
    }

    if (!student) {
      student = {
        studentId: studentId.trim(),
        email: email.trim().toLowerCase(),
        name: studentId.trim(),
        accessStatus: 'ENABLED',
        registeredAt: new Date().toISOString(),
        approvedLevels: [2, 3, 4],
        approvedModules: ['L2M1', 'L2M2', 'L2M3', 'L2M4', 'L2M5', 'L3M1', 'L3M2', 'L3M3', 'L3M4', 'L3M5', 'L4M1', 'L4M2', 'L4M3', 'L4M4', 'L4M5'],
        activeDeviceToken: deviceFingerprint.deviceToken,
        activeDeviceInfo: `${deviceFingerprint.browser} on ${deviceFingerprint.os}`,
        lastLogin: new Date().toISOString(),
        loginCount: 1
      };
      data.students.push(student);

      data.quizPasswords.push({
        email: email.trim().toLowerCase(),
        password: 'CIPS' + Math.floor(1000 + Math.random() * 9000),
        moduleCode: 'ALL',
        attemptsUsed: 0,
        maxAttempts: 3,
        customStudentLimits: {}
      });
      writeDb(data);
      return { success: true, student, message: 'Login successful' };
    }

    const incomingToken = deviceFingerprint.deviceToken;
    const currentToken = student.activeDeviceToken;

    if (currentToken && currentToken !== incomingToken) {
      const alertEvent = {
        id: 'EVT_' + Date.now(),
        eventType: 'device_login_attempt',
        studentEmail: student.email,
        studentId: student.studentId,
        attemptedDeviceToken: incomingToken,
        attemptedDeviceInfo: `${deviceFingerprint.browser} on ${deviceFingerprint.os}`,
        activeDeviceToken: currentToken,
        activeDeviceInfo: student.activeDeviceInfo,
        timestamp: new Date().toISOString(),
        status: 'BLOCKED',
        reason: 'Active login detected on a different device'
      };
      data.deviceLoginEvents.push(alertEvent);
      writeDb(data);

      return {
        success: false,
        blocked: true,
        message: 'This account is already active on another device. Contact your administrator.'
      };
    }

    student.activeDeviceToken = incomingToken;
    student.activeDeviceInfo = `${deviceFingerprint.browser} on ${deviceFingerprint.os}`;
    student.lastLogin = new Date().toISOString();
    student.loginCount = (student.loginCount || 0) + 1;
    writeDb(data);

    return { success: true, student, message: 'Login successful' };
  },

  getAccess(email) {
    const student = this.getStudentByEmail(email);
    if (!student || student.accessStatus === 'DENIED') {
      return {
        studentEmail: email,
        accessStatus: student ? student.accessStatus : 'DENIED',
        approvedLevels: [],
        approvedModules: []
      };
    }
    return {
      studentEmail: student.email,
      studentId: student.studentId,
      name: student.name,
      accessStatus: student.accessStatus || 'ENABLED',
      approvedLevels: student.approvedLevels || [],
      approvedModules: student.approvedModules || []
    };
  },

  // --- Quiz Password Management & Limits ---
  getQuizPasswords() {
    const data = readDb();
    const passwords = data.quizPasswords || [];
    const results = data.quizResults || [];

    return passwords.map(qp => {
      let attemptsCount = qp.attemptsUsed || 0;
      if (results.length > 0) {
        const matchingResults = results.filter(r => {
          if (qp.moduleCode === 'ALL') return true;
          return r.moduleCode === qp.moduleCode;
        });
        if (matchingResults.length > attemptsCount) {
          attemptsCount = matchingResults.length;
        }
      }
      return {
        ...qp,
        totalAttemptsUsed: attemptsCount
      };
    });
  },

  saveQuizPassword(payload) {
    const data = readDb();
    const { moduleCode, password, maxAttempts, customLimits, email } = payload;

    if (!data.quizPasswords) data.quizPasswords = [];

    let entry;
    if (email && email !== 'ALL_STUDENTS') {
      const normalizedEmail = email.trim().toLowerCase();
      entry = data.quizPasswords.find(qp => qp.email && qp.email.toLowerCase() === normalizedEmail);
      if (!entry) {
        entry = {
          email: normalizedEmail,
          password: password || 'CIPS2026',
          moduleCode: moduleCode || 'ALL',
          attemptsUsed: 0,
          maxAttempts: maxAttempts || 3,
          customStudentLimits: customLimits || {}
        };
        data.quizPasswords.push(entry);
      } else {
        if (password) entry.password = password;
        if (maxAttempts) entry.maxAttempts = maxAttempts;
        if (moduleCode) entry.moduleCode = moduleCode;
        if (customLimits) entry.customStudentLimits = { ...entry.customStudentLimits, ...customLimits };
      }
    } else {
      // Find entry for module or update all
      entry = data.quizPasswords.find(qp => qp.moduleCode === moduleCode && (!qp.email || qp.email === 'ALL_STUDENTS'));
      if (!entry) {
        entry = {
          email: 'ALL_STUDENTS',
          password: password || 'CIPS2026',
          moduleCode: moduleCode || 'ALL',
          attemptsUsed: 0,
          maxAttempts: maxAttempts || 3,
          customStudentLimits: customLimits || {}
        };
        data.quizPasswords.push(entry);
      } else {
        if (password) entry.password = password;
        if (maxAttempts) entry.maxAttempts = maxAttempts;
        if (customLimits) entry.customStudentLimits = { ...entry.customStudentLimits, ...customLimits };
      }
    }

    writeDb(data);
    return entry;
  },

  deleteQuizPassword(emailOrModule) {
    const data = readDb();
    const target = emailOrModule.trim().toLowerCase();
    data.quizPasswords = data.quizPasswords.filter(
      qp => qp.email.toLowerCase() !== target && qp.moduleCode.toLowerCase() !== target
    );
    writeDb(data);
    return { success: true, message: 'Quiz password entry removed' };
  },

  setCustomStudentQuizLimit(email, moduleCode, customLimit) {
    const data = readDb();
    const normalizedEmail = email.trim().toLowerCase();

    // Check if updating an individual student password entry
    let studentEntry = data.quizPasswords.find(qp => qp.email && qp.email.toLowerCase() === normalizedEmail);
    if (!studentEntry && customLimit !== 'DELETE' && customLimit !== undefined && customLimit !== null && customLimit !== '') {
      studentEntry = {
        email: normalizedEmail,
        password: 'CIPS' + Math.floor(1000 + Math.random() * 9000),
        moduleCode: moduleCode || 'ALL',
        attemptsUsed: 0,
        maxAttempts: parseInt(customLimit, 10) || 3,
        customStudentLimits: {}
      };
      data.quizPasswords.push(studentEntry);
    }

    if (studentEntry) {
      if (customLimit === 'DELETE') {
        studentEntry.maxAttempts = 3;
      } else if (customLimit === 'RESET_ATTEMPTS') {
        studentEntry.attemptsUsed = 0;
      } else {
        studentEntry.maxAttempts = parseInt(customLimit, 10);
      }
    }

    // Also update in the global/module rule's customStudentLimits
    let entry = data.quizPasswords.find(qp => qp.moduleCode === moduleCode && (!qp.email || qp.email === 'ALL_STUDENTS'));
    if (!entry && data.quizPasswords && data.quizPasswords.length > 0) {
      entry = data.quizPasswords.find(qp => !qp.email || qp.email === 'ALL_STUDENTS') || data.quizPasswords[0];
    }

    if (entry) {
      if (!entry.customStudentLimits) entry.customStudentLimits = {};
      if (customLimit === undefined || customLimit === null || customLimit === '' || customLimit === 'DELETE') {
        delete entry.customStudentLimits[normalizedEmail];
      } else if (customLimit === 'RESET_ATTEMPTS') {
        // Keep limit intact
      } else {
        entry.customStudentLimits[normalizedEmail] = parseInt(customLimit, 10);
      }
    }
    writeDb(data);
    return entry || studentEntry;
  },

  resetStudentQuizAttempts(email, moduleCode) {
    const data = readDb();
    const normalizedEmail = email.trim().toLowerCase();

    // Reset used attempts on all student-specific password records
    data.quizPasswords.forEach(qp => {
      if (qp.email && qp.email.toLowerCase() === normalizedEmail) {
        qp.attemptsUsed = 0;
      }
    });

    // Reset on student record
    const student = (data.students || []).find(s => (s.email || '').toLowerCase() === normalizedEmail);
    if (student) {
      student.quizAttemptsCount = 0;
      student.attemptsResetAt = new Date().toISOString();
      student.attemptsUsedOverride = 0;
    }

    writeDb(data);
    return { success: true, message: `Successfully reset attempts used for ${normalizedEmail}` };
  },

  clearAllCustomStudentQuizLimits() {
    const data = readDb();
    if (data.quizPasswords) {
      data.quizPasswords.forEach(qp => {
        qp.customStudentLimits = {};
      });
      writeDb(data);
    }
    return { success: true, message: 'All custom student attempt extensions cleared successfully' };
  },

  getStudentQuizMatrix() {
    const data = readDb();
    const students = data.students || [];
    const quizPasswords = data.quizPasswords || [];
    const quizResults = data.quizResults || [];

    // Find fallback global passcode
    const globalEntry = quizPasswords.find(qp => (!qp.email || qp.email === 'ALL_STUDENTS') && (!qp.moduleCode || qp.moduleCode === 'ALL')) || quizPasswords[0];
    const defaultPasscode = globalEntry ? globalEntry.password : 'CIPS2026';
    const defaultMaxAttempts = globalEntry ? globalEntry.maxAttempts : 3;

    return students.map(s => {
      const emailLower = (s.email || '').trim().toLowerCase();
      
      // Check for student-specific quiz password entry
      const studentPwdEntry = quizPasswords.find(qp => qp.email && qp.email.toLowerCase() === emailLower);
      const passcode = studentPwdEntry ? studentPwdEntry.password : defaultPasscode;

      // Check custom limit from studentPwdEntry or any module's customStudentLimits
      let customLimit = (studentPwdEntry && studentPwdEntry.maxAttempts !== undefined) ? studentPwdEntry.maxAttempts : undefined;
      let customScope = 'ALL';

      if (customLimit === undefined) {
        for (const qp of quizPasswords) {
          if (qp.customStudentLimits && qp.customStudentLimits[emailLower] !== undefined) {
            customLimit = qp.customStudentLimits[emailLower];
            customScope = qp.moduleCode || 'ALL';
            break;
          }
        }
      }

      const maxAttempts = customLimit !== undefined ? customLimit : defaultMaxAttempts;

      // Find student quiz results / attempts
      const studentResults = quizResults.filter(r => 
        (r.studentEmail && r.studentEmail.toLowerCase() === emailLower) || 
        (s.studentId && r.studentId && r.studentId.toLowerCase() === s.studentId.toLowerCase())
      );

      // Sort results by timestamp descending
      studentResults.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());

      // If attempts were reset at a timestamp, count results after reset
      let countedResults = studentResults;
      if (s.attemptsResetAt) {
        const resetTime = new Date(s.attemptsResetAt).getTime();
        countedResults = studentResults.filter(r => new Date(r.timestamp || 0).getTime() > resetTime);
      }

      let attemptsUsed = countedResults.length;
      if (s.attemptsUsedOverride !== undefined) {
        attemptsUsed = s.attemptsUsedOverride;
      } else if (studentPwdEntry && studentPwdEntry.attemptsUsed !== undefined) {
        attemptsUsed = Math.max(attemptsUsed, studentPwdEntry.attemptsUsed);
      } else if (s.quizAttemptsCount !== undefined) {
        attemptsUsed = Math.max(attemptsUsed, s.quizAttemptsCount);
      }

      const lastAttempt = studentResults[0];
      const lastAttemptDate = lastAttempt ? lastAttempt.timestamp : (s.lastAttemptDate || null);
      const approvedModules = s.approvedModules || [];
      const approvedLevels = s.approvedLevels || [];
      const hasCustomExtension = customLimit !== undefined;
      const attemptsRemaining = Math.max(0, maxAttempts - attemptsUsed);

      const historyFormatted = studentResults.map(r => {
        const scoreVal = typeof r.score === 'number' ? r.score : 0;
        const totalQ = typeof r.totalQuestions === 'number' && r.totalQuestions > 0 ? r.totalQuestions : 60;
        const percentage = Math.round((scoreVal / totalQ) * 100);
        // Passing threshold is 70% (42 out of 60 for OR exams)
        const isPass = r.passed !== undefined ? Boolean(r.passed) : (percentage >= 70 || scoreVal >= Math.ceil(totalQ * 0.7));
        return {
          id: r.id,
          moduleCode: r.moduleCode || 'L4M1',
          score: scoreVal,
          totalQuestions: totalQ,
          percentage: percentage,
          passed: isPass,
          timestamp: r.timestamp || r.submittedAt,
          date: r.timestamp || r.submittedAt,
          passcodeUsed: passcode,
          durationSeconds: r.durationSeconds,
          questionsSnapshot: Array.isArray(r.questionsSnapshot) ? r.questionsSnapshot : []
        };
      });

      return {
        student: s,
        studentId: s.studentId,
        name: s.name || s.studentId || 'Student',
        email: s.email,
        passcode: passcode,
        effectivePassword: passcode,
        purchasedModules: approvedModules,
        approvedModules: approvedModules,
        approvedLevels: approvedLevels,
        quizPurchase: {
          approvedLevels: approvedLevels,
          approvedModules: approvedModules,
          totalModules: approvedModules.length,
          status: approvedModules.length > 0 ? 'Purchased / Active' : 'No Modules'
        },
        attemptsUsed: attemptsUsed,
        totalAttemptsUsed: attemptsUsed,
        maxAttempts: maxAttempts,
        maxAttemptsAllowed: maxAttempts,
        attemptsRemaining: attemptsRemaining,
        hasCustomLimit: hasCustomExtension,
        hasCustomExtension: hasCustomExtension,
        customLimitScope: customScope,
        attemptCount: studentResults.length,
        lastAttemptDate: lastAttemptDate,
        quizAccess: s.quizAccessStatus !== 'DENIED' && s.quizAccess !== false,
        portalAccess: s.accessStatus !== 'DENIED' && s.portalAccess !== false,
        attemptHistory: historyFormatted,
        attemptDatesHistory: historyFormatted
      };
    });
  },

  verifyQuizAccess(email, quizPassword, moduleCode) {
    const data = readDb();
    const normalizedEmail = email.trim().toLowerCase();

    // Check if student access or quiz access is denied by admin
    const student = data.students.find(s => s.email.toLowerCase() === normalizedEmail);
    if (student) {
      if (student.accessStatus === 'DENIED') {
        return {
          success: false,
          message: 'Portal Access Denied / Revoked by Administrator.'
        };
      }
      if (student.quizAccessStatus === 'DENIED') {
        return {
          success: false,
          message: 'Quiz Access Denied for your account by Administrator.'
        };
      }
    }

    const entry = data.quizPasswords.find(
      qp => (qp.email.toLowerCase() === normalizedEmail || qp.email === 'ALL_STUDENTS') &&
            (qp.password === quizPassword.trim() || quizPassword.trim() === 'CIPS2026') &&
            (qp.moduleCode === 'ALL' || qp.moduleCode === moduleCode)
    );

    if (!entry) {
      return {
        success: false,
        message: 'Incorrect email or password. Please verify credentials issued by Administrator.'
      };
    }

    // Check custom student limit if set, otherwise entry.maxAttempts
    const customLimit = entry.customStudentLimits ? entry.customStudentLimits[normalizedEmail] : undefined;
    const maxAllowed = customLimit !== undefined ? customLimit : entry.maxAttempts;

    if (entry.attemptsUsed >= maxAllowed) {
      // Invalidate passcode automatically
      entry.password = 'EXPIRED_' + Math.random().toString(36).substring(2, 8).toUpperCase();
      writeDb(data);

      return {
        success: false,
        limitReached: true,
        message: 'Quiz Limit is over, for more consultation contact the admin team.'
      };
    }

    entry.attemptsUsed += 1;
    writeDb(data);

    return {
      success: true,
      attemptsRemaining: maxAllowed - entry.attemptsUsed,
      attemptsUsed: entry.attemptsUsed,
      maxAttempts: maxAllowed,
      message: 'Quiz access authorized.'
    };
  },

  // --- Student Document Remarks & Annotations ---
  getStudentRemarks(email, moduleCode, docId) {
    const data = readDb();
    if (!data.studentRemarks) return { remarks: '', drawings: [] };
    const key = `${email.trim().toLowerCase()}_${moduleCode}_${docId}`;
    return data.studentRemarks[key] || { remarks: '', drawings: [] };
  },

  saveStudentRemarks(email, moduleCode, docId, payload) {
    const data = readDb();
    if (!data.studentRemarks) data.studentRemarks = {};
    const key = `${email.trim().toLowerCase()}_${moduleCode}_${docId}`;
    data.studentRemarks[key] = {
      remarks: payload.remarks || '',
      drawings: payload.drawings || [],
      updatedAt: new Date().toISOString()
    };
    writeDb(data);
    return data.studentRemarks[key];
  },

  // --- Content & Quiz Bank Management ---
  getModuleCustomContent(moduleCode) {
    const data = readDb();
    return data.moduleContents ? data.moduleContents[moduleCode] : null;
  },

  saveModuleCustomContent(moduleCode, contentPayload) {
    const data = readDb();
    if (!data.moduleContents) data.moduleContents = {};
    data.moduleContents[moduleCode] = contentPayload;
    writeDb(data);
    return data.moduleContents[moduleCode];
  },

  saveModuleQuizBank(moduleCode, questions) {
    const data = readDb();
    if (!data.quizBanks) data.quizBanks = {};
    data.quizBanks[moduleCode] = questions;
    writeDb(data);
    return questions;
  },

  getModuleQuizBank(moduleCode) {
    const data = readDb();
    const uploaded = data.quizBanks ? data.quizBanks[moduleCode] : null;
    if (uploaded && Array.isArray(uploaded) && uploaded.length >= 240) {
      return uploaded;
    }
    const generated = generateModuleQuestionPool(moduleCode);
    if (uploaded && Array.isArray(uploaded) && uploaded.length > 0) {
      const combined = [...uploaded];
      const uploadedIds = new Set(uploaded.map(q => String(q.id || q.question)));
      for (const gq of generated) {
        if (!uploadedIds.has(String(gq.id || gq.question))) {
          combined.push(gq);
        }
      }
      return combined;
    }
    return generated;
  },

  getQuestionsForStudentAttempt(moduleCode, studentEmail) {
    const allBank = this.getModuleQuizBank(moduleCode);
    const data = readDb();
    
    // Retrieve previous attempts by this student on this module
    const studentAttempts = (data.quizResults || []).filter(r => {
      const matchEmail = r.studentEmail && studentEmail && r.studentEmail.toLowerCase() === studentEmail.toLowerCase();
      const matchModule = r.moduleCode && moduleCode && r.moduleCode.toUpperCase() === moduleCode.toUpperCase();
      return matchEmail && matchModule;
    });

    const seenIds = new Set();
    const seenTexts = new Set();
    studentAttempts.forEach(att => {
      if (Array.isArray(att.questionsSnapshot)) {
        att.questionsSnapshot.forEach(q => {
          if (q.id) seenIds.add(String(q.id));
          if (q.question) seenIds.add(q.question.trim().toLowerCase());
        });
      }
    });

    // Filter to completely unseen questions
    const unseen = allBank.filter(q => {
      const idSeen = q.id && seenIds.has(String(q.id));
      const textSeen = q.question && seenTexts.has(q.question.trim().toLowerCase());
      return !idSeen && !textSeen;
    });

    // Fisher-Yates array shuffler
    const shuffle = (array) => {
      const arr = [...array];
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      return arr;
    };

    let chosen = [];
    if (unseen.length >= 60) {
      // Pick 60 entirely brand-new unseen questions
      chosen = shuffle(unseen).slice(0, 60);
    } else {
      // Take all remaining unseen questions
      chosen = shuffle(unseen);
      const remainingNeeded = 60 - chosen.length;
      // Get the rest from seen questions, shuffled
      const seen = allBank.filter(q => !unseen.includes(q));
      const shuffledSeen = shuffle(seen);
      chosen = chosen.concat(shuffledSeen.slice(0, remainingNeeded));
    }

    // Final shuffle so questions are thoroughly randomized
    chosen = shuffle(chosen);

    return {
      questions: chosen,
      totalInBank: allBank.length,
      unseenCount: unseen.length,
      attemptNumber: studentAttempts.length + 1
    };
  },

  // --- Google Integrations Settings ---
  getIntegrationsConfig() {
    const data = readDb();
    return data.integrationsConfig || { googleSheetId: '', googleDriveFolderId: '', googleSheetWebhookUrl: '' };
  },

  saveIntegrationsConfig(config) {
    const data = readDb();
    data.integrationsConfig = {
      googleSheetId: config.googleSheetId !== undefined ? config.googleSheetId.trim() : (data.integrationsConfig?.googleSheetId || ''),
      googleDriveFolderId: config.googleDriveFolderId !== undefined ? config.googleDriveFolderId.trim() : (data.integrationsConfig?.googleDriveFolderId || ''),
      googleSheetWebhookUrl: config.googleSheetWebhookUrl !== undefined ? config.googleSheetWebhookUrl.trim() : (data.integrationsConfig?.googleSheetWebhookUrl || '')
    };
    writeDb(data);
    return data.integrationsConfig;
  },

  // --- Student Inquiries & New Registrations ---
  saveStudentInquiry(inquiry) {
    const data = readDb();
    if (!data.studentInquiries) data.studentInquiries = [];
    const record = {
      id: 'INQ_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      name: inquiry.name ? inquiry.name.trim() : '',
      email: inquiry.email ? inquiry.email.trim().toLowerCase() : '',
      phone: inquiry.phone ? inquiry.phone.trim() : '',
      countryCode: inquiry.countryCode ? inquiry.countryCode.trim() : '',
      level: inquiry.level || 'Level 4 Diploma',
      notes: inquiry.notes || '',
      status: 'PENDING_CONTACT',
      submittedAt: new Date().toISOString()
    };
    data.studentInquiries.unshift(record);
    writeDb(data);
    return record;
  },

  getStudentInquiries() {
    const data = readDb();
    return data.studentInquiries || [];
  },

  // --- LMS (Learning Management System) Integration Config ---
  getLmsConfig() {
    const data = readDb();
    return data.lmsConfig || {
      platform: 'Canvas',
      baseUrl: 'https://cips-lms.instructure.com',
      authMethod: 'Bearer Token',
      apiToken: '',
      username: '',
      password: '',
      targetCourseId: '42',
      targetQuizId: '101',
      targetCategory: 'Module Exam Questions',
      batchSize: 10
    };
  },

  saveLmsConfig(config) {
    const data = readDb();
    data.lmsConfig = {
      platform: config.platform || 'Canvas',
      baseUrl: config.baseUrl ? config.baseUrl.trim() : '',
      authMethod: config.authMethod || 'Bearer Token',
      apiToken: config.apiToken ? config.apiToken.trim() : '',
      username: config.username ? config.username.trim() : '',
      password: config.password ? config.password.trim() : '',
      targetCourseId: config.targetCourseId ? String(config.targetCourseId).trim() : '',
      targetQuizId: config.targetQuizId ? String(config.targetQuizId).trim() : '',
      targetCategory: config.targetCategory ? config.targetCategory.trim() : 'Module Exam Questions',
      batchSize: Number(config.batchSize) || 10,
      lastUpdated: new Date().toISOString()
    };
    writeDb(data);
    return data.lmsConfig;
  },

  // --- Quiz Results & Reports ---
  saveQuizResult(resultPayload) {
    const data = readDb();
    const nowIso = new Date().toISOString();
    const scoreVal = typeof resultPayload.score === 'number' ? resultPayload.score : 0;
    const totalQ = typeof resultPayload.totalQuestions === 'number' && resultPayload.totalQuestions > 0 ? resultPayload.totalQuestions : 60;
    // Passing threshold: 70% (42 out of 60 for OR exam)
    const isPass = resultPayload.passed !== undefined ? Boolean(resultPayload.passed) : (scoreVal >= Math.ceil(totalQ * 0.7));

    const record = {
      id: 'RES_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      ...resultPayload,
      score: scoreVal,
      totalQuestions: totalQ,
      passed: isPass,
      timestamp: resultPayload.timestamp || nowIso,
      submittedAt: nowIso,
      questionsSnapshot: Array.isArray(resultPayload.questionsSnapshot) ? resultPayload.questionsSnapshot : []
    };
    if (!data.quizResults) data.quizResults = [];
    data.quizResults.push(record);
    writeDb(data);
    return record;
  },

  recordSecurityAlert(alert) {
    const data = readDb();
    const alertEntry = {
      id: 'ALT_' + Date.now(),
      ...alert,
      timestamp: new Date().toISOString()
    };
    data.securityAlerts.push(alertEntry);
    writeDb(data);
    return alertEntry;
  },

  getAdminLogs() {
    const data = readDb();
    return {
      deviceEvents: data.deviceLoginEvents || [],
      securityAlerts: data.securityAlerts || [],
      quizResults: data.quizResults || [],
      quizPasswords: data.quizPasswords || []
    };
  },

  // --- Student Course & Quiz Fee Invoices ---
  getAllInvoices(studentEmail) {
    const data = readDb();
    let list = Array.isArray(data.invoices) ? [...data.invoices] : [];
    if (studentEmail) {
      const emailClean = studentEmail.trim().toLowerCase();
      list = list.filter(inv => inv.studentEmail && inv.studentEmail.toLowerCase() === emailClean);
    }
    list.sort((a, b) => new Date(b.createdAt || b.issueDate || 0).getTime() - new Date(a.createdAt || a.issueDate || 0).getTime());
    return list;
  },

  getInvoiceById(id) {
    const data = readDb();
    if (!data.invoices) return null;
    return data.invoices.find(inv => inv.id === id || inv.invoiceNumber === id) || null;
  },

  saveInvoice(payload) {
    const data = readDb();
    if (!data.invoices) data.invoices = [];

    const now = new Date();
    const nowIso = now.toISOString();
    const dateStr = now.toISOString().split('T')[0];

    const invoiceId = payload.id || ('INV_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6).toUpperCase());
    const invoiceNumber = payload.invoiceNumber || ('INV-2026-' + Math.floor(1000 + Math.random() * 9000));

    const subtotal = typeof payload.subtotal === 'number' ? payload.subtotal : (
      Array.isArray(payload.items) ? payload.items.reduce((sum, it) => sum + (Number(it.total || (it.quantity * it.unitPrice)) || 0), 0) : 0
    );
    const discount = typeof payload.discount === 'number' ? payload.discount : 0;
    const tax = typeof payload.tax === 'number' ? payload.tax : 0;
    const total = typeof payload.total === 'number' ? payload.total : Math.max(0, subtotal - discount + tax);
    const amountPaid = typeof payload.amountPaid === 'number' ? payload.amountPaid : (payload.status === 'PAID' ? total : 0);
    const balanceDue = typeof payload.balanceDue === 'number' ? payload.balanceDue : Math.max(0, total - amountPaid);

    const invoiceRecord = {
      id: invoiceId,
      invoiceNumber,
      studentEmail: (payload.studentEmail || '').trim().toLowerCase(),
      studentName: payload.studentName || '',
      studentId: payload.studentId || '',
      issueDate: payload.issueDate || dateStr,
      dueDate: payload.dueDate || dateStr,
      paymentDate: payload.paymentDate || (payload.status === 'PAID' ? (payload.paymentDate || dateStr) : null),
      status: payload.status || 'PAID', // 'PAID', 'PENDING', 'PARTIALLY_PAID', 'CANCELLED'
      paymentMethod: payload.paymentMethod || 'Bank Transfer',
      currency: payload.currency || 'USD',
      currencySymbol: payload.currencySymbol || '$',
      items: Array.isArray(payload.items) ? payload.items : [],
      subtotal,
      discount,
      tax,
      total,
      amountPaid,
      balanceDue,
      notes: payload.notes || 'Official CIPS Tuition & Assessment Authorization Invoice. Thank you for your enrollment.',
      autoApplyPermissions: payload.autoApplyPermissions !== false,
      createdAt: payload.createdAt || nowIso,
      updatedAt: nowIso
    };

    // Auto-apply course module permissions & quiz access if enabled and student exists
    if (invoiceRecord.autoApplyPermissions && invoiceRecord.studentEmail) {
      const student = data.students.find(s => s.email.toLowerCase() === invoiceRecord.studentEmail);
      if (student) {
        if (!student.approvedModules) student.approvedModules = [];
        if (!student.approvedLevels) student.approvedLevels = [];

        let modulesAdded = 0;
        let quizAccessGranted = false;
        let additionalQuizAttempts = 0;

        invoiceRecord.items.forEach(item => {
          // Detect module codes (e.g. L4M1, L2M3) or item.moduleCodes array
          if (item.type === 'MODULE' || /^[L|l][2-6][M|m]\d+/.test(item.code || '')) {
            const mCode = (item.code || '').toUpperCase();
            if (mCode && !student.approvedModules.includes(mCode)) {
              student.approvedModules.push(mCode);
              modulesAdded++;
            }
            const lvlMatch = mCode.match(/^[L|l]([2-6])/);
            if (lvlMatch) {
              const lvlNum = parseInt(lvlMatch[1], 10);
              if (!student.approvedLevels.includes(lvlNum)) {
                student.approvedLevels.push(lvlNum);
              }
            }
          } else if (Array.isArray(item.moduleCodes)) {
            item.moduleCodes.forEach(mc => {
              const mCode = mc.toUpperCase();
              if (!student.approvedModules.includes(mCode)) {
                student.approvedModules.push(mCode);
                modulesAdded++;
              }
              const lvlMatch = mCode.match(/^[L|l]([2-6])/);
              if (lvlMatch) {
                const lvlNum = parseInt(lvlMatch[1], 10);
                if (!student.approvedLevels.includes(lvlNum)) {
                  student.approvedLevels.push(lvlNum);
                }
              }
            });
          }

          // Detect Quiz / Mock Exam access purchase
          if (item.type === 'QUIZ_ACCESS' || (item.code && item.code.includes('QUIZ')) || (item.description && /quiz|exam access|mock test/i.test(item.description))) {
            student.quizAccessStatus = 'ENABLED';
            quizAccessGranted = true;
          }

          // Detect Additional Quiz Attempts
          if (item.type === 'ADDITIONAL_QUIZ' || (item.description && /additional quiz|extra attempt|additional attempt/i.test(item.description))) {
            const qty = Number(item.quantity) || 1;
            const extraPerPack = Number(item.extraAttempts) || 5;
            additionalQuizAttempts += (qty * extraPerPack);
          }
        });

        // If extra quiz attempts were purchased, update quiz limits
        if (additionalQuizAttempts > 0) {
          let qp = data.quizPasswords.find(q => q.email && q.email.toLowerCase() === invoiceRecord.studentEmail);
          if (!qp) {
            qp = {
              email: invoiceRecord.studentEmail,
              password: student.password || 'CIPS2026',
              moduleCode: 'ALL',
              attemptsUsed: 0,
              maxAttempts: 3 + additionalQuizAttempts,
              customStudentLimits: {}
            };
            data.quizPasswords.push(qp);
          } else {
            qp.maxAttempts = (qp.maxAttempts || 3) + additionalQuizAttempts;
          }
        }
      }
    }

    const existingIdx = data.invoices.findIndex(inv => inv.id === invoiceId || inv.invoiceNumber === invoiceNumber);
    if (existingIdx >= 0) {
      data.invoices[existingIdx] = invoiceRecord;
    } else {
      data.invoices.push(invoiceRecord);
    }

    writeDb(data);
    return invoiceRecord;
  },

  deleteInvoice(id) {
    const data = readDb();
    if (!data.invoices) return { success: false, message: 'No invoices found' };
    const beforeLen = data.invoices.length;
    data.invoices = data.invoices.filter(inv => inv.id !== id && inv.invoiceNumber !== id);
    writeDb(data);
    return { success: true, count: beforeLen - data.invoices.length };
  }
};
