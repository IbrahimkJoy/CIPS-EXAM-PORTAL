import fs from 'fs';
import path from 'path';

/**
 * Enhanced Google Sheets Database Sync Service
 * 
 * Supports both:
 * 1. Google Apps Script Webhook (Zero GCP config, 100% free, works on localhost & live)
 * 2. Google Sheets REST API (via Service Account JSON key)
 */

export async function syncEventToGoogleSheet(eventType, eventData, configOverride = null) {
  // 1. Resolve integrations config
  let integrations = configOverride;
  if (!integrations) {
    try {
      const dbModule = await import('./db.js');
      integrations = dbModule.db ? dbModule.db.getIntegrationsConfig() : {};
    } catch (e) {
      integrations = {};
    }
  }

  const webhookUrl = process.env.GOOGLE_SHEET_WEBHOOK_URL || (integrations && integrations.googleSheetWebhookUrl);
  const sheetId = process.env.GOOGLE_SHEET_ID || (integrations && integrations.googleSheetId);

  // If no webhook and no sheet ID, return gracefully
  if (!webhookUrl && !sheetId) {
    return { success: false, reason: 'NO_CONFIG_FOUND' };
  }

  // Priority 1: Google Apps Script Web App Webhook
  if (webhookUrl && typeof webhookUrl === 'string' && webhookUrl.startsWith('http')) {
    return await dispatchToWebhook(webhookUrl, eventType, eventData);
  }

  // Priority 2: Service Account REST API fallback
  if (sheetId) {
    return await dispatchToServiceAccount(sheetId, eventType, eventData);
  }

  return { success: false, reason: 'NO_ACTIVE_CHANNEL' };
}

/**
 * Dispatch structured event to Google Apps Script Web App
 */
async function dispatchToWebhook(webhookUrl, eventType, data) {
  try {
    const payload = {
      action: eventType,
      eventType: eventType,
      timestamp: new Date().toISOString(),
      data: data,
      source: 'CIPS Student Portal'
    };

    const res = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(payload),
      redirect: 'follow'
    });

    const responseText = await res.text();
    let parsed = null;
    try {
      parsed = JSON.parse(responseText);
    } catch (e) {
      parsed = { raw: responseText.substring(0, 300) };
    }

    console.log(`[Google Sheets Webhook Sync] [${eventType}] Status: ${res.status}`);
    return {
      success: res.ok,
      status: res.status,
      response: parsed
    };
  } catch (err) {
    console.warn(`[Google Sheets Webhook Sync] [${eventType}] Error:`, err.message);
    return { success: false, error: err.message };
  }
}

/**
 * Legacy Service Account Row Appender
 */
async function dispatchToServiceAccount(sheetId, eventType, data) {
  const saEnv = process.env.GOOGLE_SERVICE_ACCOUNT || process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
  if (!saEnv) {
    return { success: false, reason: 'NO_SERVICE_ACCOUNT_ENV' };
  }

  try {
    let rowValues = [];
    const ts = new Date().toISOString();

    if (eventType === 'QUIZ_RESULT') {
      const scorePct = data.totalQuestions ? Math.round((data.score / data.totalQuestions) * 100) : 0;
      rowValues = [
        data.studentEmail || 'N/A',
        ts,
        data.studentName || 'Candidate',
        data.moduleCode || 'N/A',
        `${data.score}/${data.totalQuestions} (${scorePct}%)`,
        data.passed ? 'PASS' : 'FAIL',
        data.id || 'N/A'
      ];
    } else if (eventType === 'STUDENT_REGISTER') {
      rowValues = [
        data.email || 'N/A',
        ts,
        data.studentId || 'N/A',
        data.name || 'N/A',
        (data.approvedLevels || []).join(', '),
        'REGISTERED'
      ];
    } else if (eventType === 'LOGIN') {
      rowValues = [
        data.email || 'N/A',
        ts,
        data.loginCount || 1,
        'LOGIN_EVENT',
        'N/A',
        'SUCCESS'
      ];
    } else if (eventType === 'INQUIRY') {
      rowValues = [
        data.email || 'N/A',
        ts,
        data.name || 'N/A',
        data.phone || 'N/A',
        data.level || 'General',
        'INQUIRY'
      ];
    } else {
      rowValues = [data.email || 'System', ts, eventType, JSON.stringify(data)];
    }

    return await appendToGoogleSheet(sheetId, rowValues);
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Raw Service Account JWT Append
 */
export async function appendToGoogleSheet(sheetId, rowData) {
  if (!sheetId) return { success: false, reason: 'NO_SHEET_ID' };

  const saEnv = process.env.GOOGLE_SERVICE_ACCOUNT || process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
  if (!saEnv) return { success: false, reason: 'NO_SERVICE_ACCOUNT_ENV' };

  try {
    let saCreds;
    try {
      saCreds = typeof saEnv === 'string' && saEnv.startsWith('{') ? JSON.parse(saEnv) : JSON.parse(Buffer.from(saEnv, 'base64').toString('utf-8'));
    } catch (e) {
      return { success: false, reason: 'INVALID_CREDENTIALS_JSON' };
    }

    const crypto = await import('crypto');
    const now = Math.floor(Date.now() / 1000);
    const header = { alg: 'RS256', typ: 'JWT' };
    const claimSet = {
      iss: saCreds.client_email,
      scope: 'https://www.googleapis.com/auth/spreadsheets',
      aud: 'https://oauth2.googleapis.com/token',
      exp: now + 3600,
      iat: now
    };

    const sHeader = Buffer.from(JSON.stringify(header)).toString('base64url');
    const sClaimSet = Buffer.from(JSON.stringify(claimSet)).toString('base64url');
    const signInput = `${sHeader}.${sClaimSet}`;

    const signer = crypto.createSign('RSA-SHA256');
    signer.update(signInput);
    const signature = signer.sign(saCreds.private_key, 'base64url');
    const jwt = `${signInput}.${signature}`;

    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        assertion: jwt
      })
    });

    if (!tokenRes.ok) return { success: false, reason: 'TOKEN_FETCH_FAILED' };

    const { access_token } = await tokenRes.json();

    const appendRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Sheet1!A1:append?valueInputOption=USER_ENTERED`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: [rowData] })
    });

    return { success: appendRes.ok };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Legacy adapter for forwardInquiryToGoogleSheetWebhook
 */
export async function forwardInquiryToGoogleSheetWebhook(webhookUrl, inquiryData) {
  return await dispatchToWebhook(webhookUrl, 'INQUIRY', inquiryData);
}

/**
 * Google Apps Script Full Code Generator
 * Reads from /google-apps-script.js
 */
export function getGoogleAppsScriptTemplate() {
  try {
    const scriptPath = path.join(process.cwd(), 'google-apps-script.js');
    if (fs.existsSync(scriptPath)) {
      return fs.readFileSync(scriptPath, 'utf8');
    }
  } catch (err) {
    console.warn('Could not read google-apps-script.js', err);
  }
  return '// Please refer to /google-apps-script.js in the root directory.';
}
