/**
 * CIPS Portal Theme Controller
 * Interactive Table Lamp theme switch with pull-cord mechanical spring animation.
 */

const THEME_STORAGE_KEY = 'cips_theme_mode';

export function getPreferredTheme() {
  const saved = localStorage.getItem(THEME_STORAGE_KEY);
  if (saved === 'light' || saved === 'dark') {
    return saved;
  }
  return 'dark'; // Tactical command center dark theme by default
}

export function applyTheme(theme) {
  const currentTheme = theme === 'light' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', currentTheme);
  if (document.body) {
    document.body.setAttribute('data-theme', currentTheme);
  }
  localStorage.setItem(THEME_STORAGE_KEY, currentTheme);

  updateThemeToggleButtons(currentTheme);

  // Notify logistics background animation canvas
  window.dispatchEvent(new CustomEvent('cipsThemeChanged', {
    detail: { theme: currentTheme }
  }));
}

let isPulling = false;

export function pullLampAndToggleTheme() {
  if (isPulling) return;
  isPulling = true;

  const current = document.documentElement.getAttribute('data-theme') || getPreferredTheme();
  const nextTheme = current === 'dark' ? 'light' : 'dark';

  // Animate all visible lamp pull cords with spring physics
  const cords = document.querySelectorAll('.lamp-cord-group');
  cords.forEach(c => {
    c.classList.remove('pulling');
    void c.getBoundingClientRect(); // Trigger reflow for instantaneous restart
    c.classList.add('pulling');
  });

  // Switch the theme right when the wire reaches max stretch (~150ms)
  setTimeout(() => {
    applyTheme(nextTheme);
  }, 150);

  // Reset animation flag once spring settles
  setTimeout(() => {
    cords.forEach(c => c.classList.remove('pulling'));
    isPulling = false;
  }, 480);

  return nextTheme;
}

export function updateThemeToggleButtons(currentTheme) {
  const isLight = currentTheme === 'light';

  // 1. Update Table Lamp buttons
  const lampBtns = document.querySelectorAll('.lamp-theme-btn');
  lampBtns.forEach(btn => {
    btn.setAttribute(
      'title',
      isLight ? 'Table Lamp is ON (Light Mode) • Click or pull wire to switch to Dark' : 'Table Lamp is OFF (Dark Mode) • Click or pull wire to switch to Light'
    );
    btn.setAttribute(
      'aria-label',
      isLight ? 'Table lamp is on. Click or pull wire to switch to dark theme' : 'Table lamp is off. Click or pull wire to switch to light theme'
    );
  });

  // 2. Fallback for any legacy theme buttons
  const legacyBtns = document.querySelectorAll('.theme-toggle-btn');
  legacyBtns.forEach(btn => {
    const iconEl = btn.querySelector('.theme-toggle-icon');
    const textEl = btn.querySelector('.theme-toggle-text');
    if (iconEl) iconEl.textContent = isLight ? '☀️' : '🌙';
    if (textEl) textEl.textContent = isLight ? 'Light' : 'Dark';
  });
}

export function initTheme() {
  const preferred = getPreferredTheme();
  applyTheme(preferred);

  // Single delegated listener for both lamp clicks and wire pulls
  document.addEventListener('click', (e) => {
    const lampBtn = e.target.closest('.lamp-theme-btn');
    if (lampBtn) {
      e.preventDefault();
      pullLampAndToggleTheme();
      return;
    }
    const legacyBtn = e.target.closest('.theme-toggle-btn');
    if (legacyBtn) {
      e.preventDefault();
      pullLampAndToggleTheme();
    }
  });

  // Keyboard accessibility: Enter or Space on lamp button triggers pull
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      const active = document.activeElement;
      if (active && active.classList.contains('lamp-theme-btn')) {
        e.preventDefault();
        pullLampAndToggleTheme();
      }
    }
  });
}

// Early execution before DOM paints to prevent flash
(function autoApplyEarly() {
  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    const theme = (saved === 'light' || saved === 'dark') ? saved : 'dark';
    document.documentElement.setAttribute('data-theme', theme);
  } catch (e) {
    // Ignore early storage error
  }
})();

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTheme);
  } else {
    initTheme();
  }
}
