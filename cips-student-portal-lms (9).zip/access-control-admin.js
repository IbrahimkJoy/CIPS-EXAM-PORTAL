import { apiConfig } from './api-config.js';

document.addEventListener('DOMContentLoaded', async () => {
  // Check admin session
  const adminSession = apiConfig.getStoredAdmin();
  if (!adminSession) {
    window.location.href = 'admin-login.html';
    return;
  }

  const adminLabel = document.getElementById('admin-user-label');
  if (adminLabel) adminLabel.textContent = adminSession.username;

  const btnLogout = document.getElementById('btn-admin-logout');
  if (btnLogout) {
    btnLogout.addEventListener('click', () => {
      apiConfig.clearStoredAdmin();
      window.location.href = 'admin-login.html';
    });
  }

  const tableBody = document.getElementById('students-table-body');
  const btnRefresh = document.getElementById('btn-refresh-students');
  const deviceUnlockContainer = document.getElementById('device-unlock-container');

  let allQuizResults = [];
  let activeTimelineStudentEmail = null;

  const studentForm = document.getElementById('student-editor-form');
  const editStudentId = document.getElementById('editStudentId');
  const editEmail = document.getElementById('editEmail');
  const editName = document.getElementById('editName');
  const editPassword = document.getElementById('editPassword');
  const btnCancel = document.getElementById('btn-cancel-edit');
  const accordionContainer = document.getElementById('levels-checkbox-accordion');

  const searchInput = document.getElementById('search-students-input');
  const sortSelect = document.getElementById('sort-students-select');
  const btnTogglePassView = document.getElementById('btn-toggle-password-view');

  const thStudentInfo = document.getElementById('th-student-info');
  const thRegisteredDate = document.getElementById('th-registered-date');
  const thQuizAttempts = document.getElementById('th-quiz-attempts');

  // Student Profile & Permissions Pop-out Modal Elements
  const studentProfileModal = document.getElementById('student-profile-modal');
  const btnCloseStudentModal = document.getElementById('btn-close-student-modal');
  const btnCloseStudentModalBottom = document.getElementById('btn-close-student-modal-bottom');
  const btnOpenAddModal = document.getElementById('btn-open-add-modal');
  const modalStudentAvatar = document.getElementById('modal-student-avatar');
  const modalStudentName = document.getElementById('modal-student-name');
  const modalStudentIdBadge = document.getElementById('modal-student-id-badge');
  const modalStudentEmailText = document.getElementById('modal-student-email-text');
  const modalStudentRegDate = document.getElementById('modal-student-reg-date');
  const modalPortalAccessSelect = document.getElementById('modal-portal-access-select');
  const modalQuizAccessSelect = document.getElementById('modal-quiz-access-select');
  const modalDeviceStatusBadge = document.getElementById('modal-device-status-badge');
  const btnModalResetDevice = document.getElementById('btn-modal-reset-device');
  const modalModulesSelectedCount = document.getElementById('modal-modules-selected-count');
  const btnSelectAllModules = document.getElementById('btn-select-all-modules');
  const btnSelectL4Only = document.getElementById('btn-select-l4-only');
  const btnClearAllModules = document.getElementById('btn-clear-all-modules');
  const btnModalCopyPass = document.getElementById('btn-modal-copy-pass');
  const btnModalDeleteStudent = document.getElementById('btn-modal-delete-student');

  // Confirmation Modal Elements
  const confirmModal = document.getElementById('confirm-action-modal');
  const btnCloseConfirmModal = document.getElementById('btn-close-confirm-modal');
  const btnCancelAction = document.getElementById('btn-cancel-action');
  const btnExecuteAction = document.getElementById('btn-execute-action');
  const confirmModalTitle = document.getElementById('confirm-modal-title');
  const confirmModalDesc = document.getElementById('confirm-modal-description');
  const confirmModalIconWrap = document.getElementById('confirm-modal-icon-wrap');
  const confirmModalIcon = document.getElementById('confirm-modal-icon');
  const confirmStudentAvatar = document.getElementById('confirm-student-avatar');
  const confirmStudentName = document.getElementById('confirm-student-name');
  const confirmStudentEmail = document.getElementById('confirm-student-email');
  const confirmStudentId = document.getElementById('confirm-student-id');
  const confirmWarningCallout = document.getElementById('confirm-warning-callout');
  const confirmWarningText = document.getElementById('confirm-warning-text');

  // Toast feedback elements
  const toastFeedback = document.getElementById('admin-toast-feedback');
  const toastIcon = document.getElementById('admin-toast-icon');
  const toastMsg = document.getElementById('admin-toast-msg');
  let toastTimer = null;

  function showToast(message, type = 'success') {
    if (!toastFeedback) return;
    if (toastTimer) clearTimeout(toastTimer);

    toastFeedback.className = 'admin-toast-notification active';
    if (type === 'danger') {
      toastFeedback.classList.add('toast-danger');
      if (toastIcon) toastIcon.textContent = '🗑️';
    } else if (type === 'warning') {
      toastFeedback.classList.add('toast-warning');
      if (toastIcon) toastIcon.textContent = '⚠️';
    } else {
      toastFeedback.classList.add('toast-success');
      if (toastIcon) toastIcon.textContent = '✓';
    }

    if (toastMsg) toastMsg.textContent = message;

    toastTimer = setTimeout(() => {
      toastFeedback.classList.remove('active');
    }, 3500);
  }

  let pendingActionCallback = null;

  function closeConfirmationModal() {
    if (confirmModal) {
      confirmModal.classList.remove('active');
    }
    pendingActionCallback = null;
  }

  function openConfirmationModal({
    title,
    description,
    icon = '⚠️',
    theme = 'amber',
    warningText,
    actionButtonText = 'Confirm',
    student,
    onConfirm
  }) {
    if (!confirmModal) return;

    if (confirmModalTitle) confirmModalTitle.textContent = title;
    if (confirmModalDesc) confirmModalDesc.textContent = description;
    if (confirmModalIcon) confirmModalIcon.textContent = icon;

    if (confirmModalIconWrap) {
      confirmModalIconWrap.className = `confirm-icon-box theme-${theme}`;
    }

    if (confirmWarningCallout) {
      confirmWarningCallout.className = `confirm-warning-box theme-${theme}`;
    }
    if (confirmWarningText) {
      confirmWarningText.textContent = warningText || 'Please verify the student details before proceeding.';
    }

    const sName = student ? (student.name || student.studentId || 'Student Record') : 'Student Record';
    const sEmail = student ? (student.email || '') : '';
    const sId = student ? (student.studentId || 'N/A') : '';
    const initials = student ? getInitials(student.name, student.studentId) : '--';

    if (confirmStudentAvatar) confirmStudentAvatar.textContent = initials;
    if (confirmStudentName) confirmStudentName.textContent = sName;
    if (confirmStudentEmail) confirmStudentEmail.textContent = sEmail;
    if (confirmStudentId) confirmStudentId.textContent = sId;

    if (btnExecuteAction) {
      btnExecuteAction.className = `btn confirm-action-btn theme-${theme}`;
      btnExecuteAction.textContent = actionButtonText;
    }

    pendingActionCallback = onConfirm;
    confirmModal.classList.add('active');
  }

  if (btnCloseConfirmModal) {
    btnCloseConfirmModal.addEventListener('click', closeConfirmationModal);
  }
  if (btnCancelAction) {
    btnCancelAction.addEventListener('click', closeConfirmationModal);
  }
  if (confirmModal) {
    confirmModal.addEventListener('click', (e) => {
      if (e.target === confirmModal) {
        closeConfirmationModal();
      }
    });
  }

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (confirmModal && confirmModal.classList.contains('active')) {
        closeConfirmationModal();
      } else if (studentProfileModal && studentProfileModal.classList.contains('active')) {
        closeStudentProfileModal();
      }
    }
  });

  // Student Profile Pop-out Modal Wire-up
  function closeStudentProfileModal() {
    if (studentProfileModal) {
      studentProfileModal.classList.remove('active');
    }
  }

  function updateSelectedModulesCount() {
    if (!modalModulesSelectedCount) return;
    const checked = document.querySelectorAll('#levels-checkbox-accordion .modules-checkbox-grid input[type="checkbox"]:checked');
    const total = document.querySelectorAll('#levels-checkbox-accordion .modules-checkbox-grid input[type="checkbox"]').length;
    modalModulesSelectedCount.textContent = `${checked.length} of ${total} Modules Selected`;
  }

  if (btnCloseStudentModal) {
    btnCloseStudentModal.addEventListener('click', closeStudentProfileModal);
  }
  if (btnCloseStudentModalBottom) {
    btnCloseStudentModalBottom.addEventListener('click', closeStudentProfileModal);
  }
  if (studentProfileModal) {
    studentProfileModal.addEventListener('click', (e) => {
      if (e.target === studentProfileModal) {
        closeStudentProfileModal();
      }
    });
  }
  if (btnOpenAddModal) {
    btnOpenAddModal.addEventListener('click', () => openStudentProfileModal(null));
  }

  if (btnModalCopyPass && editPassword) {
    btnModalCopyPass.addEventListener('click', () => {
      const pass = editPassword.value;
      if (pass) {
        navigator.clipboard.writeText(pass);
        showToast('Password copied to clipboard', 'success');
      }
    });
  }

  if (btnModalResetDevice) {
    btnModalResetDevice.addEventListener('click', async () => {
      if (!editingStudentEmail) {
        showToast('No active student selected', 'warning');
        return;
      }
      try {
        await apiConfig.approveDeviceLock(editingStudentEmail, null);
        if (modalDeviceStatusBadge) {
          modalDeviceStatusBadge.className = 'badge-status badge-unlocked';
          modalDeviceStatusBadge.textContent = 'UNLOCKED';
        }
        showToast(`Hardware device token reset for ${editingStudentEmail}.`, 'success');
        await loadStudentsList();
      } catch (err) {
        showToast(err.message || 'Failed to reset device token', 'danger');
      }
    });
  }

  if (btnSelectAllModules) {
    btnSelectAllModules.addEventListener('click', () => {
      document.querySelectorAll('#levels-checkbox-accordion input[type="checkbox"]').forEach(c => c.checked = true);
      updateSelectedModulesCount();
    });
  }

  if (btnSelectL4Only) {
    btnSelectL4Only.addEventListener('click', () => {
      document.querySelectorAll('#levels-checkbox-accordion input[type="checkbox"]').forEach(c => c.checked = false);
      const l4Master = document.getElementById('level-chk-4');
      if (l4Master) l4Master.checked = true;
      document.querySelectorAll('.mod-chk-lvl-4').forEach(c => c.checked = true);
      updateSelectedModulesCount();
    });
  }

  if (btnClearAllModules) {
    btnClearAllModules.addEventListener('click', () => {
      document.querySelectorAll('#levels-checkbox-accordion input[type="checkbox"]').forEach(c => c.checked = false);
      updateSelectedModulesCount();
    });
  }

  function triggerDeleteStudentConfirmation(student) {
    const attemptsCount = student ? (student.quizAttemptsCount || 0) : 0;
    openConfirmationModal({
      title: 'Permanently Delete Student Account',
      description: `Completely remove student account and all access records for ${student.name || student.email}.`,
      icon: '🗑️',
      theme: 'red',
      warningText: `CRITICAL: This action cannot be reversed! The student profile, login credentials, device bindings, and all ${attemptsCount} quiz attempt logs will be permanently erased from the database.`,
      actionButtonText: '🗑️ Permanently Delete Account',
      student: student,
      onConfirm: async () => {
        await apiConfig.deleteStudent(student.email);
        await loadStudentsList();
        showToast(`Student account permanently deleted: ${student.email}`, 'danger');
      }
    });
  }

  function triggerDeviceResetConfirmation(student) {
    if (!student) return;
    openConfirmationModal({
      title: 'Reset Hardware Device Lock',
      description: `Clear single-device hardware lock and allow new device authentication for ${student.name || student.email}.`,
      icon: '🔄',
      theme: 'amber',
      warningText: 'The active hardware binding token will be cleared. The student will be permitted to authenticate from a new computer, tablet, or browser on their next login session.',
      actionButtonText: '🔄 Confirm Device Reset',
      student: student,
      onConfirm: async () => {
        try {
          await apiConfig.approveDeviceLock(student.email, null);
          student.activeDeviceToken = null;
          student.activeDeviceInfo = null;
          student.isDeviceBlocked = false;
          showToast(`Hardware device lock reset for ${student.name || student.email}`, 'success');
          await loadStudentsList();
          const modalBadge = document.getElementById('modal-device-status-badge');
          if (modalBadge) {
            modalBadge.textContent = 'UNLOCKED';
            modalBadge.className = 'badge-status badge-unlocked';
          }
          const hint = document.getElementById('btn-popscreen-device-status-hint');
          if (hint) hint.textContent = 'Unlocked (Cleared)';
        } catch (err) {
          showToast('Failed to reset device lock: ' + err.message, 'danger');
        }
      }
    });
  }

  function updatePopscreenPortalBtn(student) {
    const btn = document.getElementById('btn-popscreen-toggle-portal');
    const icon = document.getElementById('btn-popscreen-portal-icon');
    const text = document.getElementById('btn-popscreen-portal-text');
    if (!btn || !student) return;
    if (student.accessStatus === 'DENIED') {
      btn.style.color = '#15803d';
      btn.style.borderColor = '#bbf7d0';
      btn.style.background = '#f0fdf4';
      if (icon) icon.textContent = '🔓';
      if (text) text.textContent = 'Unlock Portal';
    } else {
      btn.style.color = '#ea580c';
      btn.style.borderColor = '#fed7aa';
      btn.style.background = '#ffffff';
      if (icon) icon.textContent = '🔒';
      if (text) text.textContent = 'Lock Portal';
    }
  }

  function updatePopscreenQuizBtn(student) {
    const btn = document.getElementById('btn-popscreen-toggle-quiz');
    const icon = document.getElementById('btn-popscreen-quiz-icon');
    const text = document.getElementById('btn-popscreen-quiz-text');
    if (!btn || !student) return;
    if (student.quizAccessStatus === 'DENIED') {
      btn.style.color = '#0284c7';
      btn.style.borderColor = '#bae6fd';
      btn.style.background = '#f0f9ff';
      if (icon) icon.textContent = '✅';
      if (text) text.textContent = 'Enable Quiz';
    } else {
      btn.style.color = '#0369a1';
      btn.style.borderColor = '#bae6fd';
      btn.style.background = '#ffffff';
      if (icon) icon.textContent = '🚫';
      if (text) text.textContent = 'Deny Quiz';
    }
  }

  function triggerPortalToggleConfirmation(student) {
    if (!student) return;
    const isCurrentlyDenied = student.accessStatus === 'DENIED';
    if (isCurrentlyDenied) {
      openConfirmationModal({
        title: 'Enable Student Portal Access',
        description: `Restore login credentials and portal access for ${student.name || student.email}.`,
        icon: '✅',
        theme: 'green',
        warningText: 'The student will be allowed to log into the CIPS LMS portal using their password and access their approved qualification levels.',
        actionButtonText: '✅ Enable Portal Access',
        student: student,
        onConfirm: async () => {
          await apiConfig.toggleStudentAccess(student.email, 'ENABLED');
          student.accessStatus = 'ENABLED';
          if (modalPortalAccessSelect) modalPortalAccessSelect.value = 'ENABLED';
          updatePopscreenPortalBtn(student);
          await loadStudentsList();
          showToast(`Portal access enabled for ${student.name || student.email}`, 'success');
        }
      });
    } else {
      openConfirmationModal({
        title: 'Deny Student Portal Access',
        description: `Deactivate login permissions and suspend portal access for ${student.name || student.email}.`,
        icon: '🔒',
        theme: 'orange',
        warningText: 'The student will be immediately signed out from active browser sessions and barred from logging into the CIPS Portal. They will not be able to access notes or course materials.',
        actionButtonText: '🔒 Yes, Deny Portal Access',
        student: student,
        onConfirm: async () => {
          await apiConfig.toggleStudentAccess(student.email, 'DENIED');
          student.accessStatus = 'DENIED';
          if (modalPortalAccessSelect) modalPortalAccessSelect.value = 'DENIED';
          updatePopscreenPortalBtn(student);
          await loadStudentsList();
          showToast(`Portal access denied for ${student.name || student.email}`, 'warning');
        }
      });
    }
  }

  function triggerQuizToggleConfirmation(student) {
    if (!student) return;
    const isCurrentlyDenied = student.quizAccessStatus === 'DENIED';
    if (isCurrentlyDenied) {
      openConfirmationModal({
        title: 'Enable Quiz Engine Access',
        description: `Restore examination and quiz permissions for ${student.name || student.email}.`,
        icon: '✅',
        theme: 'green',
        warningText: 'The student will immediately regain access to start mock exams, practice tests, and receive automated scoring.',
        actionButtonText: '✅ Enable Quiz Access',
        student: student,
        onConfirm: async () => {
          await apiConfig.toggleStudentQuizAccess(student.email, 'ENABLED');
          student.quizAccessStatus = 'ENABLED';
          if (modalQuizAccessSelect) modalQuizAccessSelect.value = 'ENABLED';
          updatePopscreenQuizBtn(student);
          await loadStudentsList();
          showToast(`Quiz access enabled for ${student.name || student.email}`, 'success');
        }
      });
    } else {
      openConfirmationModal({
        title: 'Deny Quiz Engine Access',
        description: `Revoke examination and quiz permissions for ${student.name || student.email}.`,
        icon: '🚫',
        theme: 'amber',
        warningText: 'The student will be blocked from starting or submitting any mock exams, quizzes, or timed assessments across all CIPS qualification modules. Existing quiz score history is preserved.',
        actionButtonText: '🚫 Yes, Deny Quiz Access',
        student: student,
        onConfirm: async () => {
          await apiConfig.toggleStudentQuizAccess(student.email, 'DENIED');
          student.quizAccessStatus = 'DENIED';
          if (modalQuizAccessSelect) modalQuizAccessSelect.value = 'DENIED';
          updatePopscreenQuizBtn(student);
          await loadStudentsList();
          showToast(`Quiz access denied for ${student.name || student.email}`, 'warning');
        }
      });
    }
  }

  function openStudentProfileModal(student) {
    if (!studentProfileModal) return;

    const modalActionsCard = document.getElementById('modal-actions-card');
    const modalActionsBadge = document.getElementById('modal-actions-student-badge');
    const btnPopInvoice = document.getElementById('btn-popscreen-create-invoice');
    const btnPopTimeline = document.getElementById('btn-popscreen-open-timeline');
    const btnPopPortal = document.getElementById('btn-popscreen-toggle-portal');
    const btnPopResetDev = document.getElementById('btn-popscreen-reset-device');
    const btnPopQuiz = document.getElementById('btn-popscreen-toggle-quiz');
    const btnSecResetDevice = document.getElementById('btn-modal-reset-device');

    if (student) {
      // Pop-up Edit Screen with student's accurate data
      editingStudentEmail = student.email;
      if (modalActionsCard) modalActionsCard.style.display = 'block';
      if (modalActionsBadge) modalActionsBadge.textContent = student.studentId || 'STUDENT';

      // Connect Quick Actions inside the Popscreen
      if (btnPopInvoice) {
        btnPopInvoice.onclick = () => {
          closeStudentProfileModal();
          openInvoiceModal(student);
        };
      }

      if (btnPopTimeline) {
        btnPopTimeline.onclick = () => {
          closeStudentProfileModal();
          openStudentTimeline(student.email);
        };
      }

      updatePopscreenPortalBtn(student);
      if (btnPopPortal) {
        btnPopPortal.onclick = () => triggerPortalToggleConfirmation(student);
      }

      updatePopscreenQuizBtn(student);
      if (btnPopQuiz) {
        btnPopQuiz.onclick = () => triggerQuizToggleConfirmation(student);
      }

      const devHint = document.getElementById('btn-popscreen-device-status-hint');
      if (devHint) {
        if (student.isDeviceBlocked) {
          devHint.textContent = 'Device Blocked: Reset';
        } else if (student.activeDeviceToken) {
          devHint.textContent = 'Locked to Device: Reset';
        } else {
          devHint.textContent = 'Unlocked (No Token)';
        }
      }

      if (btnPopResetDev) {
        btnPopResetDev.onclick = () => triggerDeviceResetConfirmation(student);
      }
      if (btnSecResetDevice) {
        btnSecResetDevice.onclick = () => triggerDeviceResetConfirmation(student);
      }

      const initials = getInitials(student.name, student.studentId);
      if (modalStudentAvatar) modalStudentAvatar.textContent = initials;
      if (modalStudentName) modalStudentName.textContent = student.name || student.studentId;
      if (modalStudentIdBadge) modalStudentIdBadge.textContent = student.studentId;
      if (modalStudentEmailText) modalStudentEmailText.textContent = student.email;
      if (modalStudentRegDate) {
        const regDate = student.registeredAt ? new Date(student.registeredAt).toLocaleDateString() : '2026-01-15';
        modalStudentRegDate.textContent = `Registered ${regDate}`;
      }

      if (editStudentId) editStudentId.value = student.studentId;
      if (editEmail) {
        editEmail.value = student.email;
        editEmail.readOnly = true;
      }
      if (editName) editName.value = student.name || '';
      if (editPassword) editPassword.value = student.password || 'CIPS2026';

      if (modalPortalAccessSelect) {
        modalPortalAccessSelect.value = student.accessStatus || 'ENABLED';
      }
      if (modalQuizAccessSelect) {
        modalQuizAccessSelect.value = student.quizAccessStatus || 'ENABLED';
      }

      // Device status indicator
      if (modalDeviceStatusBadge) {
        if (student.isDeviceBlocked) {
          modalDeviceStatusBadge.className = 'badge-status badge-blocked';
          modalDeviceStatusBadge.textContent = 'BLOCKED (2ND DEVICE)';
        } else if (student.activeDeviceToken) {
          modalDeviceStatusBadge.className = 'badge-status badge-active-locked';
          modalDeviceStatusBadge.textContent = 'LOCKED TO DEVICE';
        } else {
          modalDeviceStatusBadge.className = 'badge-status badge-unlocked';
          modalDeviceStatusBadge.textContent = 'UNLOCKED';
        }
      }

      // Populate accurate module checkboxes
      document.querySelectorAll('#levels-checkbox-accordion input[type="checkbox"]').forEach(c => c.checked = false);
      const approvedMods = student.approvedModules || [];
      approvedMods.forEach(code => {
        const chk = document.querySelector(`#levels-checkbox-accordion input[value="${code}"]`);
        if (chk) chk.checked = true;
      });

      // Update level master checkboxes
      for (let lvl = 2; lvl <= 6; lvl++) {
        const levelKey = `level${lvl}`;
        const levelData = modulesDataSet ? modulesDataSet[levelKey] : null;
        if (levelData && levelData.modules) {
          const totalInLvl = levelData.modules.length;
          const checkedInLvl = levelData.modules.filter(m => approvedMods.includes(m.code)).length;
          const masterChk = document.getElementById(`level-chk-${lvl}`);
          if (masterChk) {
            masterChk.checked = (totalInLvl > 0 && totalInLvl === checkedInLvl);
          }
        }
      }

      if (btnModalDeleteStudent) {
        btnModalDeleteStudent.style.display = 'inline-flex';
        btnModalDeleteStudent.onclick = () => {
          closeStudentProfileModal();
          triggerDeleteStudentConfirmation(student);
        };
      }

      const btnModalTimeline = document.getElementById('btn-modal-open-timeline');
      const btnModalInvoice = document.getElementById('btn-modal-open-invoice');
      if (btnModalTimeline) {
        btnModalTimeline.style.display = 'inline-flex';
        btnModalTimeline.onclick = () => {
          closeStudentProfileModal();
          openStudentTimeline(student.email);
        };
      }
      if (btnModalInvoice) {
        btnModalInvoice.style.display = 'inline-flex';
        btnModalInvoice.onclick = () => {
          closeStudentProfileModal();
          openInvoiceModal(student);
        };
      }

    } else {
      // Add New Student Pop-up
      editingStudentEmail = null;
      if (modalActionsCard) modalActionsCard.style.display = 'none';
      const btnModalTimeline = document.getElementById('btn-modal-open-timeline');
      const btnModalInvoice = document.getElementById('btn-modal-open-invoice');
      if (btnModalTimeline) btnModalTimeline.style.display = 'none';
      if (btnModalInvoice) btnModalInvoice.style.display = 'none';
      if (modalStudentAvatar) modalStudentAvatar.textContent = '➕';
      if (modalStudentName) modalStudentName.textContent = 'Add New Student Record';
      if (modalStudentIdBadge) modalStudentIdBadge.textContent = 'NEW';
      if (modalStudentEmailText) modalStudentEmailText.textContent = 'Define login credentials & qualification module permissions';
      if (modalStudentRegDate) modalStudentRegDate.textContent = 'New Registration';

      if (editStudentId) editStudentId.value = '';
      if (editEmail) {
        editEmail.value = '';
        editEmail.readOnly = false;
      }
      if (editName) editName.value = '';
      if (editPassword) editPassword.value = 'CIPS2026';

      if (modalPortalAccessSelect) modalPortalAccessSelect.value = 'ENABLED';
      if (modalQuizAccessSelect) modalQuizAccessSelect.value = 'ENABLED';

      if (modalDeviceStatusBadge) {
        modalDeviceStatusBadge.className = 'badge-status badge-unlocked';
        modalDeviceStatusBadge.textContent = 'UNLOCKED';
      }

      // Default module selection for new student
      document.querySelectorAll('#levels-checkbox-accordion input[type="checkbox"]').forEach(c => c.checked = false);
      ['L2M1', 'L2M2', 'L2M3'].forEach(code => {
        const chk = document.querySelector(`#levels-checkbox-accordion input[value="${code}"]`);
        if (chk) chk.checked = true;
      });

      if (btnModalDeleteStudent) {
        btnModalDeleteStudent.style.display = 'none';
      }
    }

    updateSelectedModulesCount();
    studentProfileModal.classList.add('active');
  }

  if (btnExecuteAction) {
    btnExecuteAction.addEventListener('click', async () => {
      if (typeof pendingActionCallback === 'function') {
        const actionFn = pendingActionCallback;
        closeConfirmationModal();
        try {
          await actionFn();
        } catch (err) {
          console.error('Action execution failed:', err);
          showToast(err.message || 'Action failed to complete', 'danger');
        }
      } else {
        closeConfirmationModal();
      }
    });
  }

  let modulesDataSet = null;
  let allStudents = [];
  let editingStudentEmail = null;
  let currentSort = 'registered-desc';

  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      currentSort = e.target.value;
      renderStudentsTable();
    });
  }

  if (thStudentInfo) {
    thStudentInfo.addEventListener('click', () => {
      currentSort = currentSort === 'name-asc' ? 'name-desc' : 'name-asc';
      if (sortSelect) sortSelect.value = currentSort;
      renderStudentsTable();
    });
  }

  if (thRegisteredDate) {
    thRegisteredDate.addEventListener('click', () => {
      currentSort = currentSort === 'registered-desc' ? 'registered-asc' : 'registered-desc';
      if (sortSelect) sortSelect.value = currentSort;
      renderStudentsTable();
    });
  }

  if (thQuizAttempts) {
    thQuizAttempts.addEventListener('click', () => {
      currentSort = currentSort === 'attempts-desc' ? 'attempts-asc' : 'attempts-desc';
      if (sortSelect) sortSelect.value = currentSort;
      renderStudentsTable();
    });
  }

  if (btnTogglePassView && editPassword) {
    btnTogglePassView.addEventListener('click', () => {
      if (editPassword.type === 'password') {
        editPassword.type = 'text';
        btnTogglePassView.textContent = '🙈';
      } else {
        editPassword.type = 'password';
        btnTogglePassView.textContent = '👁️';
      }
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      renderStudentsTable();
    });
  }

  try {
    modulesDataSet = await apiConfig.getModulesData();
    renderLevelsAccordion();
    await loadStudentsList();
  } catch (e) {
    console.error('Initialization error:', e);
  }

  if (btnRefresh) {
    btnRefresh.addEventListener('click', () => loadStudentsList());
  }

  if (studentForm) {
    studentForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const studentId = editStudentId.value.trim();
      const email = editEmail.value.trim().toLowerCase();
      const name = editName.value.trim();
      const password = editPassword.value.trim();
      const accessStatus = modalPortalAccessSelect ? modalPortalAccessSelect.value : 'ENABLED';
      const quizAccessStatus = modalQuizAccessSelect ? modalQuizAccessSelect.value : 'ENABLED';

      // Collect checked levels and modules
      const selectedModules = [];
      const selectedLevels = new Set();

      for (let lvl = 2; lvl <= 6; lvl++) {
        const lvlCheck = document.getElementById(`level-chk-${lvl}`);
        if (lvlCheck && lvlCheck.checked) {
          selectedLevels.add(lvl);
        }

        const modChecks = document.querySelectorAll(`.mod-chk-lvl-${lvl}`);
        modChecks.forEach(chk => {
          if (chk.checked) {
            selectedModules.push(chk.value);
            selectedLevels.add(lvl);
          }
        });
      }

      try {
        await apiConfig.saveStudent({
          studentId,
          email,
          name,
          password: password || undefined,
          accessStatus,
          quizAccessStatus,
          approvedLevels: Array.from(selectedLevels),
          approvedModules: selectedModules
        });

        showToast(`Student record for ${name || email} saved successfully.`, 'success');
        closeStudentProfileModal();
        await loadStudentsList();
      } catch (err) {
        showToast(err.message || 'Error saving student', 'danger');
      }
    });
  }

  function renderLevelsAccordion() {
    if (!accordionContainer) return;
    accordionContainer.innerHTML = '';

    const levels = [
      { num: 2, name: 'Level 2 - Certificate in Procurement & Supply' },
      { num: 3, name: 'Level 3 - Advanced Certificate' },
      { num: 4, name: 'Level 4 - Diploma in Procurement & Supply' },
      { num: 5, name: 'Level 5 - Advanced Diploma' },
      { num: 6, name: 'Level 6 - Professional Diploma' }
    ];

    levels.forEach(lvl => {
      const levelKey = `level${lvl.num}`;
      const levelData = modulesDataSet ? modulesDataSet[levelKey] : null;
      const modules = levelData ? levelData.modules : [];

      const item = document.createElement('div');
      item.className = 'level-accordion-item';

      item.innerHTML = `
        <div class="level-header-row" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'grid' : 'none'">
          <label class="level-title-label" onclick="event.stopPropagation()">
            <input type="checkbox" id="level-chk-${lvl.num}" class="level-master-chk" data-lvl="${lvl.num}" />
            ${lvl.name}
          </label>
          <span style="font-size: 11px; color: var(--text-subtle); font-weight: 700;">${modules.length} Modules ▼</span>
        </div>
        <div class="modules-checkbox-grid" style="display: none;">
          ${modules.map(m => `
            <label class="checkbox-item">
              <input type="checkbox" value="${m.code}" class="mod-chk-lvl-${lvl.num}" />
              <strong>${m.code}</strong>: ${m.name}
            </label>
          `).join('')}
        </div>
      `;

      accordionContainer.appendChild(item);

      // Add Master Level Checkbox Toggle & Count Listener
      const masterChk = item.querySelector(`#level-chk-${lvl.num}`);
      const modChecks = item.querySelectorAll(`.mod-chk-lvl-${lvl.num}`);
      
      modChecks.forEach(chk => {
        chk.addEventListener('change', () => {
          const allCheckedInLvl = Array.from(modChecks).every(c => c.checked);
          if (masterChk) masterChk.checked = allCheckedInLvl;
          updateSelectedModulesCount();
        });
      });

      if (masterChk) {
        masterChk.addEventListener('change', (e) => {
          modChecks.forEach(c => c.checked = e.target.checked);
          updateSelectedModulesCount();
        });
      }
    });
  }

  async function loadStudentsList() {
    try {
      allStudents = await apiConfig.getAdminStudents();
      try {
        const quizRes = await fetch('/api/admin/quiz-results');
        if (quizRes.ok) {
          const qData = await quizRes.json();
          allQuizResults = Array.isArray(qData) ? qData : (qData.results || []);
        }
      } catch (err) {
        console.warn('Quiz results fetch notice:', err);
      }
      updateKpiStats();
      renderStudentsTable();
      await renderDeviceUnlockRequests();
    } catch (e) {
      if (tableBody) {
        tableBody.innerHTML = `<tr><td colspan="6" style="color: var(--cips-red); padding: 1rem;">Failed to load students: ${e.message}</td></tr>`;
      }
    }
  }

  function updateKpiStats() {
    const totalEl = document.getElementById('stat-total-students');
    const deviceEl = document.getElementById('stat-device-locked');
    const portalEl = document.getElementById('stat-portal-active');
    const quizEl = document.getElementById('stat-quiz-active');

    if (totalEl) totalEl.textContent = allStudents.length;
    if (deviceEl) {
      const lockedCount = allStudents.filter(s => s.activeDeviceToken || s.isDeviceBlocked).length;
      deviceEl.textContent = lockedCount;
    }
    if (portalEl) {
      const portalCount = allStudents.filter(s => s.accessStatus !== 'DENIED').length;
      portalEl.textContent = portalCount;
    }
    if (quizEl) {
      const quizCount = allStudents.filter(s => s.quizAccessStatus !== 'DENIED').length;
      quizEl.textContent = quizCount;
    }
  }

  function getInitials(name, fallback) {
    if (!name && !fallback) return 'ST';
    const source = (name || fallback || '').trim();
    const parts = source.split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return source.substring(0, 2).toUpperCase();
  }

  function formatRelativeTime(dateStr) {
    if (!dateStr) return 'Recently';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return 'Recently';
    const now = new Date();
    const diffSec = Math.floor((now.getTime() - d.getTime()) / 1000);
    if (diffSec < 60) return 'Just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
    if (diffSec < 86400 * 30) return `${Math.floor(diffSec / 86400)}d ago`;
    return d.toLocaleDateString();
  }

  function formatExactTime(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    return d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
  }

  async function openStudentTimeline(email) {
    const student = allStudents.find(s => s.email.toLowerCase() === email.toLowerCase());
    if (!student) return;

    activeTimelineStudentEmail = student.email;
    const modal = document.getElementById('student-timeline-modal');
    if (!modal) return;

    const avatarEl = document.getElementById('tl-modal-avatar');
    const nameEl = document.getElementById('tl-modal-student-name');
    const idEl = document.getElementById('tl-modal-student-id');
    const emailEl = document.getElementById('tl-modal-email');
    const regBadge = document.getElementById('tl-modal-reg-badge');
    const eventsCountEl = document.getElementById('tl-events-count');
    const container = document.getElementById('tl-events-container');

    const initials = getInitials(student.name, student.studentId);
    if (avatarEl) avatarEl.textContent = initials;
    if (nameEl) nameEl.textContent = student.name || student.studentId;
    if (idEl) idEl.textContent = student.studentId || 'STU';
    if (emailEl) emailEl.textContent = student.email;
    if (regBadge) {
      const regD = student.registeredAt ? new Date(student.registeredAt).toLocaleDateString() : 'Active';
      regBadge.textContent = `Enrolled: ${regD}`;
    }

    if (container) {
      container.innerHTML = `
        <div style="text-align:center; padding: 2.5rem; color: var(--text-muted);">
          <div class="sync-spinner" style="margin: 0 auto 0.75rem auto;"></div>
          <span>Loading student chronological events & activity log...</span>
        </div>
      `;
    }

    modal.classList.add('active');

    // Fetch invoices for this student
    let invoices = [];
    try {
      invoices = await apiConfig.getInvoices(student.email);
    } catch (e) {
      console.warn('Invoices fetch for timeline notice:', e);
    }

    // Filter quiz results for this student
    const studentQuizzes = (allQuizResults || []).filter(q => 
      (q.email && q.email.toLowerCase() === student.email.toLowerCase()) ||
      (q.studentId && student.studentId && q.studentId.toLowerCase() === student.studentId.toLowerCase())
    );

    const events = [];

    // 1. Registration Event
    const regTime = student.registeredAt || '2026-01-15T08:30:00.000Z';
    events.push({
      time: new Date(regTime).getTime(),
      dateStr: regTime,
      icon: '🎓',
      dotClass: 'dot-blue',
      title: 'Student Account Enrolled',
      desc: `Registered with CIPS Student ID ${student.studentId || 'Assigned'}. Approved for Level(s): ${(student.approvedLevels || []).map(l => 'L' + l).join(', ') || 'None'} with ${(student.approvedModules || []).length} modules authorized.`,
      badge: 'Account Created'
    });

    // 2. Hardware Device Lock & Binding
    if (student.activeDeviceToken || student.isDeviceBlocked || student.activeDeviceInfo) {
      const devTime = student.lastLoginAt || student.updatedAt || regTime;
      if (student.isDeviceBlocked) {
        events.push({
          time: new Date(devTime).getTime() + 1000,
          dateStr: devTime,
          icon: '⚠️',
          dotClass: 'dot-red',
          title: 'Unauthorized Device Blocked',
          desc: 'A secondary login was attempted from an unregistered browser or client device and immediately blocked by security policy.',
          badge: 'Security Alert'
        });
      } else if (student.activeDeviceToken) {
        events.push({
          time: new Date(devTime).getTime(),
          dateStr: devTime,
          icon: '🔒',
          dotClass: 'dot-amber',
          title: 'Hardware Device Lock Engaged',
          desc: `Device hardware fingerprint paired: ${student.activeDeviceInfo || 'Single Primary Workstation'}. Token: ${student.activeDeviceToken.substring(0, 16)}...`,
          badge: 'Device Locked'
        });
      }
    }

    // 3. Portal & Quiz Access Status
    if (student.accessStatus === 'DENIED') {
      events.push({
        time: Date.now() - 3600000,
        dateStr: new Date(Date.now() - 3600000).toISOString(),
        icon: '🚫',
        dotClass: 'dot-red',
        title: 'Portal Access Suspended',
        desc: 'Administrator locked portal access for this student account. Sign-in permissions are currently restricted.',
        badge: 'Portal Locked'
      });
    }

    if (student.quizAccessStatus === 'DENIED') {
      events.push({
        time: Date.now() - 7200000,
        dateStr: new Date(Date.now() - 7200000).toISOString(),
        icon: '🚫',
        dotClass: 'dot-amber',
        title: 'Quiz Engine Restricted',
        desc: 'Mock exam and test engine permissions have been set to Denied by administrator.',
        badge: 'Quiz Disabled'
      });
    }

    // 4. Invoices
    if (Array.isArray(invoices)) {
      invoices.forEach(inv => {
        const invTime = inv.createdAt || (inv.issueDate ? inv.issueDate + 'T12:00:00.000Z' : regTime);
        const curr = inv.currency === 'GBP' ? '£' : (inv.currency === 'EUR' ? '€' : '$');
        const itemsCount = (inv.lineItems || []).length;
        events.push({
          time: new Date(invTime).getTime(),
          dateStr: invTime,
          icon: '🧾',
          dotClass: inv.paymentStatus === 'PAID' ? 'dot-green' : 'dot-amber',
          title: `Invoice Generated: ${inv.invoiceNumber}`,
          desc: `Total: ${curr}${inv.totalAmount || inv.total || 0} &bull; Status: <strong>${inv.paymentStatus}</strong> &bull; Method: ${inv.paymentMethod || 'Bank Transfer'}. Invoiced for ${itemsCount} course & assessment items.`,
          badge: inv.paymentStatus === 'PAID' ? 'Paid' : 'Pending'
        });
      });
    }

    // 5. Quiz Assessment Results
    if (Array.isArray(studentQuizzes)) {
      studentQuizzes.forEach((q, idx) => {
        const qTime = q.completedAt || q.timestamp || q.createdAt || regTime;
        const score = q.score !== undefined ? q.score : (q.percentage || 0);
        const isPass = score >= (q.passMark || 70) || q.status === 'PASSED';
        events.push({
          time: new Date(qTime).getTime() + (idx * 500),
          dateStr: qTime,
          icon: isPass ? '🏆' : '📊',
          dotClass: isPass ? 'dot-green' : 'dot-purple',
          title: `Exam Attempt: ${q.moduleCode || q.moduleName || 'CIPS Assessment'}`,
          desc: `Result: <strong>${score}%</strong> (${isPass ? 'PASS' : 'REFERRAL'}) &bull; Attempt #${q.attemptNumber || idx + 1} &bull; Time: ${q.timeSpent || 'Timed'}.`,
          badge: isPass ? 'Pass' : 'Score Logged'
        });
      });
    }

    // Sort descending (latest first)
    events.sort((a, b) => b.time - a.time);

    if (eventsCountEl) eventsCountEl.textContent = `${events.length} Events`;

    if (container) {
      if (events.length === 0) {
        container.innerHTML = `
          <div style="text-align: center; color: var(--text-muted); padding: 3rem 1rem;">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">⏱️</div>
            <h4 style="font-size: 0.95rem; font-weight: 700; color: var(--cips-navy);">No Activity Events Yet</h4>
            <p style="font-size: 0.85rem; margin-top: 0.25rem;">This student account has not recorded any login attempts, invoices, or exams yet.</p>
          </div>
        `;
      } else {
        container.innerHTML = events.map(ev => `
          <div class="timeline-item">
            <div class="timeline-dot ${ev.dotClass}">
              <span>${ev.icon}</span>
            </div>
            <div class="timeline-content">
              <div class="timeline-header">
                <div class="timeline-title">
                  ${ev.title}
                  ${ev.badge ? `<span style="font-size: 10px; font-weight: 700; padding: 1px 6px; border-radius: 9999px; background: #e2e8f0; color: #334155; margin-left: 6px;">${ev.badge}</span>` : ''}
                </div>
                <div class="timeline-time" title="${formatExactTime(ev.dateStr)}">${formatRelativeTime(ev.dateStr)}</div>
              </div>
              <div class="timeline-desc">${ev.desc}</div>
              <div class="timeline-exact-date">📅 ${formatExactTime(ev.dateStr)}</div>
            </div>
          </div>
        `).join('');
      }
    }
  }

  function closeStudentTimeline() {
    const modal = document.getElementById('student-timeline-modal');
    if (modal) modal.classList.remove('active');
    activeTimelineStudentEmail = null;
  }

  function renderStudentsTable() {
    if (!tableBody) return;

    let filtered = [...allStudents];
    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    if (query) {
      filtered = filtered.filter(s => 
        (s.name && s.name.toLowerCase().includes(query)) ||
        (s.email && s.email.toLowerCase().includes(query)) ||
        (s.studentId && s.studentId.toLowerCase().includes(query))
      );
    }

    // Sort students array based on selected currentSort option
    filtered.sort((a, b) => {
      if (currentSort === 'registered-desc') {
        return new Date(b.registeredAt || 0).getTime() - new Date(a.registeredAt || 0).getTime();
      } else if (currentSort === 'registered-asc') {
        return new Date(a.registeredAt || 0).getTime() - new Date(b.registeredAt || 0).getTime();
      } else if (currentSort === 'name-asc') {
        return (a.name || a.studentId || '').localeCompare(b.name || b.studentId || '');
      } else if (currentSort === 'name-desc') {
        return (b.name || b.studentId || '').localeCompare(a.name || a.studentId || '');
      } else if (currentSort === 'email-asc') {
        return (a.email || '').localeCompare(b.email || '');
      } else if (currentSort === 'attempts-desc') {
        return (b.quizAttemptsCount || 0) - (a.quizAttemptsCount || 0);
      } else if (currentSort === 'attempts-asc') {
        return (a.quizAttemptsCount || 0) - (b.quizAttemptsCount || 0);
      }
      return 0;
    });

    if (filtered.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2.5rem;">No matching student records found.</td></tr>`;
      return;
    }

    tableBody.innerHTML = filtered.map(s => {
      let deviceStatusBadge = `<span class="badge-status badge-unlocked">UNLOCKED</span>`;
      if (s.isDeviceBlocked) {
        deviceStatusBadge = `<span class="badge-status badge-blocked">BLOCKED (2ND DEVICE)</span>`;
      } else if (s.activeDeviceToken) {
        deviceStatusBadge = `<span class="badge-status badge-active-locked">LOCKED TO DEVICE</span>`;
      }

      const portalAccessBadge = (s.accessStatus === 'DENIED')
        ? `<span class="badge-status badge-blocked" style="background:#fee2e2; color:#b91c1c;">DENIED</span>`
        : `<span class="badge-status" style="background:#dcfce7; color:#15803d;">ENABLED</span>`;

      const quizAccessBadge = (s.quizAccessStatus === 'DENIED')
        ? `<span class="badge-status badge-blocked" style="background:#fef3c7; color:#92400e;">QUIZ DENIED</span>`
        : `<span class="badge-status" style="background:#e0f2fe; color:#0369a1;">QUIZ ALLOWED</span>`;

      const levelsText = (s.approvedLevels || []).map(l => `L${l}`).join(', ') || 'None';
      const registeredDate = s.registeredAt ? new Date(s.registeredAt).toLocaleDateString() : '2026-01-15';
      const attemptsDisplay = `${s.quizAttemptsCount || 0} Attempts`;
      const initials = getInitials(s.name, s.studentId);

      return `
        <tr class="student-table-row" data-email="${s.email}" style="cursor: pointer;" title="Click row to open Student Profile &amp; Actions">
          <td class="student-cell-clickable" data-email="${s.email}">
            <div class="student-profile-trigger">
              <div class="student-avatar interactive-avatar">${initials}</div>
              <div style="flex: 1; min-width: 0;">
                <div style="display: flex; align-items: center; gap: 0.4rem;">
                  <span class="student-name-text">${s.name || s.studentId}</span>
                  <span class="student-edit-hint">⚡ Manage</span>
                </div>
                <div style="font-size: 0.8rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.4rem; margin-top: 1px;">
                  <span>${s.email}</span> &bull; 
                  <span style="font-family: var(--font-mono); font-size: 11px; background: #eef2ff; color: #4338ca; padding: 1px 5px; border-radius: 4px; font-weight: 700;">${s.studentId}</span>
                </div>
                <div style="font-size: 0.775rem; color: #64748b; margin-top: 3px; display: flex; align-items: center; gap: 0.4rem;">
                  <span>Pass:</span>
                  <code style="font-family: var(--font-mono); background:#f1f5f9; padding: 1px 5px; border-radius: 4px; font-size: 11px; font-weight: 600;">${s.password || '••••••••'}</code>
                  ${s.password ? `<button type="button" class="btn-copy-pass" data-pass="${s.password}" title="Copy password">📋 Copy</button>` : ''}
                </div>
              </div>
            </div>
          </td>
          <td style="font-size: 0.825rem; color: var(--text-muted); font-weight: 600;">${registeredDate}</td>
          <td>
            <span style="font-weight: 800; color: var(--cips-navy); font-size: 0.85rem;">📊 ${attemptsDisplay}</span>
          </td>
          <td>
            <div style="margin-bottom: 4px;">${portalAccessBadge}</div>
            <div>${deviceStatusBadge}</div>
          </td>
          <td>
            <div>${quizAccessBadge}</div>
          </td>
          <td>
            <span style="font-size: 0.825rem; font-weight: 800; color: var(--cips-accent);">${levelsText}</span>
            <div style="font-size: 11px; color: var(--text-subtle);">${(s.approvedModules || []).length} Modules</div>
          </td>
        </tr>
      `;
    }).join('');

    // Attach row copy password handler
    document.querySelectorAll('.btn-copy-pass').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const pass = e.currentTarget.getAttribute('data-pass');
        if (pass) {
          navigator.clipboard.writeText(pass);
          const originalText = e.currentTarget.textContent;
          e.currentTarget.textContent = '✓ Copied';
          e.currentTarget.style.color = '#059669';
          setTimeout(() => {
            e.currentTarget.textContent = originalText;
            e.currentTarget.style.color = '';
          }, 1800);
        }
      });
    });

    // Clicking anywhere on a student row opens the Popscreen (Student Profile Modal)
    document.querySelectorAll('.student-table-row').forEach(row => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('.btn-copy-pass')) return;
        const email = row.getAttribute('data-email');
        const student = allStudents.find(s => s.email.toLowerCase() === email.toLowerCase());
        if (student) {
          openStudentProfileModal(student);
        }
      });
    });
  }

  async function renderDeviceUnlockRequests() {
    if (!deviceUnlockContainer) return;

    try {
      const alertsData = await apiConfig.getAdminAlerts();
      const blockedEvents = (alertsData.deviceEvents || []).filter(e => e.status === 'BLOCKED');

      if (blockedEvents.length === 0) {
        deviceUnlockContainer.innerHTML = `<p style="color: var(--text-muted); font-size: 0.875rem;">No active device block requests.</p>`;
        return;
      }

      deviceUnlockContainer.innerHTML = blockedEvents.map(evt => `
        <div style="background: var(--cips-amber-bg); border: 1px solid var(--cips-amber-border); border-radius: var(--radius-sm); padding: 0.85rem; margin-bottom: 0.75rem; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <div style="font-weight: 800; color: var(--cips-amber); font-size: 0.875rem;">⚠️ Device Conflict: ${evt.studentEmail}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">
              Attempted: <strong>${evt.attemptedDeviceInfo || 'Unknown'}</strong> at ${new Date(evt.timestamp).toLocaleString()}
            </div>
          </div>
          <button class="btn btn-primary btn-action-sm btn-approve-unlock" data-email="${evt.studentEmail}" data-evt="${evt.id}">
            Approve &amp; Unlock
          </button>
        </div>
      `).join('');

      document.querySelectorAll('.btn-approve-unlock').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          const email = e.currentTarget.getAttribute('data-email');
          const evtId = e.currentTarget.getAttribute('data-evt');
          await apiConfig.approveDeviceLock(email, evtId);
          showToast(`Device access approved for ${email}.`, 'success');
          await loadStudentsList();
        });
      });
    } catch (e) {
      console.warn('Error rendering unlock requests:', e);
    }
  }

  // =========================================================
  // STUDENT INVOICE CREATOR & FEE RECEIPT MANAGEMENT
  // =========================================================
  const invoiceModal = document.getElementById('invoice-modal');
  const btnCloseInvoiceModal = document.getElementById('btn-close-invoice-modal');
  const btnInvCancel = document.getElementById('btn-inv-cancel');
  const btnInvPrint = document.getElementById('btn-inv-print');
  const btnInvDownloadPdf = document.getElementById('btn-inv-download-pdf');
  const btnInvSave = document.getElementById('btn-inv-save');

  const invStudentName = document.getElementById('inv-student-name');
  const invStudentEmail = document.getElementById('inv-student-email');
  const invStudentId = document.getElementById('inv-student-id');
  const invHeaderStatusPill = document.getElementById('inv-header-status-pill');

  const invNumberInput = document.getElementById('inv-number-input');
  const btnInvRandomizeNum = document.getElementById('btn-inv-randomize-num');
  const invIssueDate = document.getElementById('inv-issue-date');
  const invStatusSelect = document.getElementById('inv-status-select');
  const invPaymentMethodSelect = document.getElementById('inv-payment-method-select');
  const invCurrencySelect = document.getElementById('inv-currency-select');
  const invTxnRef = document.getElementById('inv-txn-ref');

  const invLevelSelect = document.getElementById('inv-level-select');
  const invModuleUnitPrice = document.getElementById('inv-module-unit-price');
  const btnInvAddL44Mods = document.getElementById('btn-inv-add-l4-4mods');
  const btnInvAddAllLevel = document.getElementById('btn-inv-add-all-level');
  const btnInvAddCheckedMods = document.getElementById('btn-inv-add-checked-mods');
  const invModulesGrid = document.getElementById('inv-modules-grid');

  const btnInvAddQuizAccess = document.getElementById('btn-inv-add-quiz-access');
  const btnInvAddQuizExtra5 = document.getElementById('btn-inv-add-quiz-extra5');
  const btnInvAddQuizExtra10 = document.getElementById('btn-inv-add-quiz-extra10');
  const btnInvAddQuizSingle = document.getElementById('btn-inv-add-quiz-single');

  const invCustomDesc = document.getElementById('inv-custom-desc');
  const invCustomCode = document.getElementById('inv-custom-code');
  const invCustomQty = document.getElementById('inv-custom-qty');
  const invCustomPrice = document.getElementById('inv-custom-price');
  const btnInvAddCustomItem = document.getElementById('btn-inv-add-custom-item');

  const invItemsTableBody = document.getElementById('inv-items-table-body');
  const invEmptyState = document.getElementById('inv-empty-state');
  const invItemsCount = document.getElementById('inv-items-count');
  const btnInvClearAllItems = document.getElementById('btn-inv-clear-all-items');

  const invNotesInput = document.getElementById('inv-notes-input');
  const invAutoApplyCheck = document.getElementById('inv-auto-apply-check');

  const invSubtotalVal = document.getElementById('inv-subtotal-val');
  const invDiscountInput = document.getElementById('inv-discount-input');
  const invDiscountVal = document.getElementById('inv-discount-val');
  const invTaxInput = document.getElementById('inv-tax-input');
  const invTaxVal = document.getElementById('inv-tax-val');
  const invGrandTotalVal = document.getElementById('inv-grand-total-val');
  const invAmountPaidInput = document.getElementById('inv-amount-paid-input');
  const invAmountPaidVal = document.getElementById('inv-amount-paid-val');
  const invBalanceVal = document.getElementById('inv-balance-val');

  const btnToggleInvHistory = document.getElementById('btn-toggle-inv-history');
  const invHistoryContainer = document.getElementById('inv-history-container');
  const invHistoryList = document.getElementById('inv-history-list');
  const invHistoryCountBadge = document.getElementById('inv-history-count-badge');
  const invHistoryChevron = document.getElementById('inv-history-chevron');

  let activeInvoiceStudent = null;
  let invoiceLineItems = [];
  let currentStudentInvoices = [];

  function getSelectedCurrencyInfo() {
    const sel = invCurrencySelect;
    const code = sel ? sel.value : 'USD';
    const opt = sel ? sel.options[sel.selectedIndex] : null;
    const sym = (opt && opt.getAttribute('data-sym')) || '$';
    return { code, sym };
  }

  function formatMoney(amount) {
    const { sym } = getSelectedCurrencyInfo();
    const num = (typeof amount === 'number' && !isNaN(amount)) ? amount : 0;
    return `${sym}${num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }

  function updateCurrencySymbolsOnUI() {
    const { sym } = getSelectedCurrencyInfo();
    document.querySelectorAll('.inv-cur-symbol').forEach(el => {
      el.textContent = sym;
    });
    recalculateInvoiceTotals();
  }

  if (invCurrencySelect) {
    invCurrencySelect.addEventListener('change', () => {
      updateCurrencySymbolsOnUI();
    });
  }

  function renderInvoiceModulePicker(levelNum) {
    if (!invModulesGrid) return;
    const levelKey = `level${levelNum}`;
    const levelData = modulesDataSet ? modulesDataSet[levelKey] : null;
    const modules = (levelData && levelData.modules) || [];

    if (modules.length === 0) {
      invModulesGrid.innerHTML = `<div style="grid-column: 1/-1; color: var(--text-muted); font-size: 0.85rem; padding: 0.5rem;">No syllabus modules found for Level ${levelNum}</div>`;
      return;
    }

    invModulesGrid.innerHTML = modules.map(m => {
      const isAlreadyInInvoice = invoiceLineItems.some(item => item.code === m.code);
      return `
        <label class="inv-mod-item-label" title="${m.title}">
          <input type="checkbox" class="inv-mod-grid-chk" value="${m.code}" data-title="${m.title}" data-level="${levelNum}" ${isAlreadyInInvoice ? 'checked' : ''} />
          <div>
            <div style="font-weight: 700; color: var(--cips-navy); font-size: 0.8rem; display: flex; align-items: center; gap: 4px;">
              <span class="inv-id-badge">${m.code}</span>
              <span style="font-size: 10px; color: var(--text-muted);">${m.type || 'Core'}</span>
            </div>
            <div style="font-size: 0.75rem; color: var(--text-main); margin-top: 2px; line-height: 1.25; max-height: 2.5em; overflow: hidden; text-overflow: ellipsis;">
              ${m.title}
            </div>
          </div>
        </label>
      `;
    }).join('');
  }

  if (invLevelSelect) {
    invLevelSelect.addEventListener('change', (e) => {
      const lvl = parseInt(e.target.value) || 4;
      renderInvoiceModulePicker(lvl);
    });
  }

  // Quick Action: + 4 Modules in Level 4 (Prompt: "Suppose a student only pays for 4 module in Level4, so that I can customize that.")
  if (btnInvAddL44Mods) {
    btnInvAddL44Mods.addEventListener('click', () => {
      const unitPrice = parseFloat(invModuleUnitPrice ? invModuleUnitPrice.value : 150) || 150;
      const l4Mods = [
        { code: 'L4M1', title: 'Scope and Influence of Procurement and Supply' },
        { code: 'L4M2', title: 'Defining Business Needs' },
        { code: 'L4M3', title: 'Commercial Contracting' },
        { code: 'L4M4', title: 'Ethical and Responsible Sourcing' }
      ];

      let addedCount = 0;
      l4Mods.forEach(m => {
        const existing = invoiceLineItems.find(it => it.code === m.code);
        if (!existing) {
          invoiceLineItems.push({
            id: 'mod_' + m.code + '_' + Date.now() + Math.random().toString(36).substr(2, 4),
            code: m.code,
            description: `CIPS Level 4 Module: ${m.code} ${m.title}`,
            type: 'COURSE_MODULE',
            level: 4,
            quantity: 1,
            unitPrice: unitPrice,
            lineTotal: unitPrice,
            extraAttempts: 0
          });
          addedCount++;
        }
      });

      renderInvoiceItemsTable();
      recalculateInvoiceTotals();
      if (invLevelSelect) renderInvoiceModulePicker(parseInt(invLevelSelect.value) || 4);
      showToast(`Added 4 Core Level 4 Modules (L4M1-L4M4) to invoice.`, 'success');
    });
  }

  // Quick Action: Add all modules in the selected level
  if (btnInvAddAllLevel) {
    btnInvAddAllLevel.addEventListener('click', () => {
      const lvl = invLevelSelect ? parseInt(invLevelSelect.value) : 4;
      const levelKey = `level${lvl}`;
      const modules = (modulesDataSet && modulesDataSet[levelKey] && modulesDataSet[levelKey].modules) || [];
      const unitPrice = parseFloat(invModuleUnitPrice ? invModuleUnitPrice.value : 150) || 150;

      let added = 0;
      modules.forEach(m => {
        if (!invoiceLineItems.some(it => it.code === m.code)) {
          invoiceLineItems.push({
            id: 'mod_' + m.code + '_' + Date.now() + Math.random().toString(36).substr(2, 4),
            code: m.code,
            description: `CIPS Level ${lvl} Module: ${m.code} ${m.title}`,
            type: 'COURSE_MODULE',
            level: lvl,
            quantity: 1,
            unitPrice: unitPrice,
            lineTotal: unitPrice,
            extraAttempts: 0
          });
          added++;
        }
      });

      renderInvoiceItemsTable();
      recalculateInvoiceTotals();
      renderInvoiceModulePicker(lvl);
      showToast(`Added all Level ${lvl} modules to invoice (${added} added).`, 'success');
    });
  }

  // Quick Action: Add checked modules in the grid
  if (btnInvAddCheckedMods) {
    btnInvAddCheckedMods.addEventListener('click', () => {
      const checkboxes = document.querySelectorAll('.inv-mod-grid-chk:checked');
      const unitPrice = parseFloat(invModuleUnitPrice ? invModuleUnitPrice.value : 150) || 150;
      let added = 0;

      checkboxes.forEach(chk => {
        const code = chk.value;
        const title = chk.getAttribute('data-title') || '';
        const level = chk.getAttribute('data-level') || '4';

        if (!invoiceLineItems.some(it => it.code === code)) {
          invoiceLineItems.push({
            id: 'mod_' + code + '_' + Date.now() + Math.random().toString(36).substr(2, 4),
            code: code,
            description: `CIPS Level ${level} Module: ${code} ${title}`,
            type: 'COURSE_MODULE',
            level: parseInt(level),
            quantity: 1,
            unitPrice: unitPrice,
            lineTotal: unitPrice,
            extraAttempts: 0
          });
          added++;
        }
      });

      renderInvoiceItemsTable();
      recalculateInvoiceTotals();
      showToast(`Added ${added} selected module(s) to invoice.`, 'success');
    });
  }

  // Quiz Add-on Presets (Prompt: "if a student pays for quiz or additional quiz I can make the invoice.")
  function addQuizFeeItem(code, description, price, extraAttempts = 0) {
    const existing = invoiceLineItems.find(it => it.code === code);
    if (existing) {
      existing.quantity += 1;
      existing.lineTotal = existing.quantity * existing.unitPrice;
      showToast(`Incremented quantity for ${code}.`, 'info');
    } else {
      invoiceLineItems.push({
        id: 'quiz_' + code + '_' + Date.now() + Math.random().toString(36).substr(2, 4),
        code: code,
        description: description,
        type: extraAttempts > 0 ? 'ADDITIONAL_QUIZ' : 'QUIZ_ACCESS',
        level: null,
        quantity: 1,
        unitPrice: price,
        lineTotal: price,
        extraAttempts: extraAttempts
      });
      showToast(`Added ${description.slice(0, 35)}...`, 'success');
    }
    renderInvoiceItemsTable();
    recalculateInvoiceTotals();
  }

  if (btnInvAddQuizAccess) {
    btnInvAddQuizAccess.addEventListener('click', () => {
      addQuizFeeItem('QUIZ_ACCESS', 'CIPS Objective Response Exam Quiz Access Engine (Full 60 Questions Bank & Mock Engine)', 50, 0);
    });
  }

  if (btnInvAddQuizExtra5) {
    btnInvAddQuizExtra5.addEventListener('click', () => {
      addQuizFeeItem('ADD_QUIZ_5', 'Additional Exam Quiz Attempts Pack (+5 Attempts)', 30, 5);
    });
  }

  if (btnInvAddQuizExtra10) {
    btnInvAddQuizExtra10.addEventListener('click', () => {
      addQuizFeeItem('ADD_QUIZ_10', 'Additional Exam Quiz Attempts Pack (+10 Attempts)', 50, 10);
    });
  }

  if (btnInvAddQuizSingle) {
    btnInvAddQuizSingle.addEventListener('click', () => {
      addQuizFeeItem('ADD_QUIZ_1', 'Single Additional Exam Quiz Attempt (+1 Attempt)', 10, 1);
    });
  }

  // Custom line item addition
  if (btnInvAddCustomItem) {
    btnInvAddCustomItem.addEventListener('click', () => {
      const desc = invCustomDesc ? invCustomDesc.value.trim() : '';
      const code = (invCustomCode ? invCustomCode.value.trim() : '') || 'CUSTOM';
      const qty = parseInt(invCustomQty ? invCustomQty.value : 1) || 1;
      const price = parseFloat(invCustomPrice ? invCustomPrice.value : 0) || 0;

      if (!desc) {
        showToast('Please enter an item description.', 'warning');
        return;
      }

      invoiceLineItems.push({
        id: 'custom_' + Date.now() + Math.random().toString(36).substr(2, 4),
        code: code.toUpperCase(),
        description: desc,
        type: 'CUSTOM',
        level: null,
        quantity: qty,
        unitPrice: price,
        lineTotal: qty * price,
        extraAttempts: 0
      });

      if (invCustomDesc) invCustomDesc.value = '';
      if (invCustomCode) invCustomCode.value = '';
      if (invCustomQty) invCustomQty.value = '1';
      if (invCustomPrice) invCustomPrice.value = '';

      renderInvoiceItemsTable();
      recalculateInvoiceTotals();
      showToast('Custom item added to invoice.', 'success');
    });
  }

  if (btnInvClearAllItems) {
    btnInvClearAllItems.addEventListener('click', () => {
      invoiceLineItems = [];
      renderInvoiceItemsTable();
      recalculateInvoiceTotals();
      if (invLevelSelect) renderInvoiceModulePicker(parseInt(invLevelSelect.value) || 4);
    });
  }

  // Line items table renderer
  function renderInvoiceItemsTable() {
    if (!invItemsTableBody) return;
    if (invItemsCount) invItemsCount.textContent = invoiceLineItems.length;

    if (invoiceLineItems.length === 0) {
      invItemsTableBody.innerHTML = '';
      if (invEmptyState) invEmptyState.style.display = 'block';
      return;
    }

    if (invEmptyState) invEmptyState.style.display = 'none';

    const { sym } = getSelectedCurrencyInfo();

    invItemsTableBody.innerHTML = invoiceLineItems.map((item, idx) => `
      <tr data-id="${item.id}">
        <td style="color: var(--text-muted); font-size: 0.8rem; font-family: var(--font-mono);">${idx + 1}</td>
        <td>
          <div style="font-weight: 700; color: var(--text-main); font-size: 0.85rem;">${item.description}</div>
        </td>
        <td>
          <span class="inv-id-badge">${item.code}</span>
        </td>
        <td style="text-align: center;">
          <input type="number" class="form-input item-qty-input" data-id="${item.id}" value="${item.quantity}" min="1" max="99" style="width: 55px; padding: 2px 4px; text-align: center; font-size: 0.8rem;" />
        </td>
        <td style="text-align: right;">
          <div style="display: flex; align-items: center; justify-content: flex-end; gap: 2px;">
            <span style="font-size: 0.75rem; color: var(--text-muted);">${sym}</span>
            <input type="number" class="form-input item-price-input" data-id="${item.id}" value="${item.unitPrice}" min="0" step="5" style="width: 75px; padding: 2px 4px; text-align: right; font-size: 0.8rem;" />
          </div>
        </td>
        <td style="text-align: right; font-weight: 700; font-family: var(--font-mono); color: var(--cips-navy);">
          ${formatMoney(item.quantity * item.unitPrice)}
        </td>
        <td style="text-align: center;">
          <button type="button" class="btn-inv-remove-item" data-id="${item.id}" style="background: transparent; border: none; color: #dc2626; cursor: pointer; font-size: 1rem;" title="Remove this item">
            🗑️
          </button>
        </td>
      </tr>
    `).join('');

    // Attach listeners to line items
    document.querySelectorAll('.item-qty-input').forEach(inp => {
      inp.addEventListener('input', (e) => {
        const id = e.target.getAttribute('data-id');
        const it = invoiceLineItems.find(x => x.id === id);
        if (it) {
          it.quantity = Math.max(1, parseInt(e.target.value) || 1);
          it.lineTotal = it.quantity * it.unitPrice;
          recalculateInvoiceTotals();
          const tr = e.target.closest('tr');
          if (tr) {
            const totalTd = tr.querySelector('td:nth-child(6)');
            if (totalTd) totalTd.textContent = formatMoney(it.lineTotal);
          }
        }
      });
    });

    document.querySelectorAll('.item-price-input').forEach(inp => {
      inp.addEventListener('input', (e) => {
        const id = e.target.getAttribute('data-id');
        const it = invoiceLineItems.find(x => x.id === id);
        if (it) {
          it.unitPrice = Math.max(0, parseFloat(e.target.value) || 0);
          it.lineTotal = it.quantity * it.unitPrice;
          recalculateInvoiceTotals();
          const tr = e.target.closest('tr');
          if (tr) {
            const totalTd = tr.querySelector('td:nth-child(6)');
            if (totalTd) totalTd.textContent = formatMoney(it.lineTotal);
          }
        }
      });
    });

    document.querySelectorAll('.btn-inv-remove-item').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        invoiceLineItems = invoiceLineItems.filter(x => x.id !== id);
        renderInvoiceItemsTable();
        recalculateInvoiceTotals();
        if (invLevelSelect) renderInvoiceModulePicker(parseInt(invLevelSelect.value) || 4);
      });
    });
  }

  // Financial calculations
  function recalculateInvoiceTotals() {
    const subtotal = invoiceLineItems.reduce((acc, it) => acc + (it.quantity * it.unitPrice), 0);
    const discount = Math.max(0, parseFloat(invDiscountInput ? invDiscountInput.value : 0) || 0);
    const taxRate = Math.max(0, parseFloat(invTaxInput ? invTaxInput.value : 0) || 0);
    const taxableAmount = Math.max(0, subtotal - discount);
    const tax = taxableAmount * (taxRate / 100);
    const grandTotal = Math.max(0, taxableAmount + tax);

    if (invSubtotalVal) invSubtotalVal.textContent = formatMoney(subtotal);
    if (invDiscountVal) invDiscountVal.textContent = `-${formatMoney(discount)}`;
    if (invTaxVal) invTaxVal.textContent = formatMoney(tax);
    if (invGrandTotalVal) invGrandTotalVal.textContent = formatMoney(grandTotal);

    // Auto update amount paid if status is PAID
    const status = invStatusSelect ? invStatusSelect.value : 'PAID';
    if (status === 'PAID') {
      if (invAmountPaidInput) invAmountPaidInput.value = grandTotal.toFixed(2);
      if (invHeaderStatusPill) {
        invHeaderStatusPill.className = 'inv-status-pill status-paid';
        invHeaderStatusPill.textContent = 'PAID (FULL)';
      }
    } else if (status === 'PARTIALLY_PAID') {
      if (invHeaderStatusPill) {
        invHeaderStatusPill.className = 'inv-status-pill status-partial';
        invHeaderStatusPill.textContent = 'PARTIALLY PAID';
      }
    } else {
      if (invHeaderStatusPill) {
        invHeaderStatusPill.className = 'inv-status-pill status-pending';
        invHeaderStatusPill.textContent = status;
      }
    }

    const amountPaid = parseFloat(invAmountPaidInput ? invAmountPaidInput.value : 0) || 0;
    if (invAmountPaidVal) invAmountPaidVal.textContent = formatMoney(amountPaid);

    const balanceDue = Math.max(0, grandTotal - amountPaid);
    if (invBalanceVal) {
      invBalanceVal.textContent = formatMoney(balanceDue);
      if (balanceDue === 0) {
        invBalanceVal.style.color = '#059669';
      } else {
        invBalanceVal.style.color = '#b91c1c';
      }
    }
  }

  if (invDiscountInput) invDiscountInput.addEventListener('input', recalculateInvoiceTotals);
  if (invTaxInput) invTaxInput.addEventListener('input', recalculateInvoiceTotals);
  if (invAmountPaidInput) invAmountPaidInput.addEventListener('input', recalculateInvoiceTotals);
  if (invStatusSelect) invStatusSelect.addEventListener('change', recalculateInvoiceTotals);

  if (btnInvRandomizeNum) {
    btnInvRandomizeNum.addEventListener('click', () => {
      const rnd = Math.floor(1000 + Math.random() * 9000);
      if (invNumberInput) invNumberInput.value = `INV-2026-${rnd}`;
    });
  }

  // Open Invoice Modal
  function openInvoiceModal(student) {
    if (!invoiceModal || !student) return;
    activeInvoiceStudent = student;

    // Student identity
    if (invStudentName) invStudentName.textContent = student.name || student.studentId;
    if (invStudentEmail) invStudentEmail.textContent = student.email;
    if (invStudentId) invStudentId.textContent = student.studentId || 'STU';

    // Generate Invoice Number
    const rnd = Math.floor(1000 + Math.random() * 9000);
    if (invNumberInput) invNumberInput.value = `INV-2026-${rnd}`;

    // Dates
    const today = new Date().toISOString().split('T')[0];
    if (invIssueDate) invIssueDate.value = today;

    // Defaults
    if (invStatusSelect) invStatusSelect.value = 'PAID';
    if (invPaymentMethodSelect) invPaymentMethodSelect.value = 'Bank Transfer';
    if (invCurrencySelect) invCurrencySelect.value = 'USD';
    if (invTxnRef) invTxnRef.value = 'TXN-' + Math.floor(100000 + Math.random() * 900000);
    if (invNotesInput) invNotesInput.value = 'Payment confirmed. Student granted immediate authorization for invoiced qualification modules and examination attempts.';
    if (invDiscountInput) invDiscountInput.value = '0';
    if (invTaxInput) invTaxInput.value = '0';
    if (invLevelSelect) invLevelSelect.value = '4';
    if (invModuleUnitPrice) invModuleUnitPrice.value = '150';

    // Clear and reset items
    invoiceLineItems = [];

    // Render modules picker for level 4
    renderInvoiceModulePicker(4);

    // Render empty items and totals
    renderInvoiceItemsTable();
    recalculateInvoiceTotals();
    updateCurrencySymbolsOnUI();

    // Load invoice history
    loadStudentInvoiceHistory(student.email);

    invoiceModal.classList.add('active');
  }

  function closeInvoiceModal() {
    if (invoiceModal) invoiceModal.classList.remove('active');
  }

  if (btnCloseInvoiceModal) btnCloseInvoiceModal.addEventListener('click', closeInvoiceModal);
  if (btnInvCancel) btnInvCancel.addEventListener('click', closeInvoiceModal);
  if (invoiceModal) {
    invoiceModal.addEventListener('click', (e) => {
      if (e.target === invoiceModal) closeInvoiceModal();
    });
  }

  // Previous Invoices History Loader
  async function loadStudentInvoiceHistory(email) {
    if (!invHistoryList) return;
    try {
      currentStudentInvoices = await apiConfig.getInvoices(email);
      if (invHistoryCountBadge) {
        invHistoryCountBadge.textContent = `${currentStudentInvoices.length} Saved`;
      }

      if (currentStudentInvoices.length === 0) {
        invHistoryList.innerHTML = `<p style="font-size: 0.8rem; color: var(--text-muted); padding: 0.5rem 0;">No previous invoices found for this student.</p>`;
        return;
      }

      invHistoryList.innerHTML = currentStudentInvoices.map(inv => `
        <div class="inv-history-item">
          <div>
            <div style="display: flex; align-items: center; gap: 6px;">
              <strong style="font-family: var(--font-mono); color: var(--cips-navy);">${inv.invoiceNumber}</strong>
              <span class="inv-status-pill status-${inv.paymentStatus === 'PAID' ? 'paid' : 'pending'}" style="font-size: 9px; padding: 1px 6px;">
                ${inv.paymentStatus}
              </span>
            </div>
            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 2px;">
              ${inv.issueDate} &bull; ${(inv.items || []).length} items &bull; ${inv.paymentMethod || 'Bank Transfer'}
            </div>
          </div>
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <div style="font-weight: 800; font-family: var(--font-mono); color: var(--text-main); font-size: 0.9rem;">
              ${inv.currency || '$'}${Number(inv.total || 0).toFixed(2)}
            </div>
            <button type="button" class="btn btn-secondary btn-action-sm btn-delete-inv" data-id="${inv.id}" title="Delete Invoice Record" style="color: #dc2626; padding: 3px 6px;">
              🗑️
            </button>
          </div>
        </div>
      `).join('');

      document.querySelectorAll('.btn-delete-inv').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          if (confirm('Are you sure you want to delete this invoice record?')) {
            await apiConfig.deleteInvoice(id);
            showToast('Invoice deleted', 'info');
            loadStudentInvoiceHistory(email);
          }
        });
      });
    } catch (e) {
      console.warn('Failed to load invoice history:', e);
      invHistoryList.innerHTML = `<p style="font-size: 0.8rem; color: #dc2626;">Error loading invoice history.</p>`;
    }
  }

  if (btnToggleInvHistory) {
    btnToggleInvHistory.addEventListener('click', () => {
      if (!invHistoryContainer) return;
      const isVisible = invHistoryContainer.style.display === 'block';
      invHistoryContainer.style.display = isVisible ? 'none' : 'block';
      if (invHistoryChevron) invHistoryChevron.textContent = isVisible ? '▼' : '▲';
    });
  }

  // Save Invoice Action
  async function saveInvoiceRecord() {
    if (!activeInvoiceStudent) {
      showToast('No student selected for invoice generation', 'danger');
      return;
    }

    if (invoiceLineItems.length === 0) {
      showToast('Please add at least one module or fee item to the invoice.', 'warning');
      return;
    }

    const subtotal = invoiceLineItems.reduce((acc, it) => acc + (it.quantity * it.unitPrice), 0);
    const discount = Math.max(0, parseFloat(invDiscountInput ? invDiscountInput.value : 0) || 0);
    const taxRate = Math.max(0, parseFloat(invTaxInput ? invTaxInput.value : 0) || 0);
    const tax = Math.max(0, subtotal - discount) * (taxRate / 100);
    const grandTotal = Math.max(0, (subtotal - discount) + tax);
    const amountPaid = parseFloat(invAmountPaidInput ? invAmountPaidInput.value : 0) || 0;
    const balanceDue = Math.max(0, grandTotal - amountPaid);

    const invoiceNumber = invNumberInput.value.trim() || `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const payload = {
      invoiceNumber: invoiceNumber,
      studentEmail: activeInvoiceStudent.email,
      studentName: activeInvoiceStudent.name || activeInvoiceStudent.studentId,
      studentId: activeInvoiceStudent.studentId,
      currency: invCurrencySelect.value,
      issueDate: invIssueDate.value || new Date().toISOString().split('T')[0],
      dueDate: invIssueDate.value || new Date().toISOString().split('T')[0],
      paymentStatus: invStatusSelect.value,
      paymentMethod: invPaymentMethodSelect.value,
      transactionReference: invTxnRef.value.trim(),
      items: invoiceLineItems.map(item => ({
        description: item.description,
        code: item.code,
        type: item.type,
        level: item.level || undefined,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        total: item.quantity * item.unitPrice,
        extraAttempts: item.extraAttempts || 0
      })),
      subtotal: subtotal,
      discount: discount,
      tax: tax,
      total: grandTotal,
      amountPaid: amountPaid,
      balanceDue: balanceDue,
      notes: invNotesInput.value.trim(),
      autoApplyPermissions: invAutoApplyCheck ? invAutoApplyCheck.checked : true
    };

    try {
      if (btnInvSave) {
        btnInvSave.disabled = true;
        btnInvSave.textContent = '⏳ Saving & Applying...';
      }

      await apiConfig.saveInvoice(payload);

      showToast(`Invoice ${invoiceNumber} created and saved successfully!`, 'success');

      // If auto-applied, reload student list to reflect new modules & quiz access
      if (payload.autoApplyPermissions) {
        await loadStudentsList();
        activeInvoiceStudent = allStudents.find(s => s.email.toLowerCase() === activeInvoiceStudent.email.toLowerCase()) || activeInvoiceStudent;
      }

      await loadStudentInvoiceHistory(activeInvoiceStudent.email);

      if (btnInvSave) {
        btnInvSave.disabled = false;
        btnInvSave.textContent = '💾 Save Invoice & Apply Access';
      }
    } catch (err) {
      console.error('Error saving invoice:', err);
      showToast(err.message || 'Failed to save invoice', 'danger');
      if (btnInvSave) {
        btnInvSave.disabled = false;
        btnInvSave.textContent = '💾 Save Invoice & Apply Access';
      }
    }
  }

  if (btnInvSave) btnInvSave.addEventListener('click', saveInvoiceRecord);

  // PDF Generation with jsPDF
  function generateInvoicePDF() {
    if (!activeInvoiceStudent) return;
    if (invoiceLineItems.length === 0) {
      showToast('Add line items before downloading PDF.', 'warning');
      return;
    }

    try {
      const jsPDFConstructor = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
      if (!jsPDFConstructor) {
        showToast('PDF generator library is still loading. Please try again in a moment.', 'warning');
        return;
      }
      const doc = new jsPDFConstructor('p', 'mm', 'a4');
      const invoiceNumber = invNumberInput.value.trim() || 'INV-2026-0001';
      const issueDate = invIssueDate.value || new Date().toISOString().split('T')[0];
      const status = invStatusSelect.value || 'PAID';
      const paymentMethod = invPaymentMethodSelect.value;
      const txnRef = invTxnRef.value.trim() || 'N/A';
      const { sym, code } = getSelectedCurrencyInfo();

      const subtotal = invoiceLineItems.reduce((acc, it) => acc + (it.quantity * it.unitPrice), 0);
      const discount = Math.max(0, parseFloat(invDiscountInput.value) || 0);
      const taxRate = Math.max(0, parseFloat(invTaxInput.value) || 0);
      const tax = Math.max(0, subtotal - discount) * (taxRate / 100);
      const grandTotal = Math.max(0, (subtotal - discount) + tax);
      const amountPaid = parseFloat(invAmountPaidInput.value) || 0;
      const balanceDue = Math.max(0, grandTotal - amountPaid);

      // Top Navy Banner
      doc.setFillColor(30, 58, 138); // Navy Blue
      doc.rect(0, 0, 210, 32, 'F');

      // Gold Accent Stripe
      doc.setFillColor(217, 119, 6); // CIPS Gold
      doc.rect(0, 32, 210, 2.5, 'F');

      // Header Text
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text('CHARTERED INSTITUTE OF PROCUREMENT & SUPPLY', 15, 14);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(226, 232, 240);
      doc.text('ACADEMIC TUITION & ASSESSMENT FEE SETTLEMENT INVOICE / RECEIPT', 15, 22);

      // Invoice Details Block (Right)
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(255, 255, 255);
      doc.text(invoiceNumber, 195, 14, { align: 'right' });

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.text(`Date: ${issueDate}`, 195, 22, { align: 'right' });

      // Student / Billing Information Card
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(15, 42, 88, 38, 2, 2, 'FD');

      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.text('BILLED TO (REGISTERED STUDENT):', 20, 50);

      doc.setFontSize(10);
      doc.text(activeInvoiceStudent.name || activeInvoiceStudent.studentId, 20, 58);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);
      doc.text(`Email: ${activeInvoiceStudent.email}`, 20, 65);
      doc.text(`Student ID: ${activeInvoiceStudent.studentId || 'N/A'}`, 20, 72);

      // Payment & Transaction Info Card
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(107, 42, 88, 38, 2, 2, 'FD');

      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.text('PAYMENT DETAILS & STATUS:', 112, 50);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);
      doc.text(`Payment Method: ${paymentMethod}`, 112, 58);
      doc.text(`Transaction Ref: ${txnRef}`, 112, 65);
      doc.text(`Currency: ${code} (${sym})`, 112, 72);

      // Payment Status Stamp Badge
      if (status === 'PAID') {
        doc.setFillColor(220, 252, 231);
        doc.setDrawColor(34, 197, 94);
        doc.roundedRect(165, 47, 24, 7, 1, 1, 'FD');
        doc.setTextColor(21, 128, 61);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.text('PAID (FULL)', 177, 52, { align: 'center' });
      } else {
        doc.setFillColor(254, 243, 199);
        doc.setDrawColor(245, 158, 11);
        doc.roundedRect(165, 47, 24, 7, 1, 1, 'FD');
        doc.setTextColor(180, 83, 9);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.text(status, 177, 52, { align: 'center' });
      }

      // Line Items Table Header
      let y = 88;
      doc.setFillColor(30, 58, 138);
      doc.rect(15, y, 180, 8, 'F');

      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.text('#', 18, y + 5.5);
      doc.text('Description & Module Details', 28, y + 5.5);
      doc.text('Code', 120, y + 5.5);
      doc.text('Qty', 140, y + 5.5, { align: 'center' });
      doc.text('Unit Price', 162, y + 5.5, { align: 'right' });
      doc.text('Total', 190, y + 5.5, { align: 'right' });

      y += 8;

      // Table Rows
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);

      invoiceLineItems.forEach((it, idx) => {
        const rowBg = idx % 2 === 0 ? [255, 255, 255] : [248, 250, 252];
        doc.setFillColor(rowBg[0], rowBg[1], rowBg[2]);
        doc.rect(15, y, 180, 8, 'F');
        doc.setDrawColor(226, 232, 240);
        doc.line(15, y + 8, 195, y + 8);

        doc.setTextColor(71, 85, 105);
        doc.text(`${idx + 1}`, 18, y + 5.5);

        doc.setTextColor(15, 23, 42);
        const descText = it.description.length > 55 ? it.description.substring(0, 52) + '...' : it.description;
        doc.text(descText, 28, y + 5.5);

        doc.setFont('helvetica', 'bold');
        doc.setTextColor(67, 56, 202);
        doc.text(it.code, 120, y + 5.5);

        doc.setFont('helvetica', 'normal');
        doc.setTextColor(71, 85, 105);
        doc.text(`${it.quantity}`, 140, y + 5.5, { align: 'center' });
        doc.text(`${sym}${it.unitPrice.toFixed(2)}`, 162, y + 5.5, { align: 'right' });

        doc.setFont('helvetica', 'bold');
        doc.setTextColor(15, 23, 42);
        doc.text(`${sym}${(it.quantity * it.unitPrice).toFixed(2)}`, 190, y + 5.5, { align: 'right' });

        y += 8;
      });

      y += 6;

      // Financial Calculation Summary Box (Right)
      const summaryLeft = 120;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);

      doc.text('Subtotal:', summaryLeft, y);
      doc.text(`${sym}${subtotal.toFixed(2)}`, 190, y, { align: 'right' });
      y += 5.5;

      if (discount > 0) {
        doc.text('Discount:', summaryLeft, y);
        doc.setTextColor(22, 163, 74);
        doc.text(`-${sym}${discount.toFixed(2)}`, 190, y, { align: 'right' });
        doc.setTextColor(71, 85, 105);
        y += 5.5;
      }

      if (tax > 0) {
        doc.text(`Tax / VAT (${taxRate}%):`, summaryLeft, y);
        doc.text(`${sym}${tax.toFixed(2)}`, 190, y, { align: 'right' });
        y += 5.5;
      }

      doc.setDrawColor(203, 213, 225);
      doc.line(summaryLeft, y, 195, y);
      y += 5.5;

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(30, 58, 138);
      doc.text('Grand Total:', summaryLeft, y);
      doc.text(`${sym}${grandTotal.toFixed(2)}`, 190, y, { align: 'right' });
      y += 6.5;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(5, 150, 105);
      doc.text('Amount Paid:', summaryLeft, y);
      doc.text(`${sym}${amountPaid.toFixed(2)}`, 190, y, { align: 'right' });
      y += 5.5;

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(balanceDue === 0 ? 5 : 185, balanceDue === 0 ? 150 : 28, balanceDue === 0 ? 105 : 28);
      doc.text('Balance Due:', summaryLeft, y);
      doc.text(`${sym}${balanceDue.toFixed(2)}`, 190, y, { align: 'right' });

      // Remarks Box
      const notesY = y - 24;
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(15, notesY, 95, 32, 2, 2, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(15, 23, 42);
      doc.text('Official Remarks & Access Authorization:', 19, notesY + 6);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(71, 85, 105);
      const noteText = (invNotesInput.value.trim() || 'This invoice confirms academic tuition and examination fees. Permitted modules and quiz attempt quotas are authorized.')
        .substring(0, 150);
      const splitNotes = doc.splitTextToSize(noteText, 87);
      doc.text(splitNotes, 19, notesY + 12);

      // Official Stamp / Watermark
      doc.setDrawColor(34, 197, 94);
      doc.setLineWidth(0.5);
      doc.roundedRect(15, 230, 80, 22, 2, 2, 'D');
      doc.setTextColor(21, 128, 61);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.text('✓ OFFICIAL CIPS VERIFICATION', 20, 238);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.text('Student Qualification Access Authorized', 20, 244);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 20, 249);

      // Footer
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text('Chartered Institute of Procurement & Supply • Student Fee Administration System', 105, 280, { align: 'center' });
      doc.text('This is a computer-generated official document. No physical signature required.', 105, 285, { align: 'center' });

      doc.save(`CIPS_Invoice_${invoiceNumber}_${activeInvoiceStudent.studentId || 'student'}.pdf`);
      showToast(`PDF Invoice ${invoiceNumber} downloaded successfully!`, 'success');
    } catch (err) {
      console.error('PDF Generation Error:', err);
      showToast('Error generating PDF invoice: ' + err.message, 'danger');
    }
  }

  if (btnInvDownloadPdf) btnInvDownloadPdf.addEventListener('click', generateInvoicePDF);

  // Print Invoice
  function printInvoiceDocument() {
    if (!activeInvoiceStudent) return;
    window.print();
  }

  if (btnInvPrint) btnInvPrint.addEventListener('click', printInvoiceDocument);

  // Window Escape key handler for invoice modal
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && invoiceModal && invoiceModal.classList.contains('active')) {
      closeInvoiceModal();
    }
  });

  // Student Timeline Modal handlers
  const btnCloseTimeline = document.getElementById('btn-close-timeline-modal');
  const btnCloseTimelineBottom = document.getElementById('btn-close-timeline-modal-bottom');
  const timelineModal = document.getElementById('student-timeline-modal');
  const btnTimelineCreateInvoice = document.getElementById('btn-timeline-create-invoice');
  const btnTimelineEditStudent = document.getElementById('btn-timeline-edit-student');

  if (btnCloseTimeline) btnCloseTimeline.addEventListener('click', closeStudentTimeline);
  if (btnCloseTimelineBottom) btnCloseTimelineBottom.addEventListener('click', closeStudentTimeline);
  if (timelineModal) {
    timelineModal.addEventListener('click', (e) => {
      if (e.target === timelineModal) closeStudentTimeline();
    });
  }

  if (btnTimelineCreateInvoice) {
    btnTimelineCreateInvoice.addEventListener('click', () => {
      if (activeTimelineStudentEmail) {
        const student = allStudents.find(s => s.email.toLowerCase() === activeTimelineStudentEmail.toLowerCase());
        closeStudentTimeline();
        if (student) openInvoiceModal(student);
      }
    });
  }

  if (btnTimelineEditStudent) {
    btnTimelineEditStudent.addEventListener('click', () => {
      if (activeTimelineStudentEmail) {
        const student = allStudents.find(s => s.email.toLowerCase() === activeTimelineStudentEmail.toLowerCase());
        closeStudentTimeline();
        if (student) openStudentProfileModal(student);
      }
    });
  }

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && timelineModal && timelineModal.classList.contains('active')) {
      closeStudentTimeline();
    }
  });

  // Stat Cards Navigation click support
  document.querySelectorAll('.stat-card-clickable').forEach(card => {
    card.addEventListener('click', (e) => {
      const href = card.getAttribute('href');
      if (href && !e.ctrlKey && !e.metaKey && !e.shiftKey) {
        window.location.href = href;
      }
    });
  });
});
