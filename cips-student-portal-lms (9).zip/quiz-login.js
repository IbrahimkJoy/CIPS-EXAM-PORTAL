/**
 * Quiz Login & Access Authorization Logic
 */

import { apiConfig } from './api-config.js';

document.addEventListener('DOMContentLoaded', async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const moduleCode = urlParams.get('module') || 'L4M1';

  const modulePill = document.getElementById('quiz-module-pill');
  if (modulePill) {
    modulePill.innerHTML = `🔒 Module <strong>${moduleCode}</strong> Exam Authorization`;
    // Try to enrich with module name if available
    try {
      const modulesData = await apiConfig.getModulesData();
      for (const lvl in modulesData) {
        const found = (modulesData[lvl].modules || []).find(m => m.code === moduleCode);
        if (found) {
          modulePill.innerHTML = `🔒 Module <strong>${moduleCode}</strong>: ${found.name}`;
          break;
        }
      }
    } catch (e) {
      // Fallback stays as default
    }
  }

  const activeStudent = apiConfig.getStoredStudent();
  const quizEmailInput = document.getElementById('quizEmail');
  const quizPassInput = document.getElementById('quizPassword');
  const btnToggleQuizPass = document.getElementById('btn-toggle-quiz-pass');
  const deviceInfoLabel = document.getElementById('device-info-label');

  if (activeStudent && quizEmailInput) {
    quizEmailInput.value = activeStudent.email;
  }

  // Display device fingerprint details
  if (deviceInfoLabel) {
    const fp = apiConfig.getDeviceFingerprint();
    deviceInfoLabel.textContent = `🔒 Active Device: ${fp.browser} on ${fp.os} (ID: ${fp.deviceToken.substring(0, 8)}...) • Single-Session Lock`;
  }

  // Floating label sync for input boxes
  function syncFloatingLabels() {
    document.querySelectorAll('.auth-panel-wrapper .input-box input').forEach(input => {
      const updateHasValue = () => {
        if (input.value && input.value.length > 0) {
          input.parentElement.classList.add('has-value');
        } else {
          input.parentElement.classList.remove('has-value');
        }
      };
      input.addEventListener('input', updateHasValue);
      input.addEventListener('change', updateHasValue);
      updateHasValue();
    });
  }
  syncFloatingLabels();

  // Password visibility toggle
  if (btnToggleQuizPass && quizPassInput) {
    btnToggleQuizPass.addEventListener('click', () => {
      const isPass = quizPassInput.type === 'password';
      quizPassInput.type = isPass ? 'text' : 'password';
      btnToggleQuizPass.style.opacity = isPass ? '1' : '0.65';
    });
  }

  // Global Quiz Demo Fill Handler
  window.fillQuizDemo = (email, pass) => {
    if (quizEmailInput && quizPassInput) {
      quizEmailInput.value = email;
      quizPassInput.value = pass;
      quizEmailInput.dispatchEvent(new Event('input', { bubbles: true }));
      quizPassInput.dispatchEvent(new Event('input', { bubbles: true }));
      quizEmailInput.dispatchEvent(new Event('change', { bubbles: true }));
      quizPassInput.dispatchEvent(new Event('change', { bubbles: true }));
      hideAlert();
    }
  };

  const form = document.getElementById('quiz-login-form');
  const alertBox = document.getElementById('quiz-auth-alert');
  const alertText = document.getElementById('quiz-auth-alert-text');
  const submitBtn = document.getElementById('btn-submit-quiz-auth');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const email = quizEmailInput ? quizEmailInput.value.trim() : '';
      const quizPassword = quizPassInput ? quizPassInput.value.trim() : '';

      if (!email || !quizPassword) {
        showAlert('Please enter both your student email and admin-issued quiz password.');
        return;
      }

      hideAlert();
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Verifying Quiz Password & Attempts...';
      }

      try {
        const response = await apiConfig.verifyQuizPassword(email, quizPassword, moduleCode);

        if (response.success) {
          // Store authorized token in sessionStorage
          sessionStorage.setItem('cips_quiz_authorized', JSON.stringify({
            email,
            moduleCode,
            authorizedAt: Date.now(),
            attemptsRemaining: response.attemptsRemaining
          }));

          if (submitBtn) {
            submitBtn.textContent = '✓ Authorized! Launching Exam Engine...';
          }
          setTimeout(() => {
            window.location.href = `quiz.html?module=${encodeURIComponent(moduleCode)}`;
          }, 400);
        }
      } catch (err) {
        console.error('Quiz verification failed:', err);
        const msg = err.message || 'Quiz authorization failed.';
        showAlert(msg);
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Authorize & Launch Exam Engine';
        }
      }
    });
  }

  function showAlert(msg) {
    if (alertBox && alertText) {
      alertText.textContent = msg;
      alertBox.style.display = 'flex';
    }
  }

  function hideAlert() {
    if (alertBox) alertBox.style.display = 'none';
  }
});
