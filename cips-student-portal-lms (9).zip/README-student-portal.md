# CIPS Student Portal LMS - Project Structure & Directory Guide

This document outlines the files generated for the Chartered Institute of Procurement & Supply (CIPS) Student Portal LMS project, organized section-by-section. All files are standalone and designed to drop directly into a single project root folder.

---

### SECTION 1: STUDENT LOGIN & DEVICE LOCK
- **Files:** `student-login.html`, `student-login.css`, `student-auth.js`
- **Role:** Handles student user authentication using Student UserID and Email (with no public username/password or forgot password flow). Implements active device fingerprinting (browser + OS + `localStorage` device token). Blocks logins from unrecognized second devices with the exact message *"This account is already active on another device. Contact your administrator"*, and records a `device_login_attempt` event to the shared backend database for Admin Panel monitoring.

---

### SECTION 2: DASHBOARD & LEVEL/MODULE ACCESS CONTROL
- **Files:** `dashboard.html`, `dashboard.css`, `access-control.js`, `modules-data.json`
- **Role:** Displays all 5 CIPS qualification level cards (Level 2, 3, 4, 5, 6) in a clean grid layout. Fetches student approval lists from `GET /api/access/:studentEmail`. Unapproved levels trigger an access denied modal (*"Access Denied — Pay fees to unlock CIPS Level X"*). Partially approved levels open the module list while padlocking unauthorized modules with fee unlock alerts. Complete dataset is defined in `modules-data.json` containing codes, credits, exam formats (OR / Case Study CR), and durations.

---

### SECTION 3: MODULE CONTENT VIEWER & ANTI-COPY PROTECTION
- **Files:** `module-content.html`, `module-content.css`, `content-protection.js`
- **Role:** Provides an in-browser document viewer for study guides, embedded streaming video player for recordings, past exam papers, and revision notes. `content-protection.js` enforces anti-copy deterrence by disabling right-click context menus, blocking devtools/print shortcuts (F12, Ctrl+P, Ctrl+S, Ctrl+Shift+I), blurring content when tab focus is lost or window size shifts, rendering dynamic student email watermarks, and broadcasting audit events to `POST /api/security-alert`.

---

### SECTION 4: QUIZ SYSTEM (SEPARATE QUIZ LOGIN + EXAM ENGINE)
- **Files:** `quiz-login.html`, `quiz-login.js`, `quiz.html`, `quiz.css`, `quiz-engine.js`
- **Role:** Enforces a secondary exam authorization gate requiring student email and an Admin-issued quiz password. Enforces a 3-attempt limit policy (*"Quiz attempt limit reached — ask your administrator to extend it"*). Features a dual exam engine mode: Objective Response (OR) with 60 MCQs, 90-minute countdown timer, navigation grid, and auto-submit; and Constructive Response (CR) with module-specific Case Studies, timed long-form text answer boxes, and automated submission to `/api/quiz-results`.

---

### SECTION 5: SHARED API LAYER, STYLES & BACKEND
- **Files:** `api-config.js`, `shared-styles.css`, `README-student-portal.md`, `server.ts`, `shared-backend/db.js`, `shared-backend/data.json`
- **Role:** `api-config.js` provides centralized fetch wrappers for all REST endpoints across the portal. `shared-styles.css` maintains unified CIPS corporate theme design variables, typography, modal overlays, and form controls. The Express backend in `server.ts` and `shared-backend/` provides data persistence and REST API endpoints for login, device lock verification, access control, secure content delivery, quiz verification, and security event logging.
