/**
 * Logistics, Maritime, Aviation & Stadium Procurement Animated Canvas Engine (Version 3.0)
 * Ultra-high-fidelity simulation featuring:
 *  - Full Continental World Map (North America, South America, Europe, Africa, Asia, Australia, Antarctica)
 *  - Tactical Air Corridors & Multiple Long-Range Cargo Planes (B747-8F, B777F, A350F, MD-11F, C-17)
 *  - Maritime Container Ships, Inland Freight Convoys, Stadium Tenders & Purchasing PO Hubs
 *  - Complete Light & Dark Theme Support with dynamic reactive switching
 */

export function initLogisticsBackground(canvasId = 'logistics-bg-canvas', options = {}) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;

  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  let width = 0;
  let height = 0;
  let dpr = window.devicePixelRatio || 1;
  let animFrameId = null;
  let time = 0;

  // Theme Detection & Reactive State
  function getTheme() {
    return document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
  }
  let currentTheme = getTheme();

  window.addEventListener('cipsThemeChanged', (e) => {
    if (e.detail && e.detail.theme) {
      currentTheme = e.detail.theme;
    }
  });

  const isDashboard = options.theme === 'dashboard';
  const ambientAlpha = isDashboard ? 0.85 : 1.0;

  // Interaction State
  const mouse = {
    x: -1000,
    y: -1000,
    radius: 220,
    active: false,
    clickRipple: 0,
    clickX: 0,
    clickY: 0
  };

  let speedMultiplier = 1.0;

  function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    dpr = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.scale(dpr, dpr);

    initWorld();
  }

  // World Graph Entities
  let nodes = [];
  let routes = [];
  let vessels = [];
  let trucks = [];
  let planes = [];
  let cargoPackets = [];
  let wakeParticles = [];
  let contrailParticles = [];
  let ambientBuoys = [];
  let worldGridDots = [];
  let strategicChokepoints = [];

  // Continental Landmass Data (Normalized 0.0 - 1.0 coordinates)
  const continents = [
    // 1. NORTH AMERICA (Alaska, Canada, Greenland, US, Mexico, Central America)
    {
      name: 'North America',
      polygons: [
        [
          [0.04, 0.16], [0.09, 0.13], [0.16, 0.13], [0.22, 0.15],
          [0.26, 0.18], [0.28, 0.15], [0.32, 0.15], [0.34, 0.20],
          [0.32, 0.24], [0.29, 0.23], [0.32, 0.27], [0.31, 0.32],
          [0.28, 0.35], [0.26, 0.40], [0.26, 0.44], [0.23, 0.44],
          [0.21, 0.42], [0.18, 0.45], [0.16, 0.48], [0.18, 0.52],
          [0.21, 0.53], [0.19, 0.51], [0.15, 0.44], [0.13, 0.39],
          [0.11, 0.33], [0.10, 0.27], [0.07, 0.22], [0.04, 0.19]
        ],
        // Greenland
        [
          [0.34, 0.08], [0.40, 0.07], [0.42, 0.12], [0.38, 0.16], [0.33, 0.13]
        ]
      ]
    },
    // 2. SOUTH AMERICA (Colombia, Venezuela, Brazil, Argentina, Chile)
    {
      name: 'South America',
      polygons: [
        [
          [0.23, 0.54], [0.27, 0.53], [0.32, 0.55], [0.36, 0.59],
          [0.38, 0.63], [0.36, 0.69], [0.33, 0.74], [0.30, 0.81],
          [0.28, 0.88], [0.26, 0.92], [0.24, 0.89], [0.23, 0.82],
          [0.24, 0.73], [0.22, 0.65], [0.21, 0.59], [0.22, 0.55]
        ]
      ]
    },
    // 3. EUROPE (Scandinavia, UK, Iberia, France, Germany, Italy, Balkans)
    {
      name: 'Europe',
      polygons: [
        // British Isles
        [
          [0.44, 0.20], [0.47, 0.19], [0.47, 0.24], [0.44, 0.25]
        ],
        // Scandinavia
        [
          [0.50, 0.12], [0.54, 0.11], [0.57, 0.15], [0.54, 0.21], [0.49, 0.18]
        ],
        // Mainland Europe
        [
          [0.46, 0.25], [0.51, 0.24], [0.57, 0.25], [0.59, 0.30],
          [0.55, 0.33], [0.53, 0.36], [0.51, 0.33], [0.48, 0.32],
          [0.43, 0.33], [0.42, 0.37], [0.46, 0.37], [0.47, 0.31]
        ]
      ]
    },
    // 4. AFRICA (North Africa, West Africa, Horn, Southern Africa, Madagascar)
    {
      name: 'Africa',
      polygons: [
        [
          [0.43, 0.38], [0.51, 0.38], [0.56, 0.39], [0.57, 0.44],
          [0.61, 0.46], [0.63, 0.50], [0.60, 0.54], [0.58, 0.61],
          [0.57, 0.68], [0.54, 0.76], [0.51, 0.80], [0.48, 0.76],
          [0.46, 0.66], [0.45, 0.57], [0.47, 0.50], [0.42, 0.47],
          [0.41, 0.41]
        ],
        // Madagascar
        [
          [0.62, 0.67], [0.63, 0.65], [0.64, 0.71], [0.62, 0.73]
        ]
      ]
    },
    // 5. ASIA & MIDDLE EAST (Arabia, India, China, Russia, Southeast Asia, Japan)
    {
      name: 'Asia',
      polygons: [
        // Arabian Peninsula
        [
          [0.57, 0.44], [0.62, 0.45], [0.64, 0.49], [0.60, 0.52], [0.57, 0.48]
        ],
        // Main Asian landmass
        [
          [0.58, 0.22], [0.66, 0.17], [0.76, 0.15], [0.86, 0.14],
          [0.94, 0.17], [0.91, 0.24], [0.84, 0.28], [0.83, 0.34],
          [0.85, 0.38], [0.80, 0.42], [0.77, 0.45], [0.78, 0.52],
          [0.76, 0.56], [0.74, 0.51], [0.73, 0.44], [0.69, 0.52],
          [0.66, 0.45], [0.64, 0.36], [0.60, 0.30]
        ],
        // Japanese Archipelago
        [
          [0.88, 0.27], [0.90, 0.29], [0.89, 0.34], [0.87, 0.32]
        ],
        // Indonesian Archipelago
        [
          [0.78, 0.58], [0.84, 0.58], [0.89, 0.60], [0.84, 0.62]
        ]
      ]
    },
    // 6. AUSTRALIA & OCEANIA
    {
      name: 'Australia',
      polygons: [
        [
          [0.82, 0.68], [0.87, 0.66], [0.91, 0.70], [0.92, 0.77],
          [0.89, 0.82], [0.84, 0.82], [0.80, 0.77], [0.80, 0.71]
        ],
        // New Zealand
        [
          [0.94, 0.81], [0.96, 0.79], [0.95, 0.86], [0.93, 0.86]
        ]
      ]
    },
    // 7. ANTARCTICA
    {
      name: 'Antarctica',
      polygons: [
        [
          [0.08, 0.96], [0.28, 0.95], [0.48, 0.96], [0.68, 0.95],
          [0.88, 0.96], [0.96, 0.98], [0.04, 0.98]
        ]
      ]
    }
  ];

  function initWorld() {
    // 1. Core Global Logistics & Stadium Nodes
    nodes = [
      {
        id: 'rotterdam',
        name: 'Port of Rotterdam',
        type: 'port',
        code: 'NLRTM',
        xRatio: 0.47,
        yRatio: 0.27,
        icon: '⚓',
        accent: '#0284c7',
        status: 'BERTH 4 • TEU 24K CLEARED'
      },
      {
        id: 'london',
        name: 'London CIPS Sourcing HQ',
        type: 'purchasing',
        code: 'GBPUR',
        xRatio: 0.45,
        yRatio: 0.23,
        icon: '📋',
        accent: '#6366f1',
        status: 'PO CLEARINGHOUSE • INCOTERMS DDP'
      },
      {
        id: 'wembley',
        name: 'National Stadium Arena',
        type: 'stadium',
        code: 'UKARENA',
        xRatio: 0.46,
        yRatio: 0.20,
        icon: '🏟️',
        accent: '#10b981',
        status: '$148M TURNKEY CONTRACT'
      },
      {
        id: 'suez',
        name: 'Suez Canal Maritime Gateway',
        type: 'canal',
        code: 'EGSCA',
        xRatio: 0.57,
        yRatio: 0.43,
        icon: '🌊',
        accent: '#38bdf8',
        status: 'CONVOY SOUTHBOUND • AIS LVL 1'
      },
      {
        id: 'dubai',
        name: 'Dubai Jebel Ali Hub',
        type: 'freight',
        code: 'AEDXB',
        xRatio: 0.63,
        yRatio: 0.48,
        icon: '📦',
        accent: '#f59e0b',
        status: 'COLD-CHAIN INTERMODAL 99.4% JIT'
      },
      {
        id: 'lusail',
        name: 'Grand Lusail Mega-Stadium',
        type: 'stadium',
        code: 'QTARENA',
        xRatio: 0.61,
        yRatio: 0.45,
        icon: '🏟️',
        accent: '#10b981',
        status: 'ARENA FLOODLIGHTS PROCUREMENT'
      },
      {
        id: 'singapore',
        name: 'Singapore PSA Terminal',
        type: 'port',
        code: 'SGSIN',
        xRatio: 0.77,
        yRatio: 0.57,
        icon: '🚢',
        accent: '#0284c7',
        status: 'PACIFIC HUB • TRANSSHIPMENT'
      },
      {
        id: 'shanghai',
        name: 'Shanghai Yangshan Port',
        type: 'port',
        code: 'CNSHG',
        xRatio: 0.83,
        yRatio: 0.36,
        icon: '⚓',
        accent: '#0284c7',
        status: 'CONTAINER GANTRY CRANES ONLINE'
      },
      {
        id: 'tokyo',
        name: 'Tokyo Olympic Arena Center',
        type: 'stadium',
        code: 'JPARENA',
        xRatio: 0.89,
        yRatio: 0.31,
        icon: '🏟️',
        accent: '#10b981',
        status: 'MODULAR SEATING & TURF TENDER'
      },
      {
        id: 'chicago',
        name: 'Chicago Intermodal Logistics',
        type: 'truck',
        code: 'USCHI',
        xRatio: 0.22,
        yRatio: 0.30,
        icon: '🚛',
        accent: '#f59e0b',
        status: 'RAIL-TO-TRUCK FREIGHT DEPOT'
      },
      {
        id: 'newyork',
        name: 'JFK Global Air Cargo Hub',
        type: 'airhub',
        code: 'USJFK',
        xRatio: 0.27,
        yRatio: 0.31,
        icon: '✈️',
        accent: '#818cf8',
        status: 'TRANSATLANTIC AIR EXPRESS'
      },
      {
        id: 'losangeles',
        name: 'Port of Los Angeles (POLA)',
        type: 'port',
        code: 'USLAX',
        xRatio: 0.13,
        yRatio: 0.35,
        icon: '⚓',
        accent: '#0284c7',
        status: 'PACIFIC INTERMODAL GATEWAY'
      },
      {
        id: 'saopaulo',
        name: 'Sao Paulo Industrial Hub',
        type: 'freight',
        code: 'BRGRU',
        xRatio: 0.34,
        yRatio: 0.72,
        icon: '📦',
        accent: '#f59e0b',
        status: 'LATAM SOURCING CORRIDOR'
      },
      {
        id: 'sydney',
        name: 'Sydney Olympic Logistics',
        type: 'stadium',
        code: 'AUSYD',
        xRatio: 0.89,
        yRatio: 0.79,
        icon: '🏟️',
        accent: '#10b981',
        status: 'SOUTHERN PACIFIC ARENA CONTRACTS'
      }
    ];

    // Compute absolute pixel coordinates
    nodes.forEach(n => {
      n.x = n.xRatio * width;
      n.y = n.yRatio * height;
    });

    // 2. Global Corridors (Sea Lanes, Highway Arteries & Flight Skyways)
    routes = [
      // Sea & Road Corridors
      { from: 'rotterdam', to: 'london', type: 'sea', curve: -25, label: 'North Sea Feeder' },
      { from: 'london', to: 'wembley', type: 'road', curve: 15, label: 'M25 Heavy Haul Corridor' },
      { from: 'rotterdam', to: 'suez', type: 'sea', curve: 35, label: 'Gibraltar-Mediterranean Sea Route' },
      { from: 'suez', to: 'dubai', type: 'sea', curve: -15, label: 'Red Sea & Gulf of Oman Lane' },
      { from: 'dubai', to: 'lusail', type: 'road', curve: 18, label: 'Trans-Gulf Heavy Transit' },
      { from: 'dubai', to: 'singapore', type: 'sea', curve: 30, label: 'Indian Ocean Deep Sea Lane' },
      { from: 'singapore', to: 'shanghai', type: 'sea', curve: -30, label: 'South China Sea Corridor' },
      { from: 'shanghai', to: 'tokyo', type: 'sea', curve: -20, label: 'Pacific Archipelago Lane' },
      { from: 'chicago', to: 'rotterdam', type: 'sea', curve: -45, label: 'Transatlantic Freight Route' },

      // Air Skyways (New & Expanded Flight Corridors)
      { from: 'newyork', to: 'london', type: 'air', curve: -55, label: 'Transatlantic Great Circle Skyway' },
      { from: 'chicago', to: 'wembley', type: 'air', curve: -65, label: 'Great Circle Stadium Airway' },
      { from: 'london', to: 'dubai', type: 'air', curve: -35, label: 'Eurasia Strategic Air Bridge' },
      { from: 'dubai', to: 'singapore', type: 'air', curve: -40, label: 'Silk Air Corridor' },
      { from: 'tokyo', to: 'losangeles', type: 'air', curve: -70, label: 'Transpacific Air Express' },
      { from: 'rotterdam', to: 'lusail', type: 'air', curve: -42, label: 'Euro-Gulf Cargo Skyway' },
      { from: 'singapore', to: 'sydney', type: 'air', curve: 35, label: 'Australasia Sky Corridor' },
      { from: 'chicago', to: 'saopaulo', type: 'air', curve: 30, label: 'Pan-American Air Route' }
    ];

    // 3. Container Ships Fleet (🚢)
    vessels = [
      {
        name: 'M/V CIPS MARINER',
        callsign: 'TEU 24,000 • CLASS A',
        routeIndex: 2, // Rotterdam to Suez
        progress: 0.25,
        speed: 0.00065,
        length: 38,
        width: 12,
        containers: [
          ['#e11d48', '#0284c7', '#d97706'],
          ['#059669', '#4f46e5', '#f59e0b'],
          ['#0284c7', '#10b981', '#6366f1']
        ],
        radarAngle: 0
      },
      {
        name: 'EVERGREEN DISCOVERY',
        callsign: 'TEU 20,500 • PACIFIC',
        routeIndex: 5, // Dubai to Singapore
        progress: 0.65,
        speed: 0.00055,
        length: 34,
        width: 11,
        containers: [
          ['#059669', '#059669', '#0284c7'],
          ['#f59e0b', '#e11d48', '#059669'],
          ['#4f46e5', '#0284c7', '#f59e0b']
        ],
        radarAngle: 0.8
      },
      {
        name: 'OCEAN TITAN',
        callsign: 'TEU 18,200 • CHINA EXP',
        routeIndex: 6, // Singapore to Shanghai
        progress: 0.40,
        speed: 0.0007,
        length: 32,
        width: 10,
        containers: [
          ['#0284c7', '#e11d48', '#059669'],
          ['#d97706', '#4f46e5', '#0284c7']
        ],
        radarAngle: 1.5
      },
      {
        name: 'ATLANTIC HIGHWAY',
        callsign: 'TEU 16,800 • TRANS-ATL',
        routeIndex: 8, // Chicago to Rotterdam
        progress: 0.78,
        speed: 0.0006,
        length: 30,
        width: 10,
        containers: [
          ['#4f46e5', '#059669', '#d97706'],
          ['#e11d48', '#0284c7', '#4f46e5']
        ],
        radarAngle: 2.2
      }
    ];

    // 4. Heavy Haulage Fleet Trucks (🚛)
    trucks = [
      {
        name: 'FLEET CONVOY #104',
        cargo: 'Stadium Turf & Seating JIT',
        routeIndex: 1, // London to Wembley
        progress: 0.35,
        speed: 0.0022,
        trailerColor: '#334155',
        cabColor: '#f59e0b'
      },
      {
        name: 'ARENA LOGISTICS #88',
        cargo: '4K LED Stadium Luminaires',
        routeIndex: 1,
        progress: 0.85,
        speed: 0.0020,
        trailerColor: '#1e293b',
        cabColor: '#38bdf8'
      },
      {
        name: 'HEAVY TRANSIT #42',
        cargo: 'Turnkey Infrastructure Prefab',
        routeIndex: 4, // Dubai to Lusail
        progress: 0.55,
        speed: 0.0018,
        trailerColor: '#334155',
        cabColor: '#10b981'
      }
    ];

    // 5. Air Cargo Freighters (✈️ - Both Original + Newly Added Planes)
    planes = [
      // Original Planes
      {
        name: 'CARGO EXPRESS 777F',
        model: '777F',
        engines: 2,
        cargo: 'Urgent Spare Parts & POs',
        routeIndex: 10, // Chicago to Wembley
        progress: 0.22,
        speed: 0.0015,
        strobeTick: 0,
        altitude: 'FL370',
        knots: '495 KTS'
      },
      {
        name: 'GLOBAL AIR FREIGHT',
        model: '777F',
        engines: 2,
        cargo: 'Priority Commercial Contracts',
        routeIndex: 11, // London to Dubai
        progress: 0.68,
        speed: 0.0014,
        strobeTick: 1.2,
        altitude: 'FL390',
        knots: '512 KTS'
      },

      // Newly Added Heavy Cargo Aircraft & Airlifters
      {
        name: 'ATLAS SKYCARGO B747-8F',
        model: '747-8F',
        engines: 4,
        cargo: 'Oversize High-Value Machinery',
        routeIndex: 9, // New York to London
        progress: 0.48,
        speed: 0.0017,
        strobeTick: 0.5,
        altitude: 'FL380',
        knots: '530 KTS'
      },
      {
        name: 'CATHAY CARGO A350F',
        model: 'A350F',
        engines: 2,
        cargo: 'Next-Gen Semiconductor Batch',
        routeIndex: 12, // Dubai to Singapore
        progress: 0.35,
        speed: 0.0016,
        strobeTick: 2.1,
        altitude: 'FL410',
        knots: '505 KTS'
      },
      {
        name: 'PACIFIC RIM FREIGHTER MD-11F',
        model: 'MD-11F',
        engines: 3,
        cargo: 'Autonomous Automotive Powertrains',
        routeIndex: 13, // Tokyo to Los Angeles
        progress: 0.58,
        speed: 0.0018,
        strobeTick: 3.4,
        altitude: 'FL360',
        knots: '488 KTS'
      },
      {
        name: 'STADIUM MEGA-LOGISTICS C-17',
        model: 'C-17',
        engines: 4,
        cargo: 'Turnkey Stadium Truss Infrastructure',
        routeIndex: 14, // Rotterdam to Lusail
        progress: 0.82,
        speed: 0.0014,
        strobeTick: 4.8,
        altitude: 'FL340',
        knots: '450 KTS'
      },
      {
        name: 'QANTAS FREIGHT A330-200F',
        model: 'A330F',
        engines: 2,
        cargo: 'Australasia Supply Resupply',
        routeIndex: 15, // Singapore to Sydney
        progress: 0.28,
        speed: 0.0015,
        strobeTick: 1.8,
        altitude: 'FL400',
        knots: '500 KTS'
      },
      {
        name: 'LATAM SKY-LINK B767-300F',
        model: '767F',
        engines: 2,
        cargo: 'Industrial Assembly Modules',
        routeIndex: 16, // Chicago to Sao Paulo
        progress: 0.62,
        speed: 0.0016,
        strobeTick: 2.9,
        altitude: 'FL370',
        knots: '480 KTS'
      }
    ];

    // 6. Fast Supply Chain Packets
    cargoPackets = [];
    for (let i = 0; i < 36; i++) {
      cargoPackets.push({
        routeIndex: Math.floor(Math.random() * routes.length),
        progress: Math.random(),
        speed: 0.002 + Math.random() * 0.0025,
        size: 2.2 + Math.random() * 2,
        color: Math.random() > 0.5 ? '#38bdf8' : (Math.random() > 0.5 ? '#818cf8' : '#34d399')
      });
    }

    // 7. Ambient Navigational Buoys
    ambientBuoys = [
      { xRatio: 0.43, yRatio: 0.35, color: '#38bdf8', label: 'BUOY 08 (Gibraltar)' },
      { xRatio: 0.59, yRatio: 0.49, color: '#34d399', label: 'BUOY 12 (Red Sea)' },
      { xRatio: 0.74, yRatio: 0.55, color: '#f59e0b', label: 'BUOY 19 (Malacca)' },
      { xRatio: 0.86, yRatio: 0.34, color: '#38bdf8', label: 'BUOY 24 (East Sea)' }
    ];

    // 8. Strategic Maritime Chokepoints
    strategicChokepoints = [
      { name: 'PANAMA CANAL', latLon: '9.1°N, 79.7°W', xRatio: 0.23, yRatio: 0.52 },
      { name: 'GIBRALTAR STRAIT', latLon: '35.9°N, 5.6°W', xRatio: 0.43, yRatio: 0.36 },
      { name: 'SUEZ CANAL', latLon: '30.5°N, 32.3°E', xRatio: 0.57, yRatio: 0.43 },
      { name: 'STRAIT OF MALACCA', latLon: '1.4°N, 103.8°E', xRatio: 0.76, yRatio: 0.56 },
      { name: 'CAPE OF GOOD HOPE', latLon: '34.3°S, 18.4°E', xRatio: 0.52, yRatio: 0.81 }
    ];

    // 9. Coordinate Dots Matrix
    worldGridDots = [];
    const cols = 24;
    const rows = 14;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        worldGridDots.push({
          x: (c / (cols - 1)) * width,
          y: (r / (rows - 1)) * height,
          phase: (c + r) * 0.4
        });
      }
    }
  }

  // Bezier Geometry Helper
  function getPointOnRoute(route, t) {
    const fromNode = nodes.find(n => n.id === route.from);
    const toNode = nodes.find(n => n.id === route.to);
    if (!fromNode || !toNode) return { x: 0, y: 0, angle: 0, cpX: 0, cpY: 0 };

    const midX = (fromNode.x + toNode.x) / 2;
    const midY = (fromNode.y + toNode.y) / 2;
    const dx = toNode.x - fromNode.x;
    const dy = toNode.y - fromNode.y;
    const dist = Math.sqrt(dx * dx + dy * dy);

    const perpX = -dy / (dist || 1);
    const perpY = dx / (dist || 1);

    const cpX = midX + perpX * (route.curve || 0);
    const cpY = midY + perpY * (route.curve || 0);

    const x = (1 - t) * (1 - t) * fromNode.x + 2 * (1 - t) * t * cpX + t * t * toNode.x;
    const y = (1 - t) * (1 - t) * fromNode.y + 2 * (1 - t) * t * cpY + t * t * toNode.y;

    const tangentX = 2 * (1 - t) * (cpX - fromNode.x) + 2 * t * (toNode.x - cpX);
    const tangentY = 2 * (1 - t) * (cpY - fromNode.y) + 2 * t * (toNode.y - cpY);
    const angle = Math.atan2(tangentY, tangentX);

    return { x, y, angle, cpX, cpY, fromNode, toNode };
  }

  // -------------------------------------------------------------
  // PRIMARY 60 FPS RENDER LOOP
  // -------------------------------------------------------------
  function render() {
    time += 0.016 * speedMultiplier;
    ctx.clearRect(0, 0, width, height);

    ctx.globalAlpha = ambientAlpha;

    // 1. Draw Cyber Ocean Canvas (Theme-responsive)
    drawCyberOceanCanvas();

    // 2. Draw WHOLE WORLD MAP (Continents, Coastlines, Graticules & Chokepoints)
    drawWholeWorldMap();

    // 3. Draw Marine Wave Grid & Buoys
    drawOceanWavesAndBuoys();

    // 4. Draw Global Corridors (Sea, Road & Air)
    drawTradeCorridors();

    // 5. Draw Fast Cargo Packets
    drawCargoPackets();

    // 6. Draw Contrail Particles from Jets
    drawContrails();

    // 7. Draw Wake Particles from Vessels
    drawWakeParticles();

    // 8. Draw High-Detail Container Ships (🚢)
    drawVessels();

    // 9. Draw Heavy Freight Convoys & Trucks (🚛)
    drawTrucks();

    // 10. Draw Air Cargo Fleet (✈️ - Both Original + Newly Added Planes)
    drawPlanes();

    // 11. Draw Procurement, Port & Stadium Hubs (🏟️ & 📋)
    drawLogisticsNodes();

    // 12. Interactive Sonar Waves on Click & Mouse Movement
    drawInteractiveTelemetry();

    ctx.globalAlpha = 1.0;
    animFrameId = requestAnimationFrame(render);
  }

  // -------------------------------------------------------------
  // RENDERING COMPONENTS
  // -------------------------------------------------------------

  function drawCyberOceanCanvas() {
    const isDark = currentTheme === 'dark';

    // Radial Ocean Background Gradient
    const bgGrad = ctx.createRadialGradient(
      width * 0.45, height * 0.35, 80,
      width * 0.5, height * 0.5, Math.max(width, height) * 0.85
    );

    if (isDark) {
      bgGrad.addColorStop(0, '#0a162b');
      bgGrad.addColorStop(0.6, '#050c18');
      bgGrad.addColorStop(1, '#02050b');
    } else {
      bgGrad.addColorStop(0, '#eaf2f9');
      bgGrad.addColorStop(0.6, '#dfeaf4');
      bgGrad.addColorStop(1, '#d0e0ed');
    }

    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Latitude & Longitude Reference Grid Lines
    ctx.strokeStyle = isDark ? 'rgba(56, 189, 248, 0.05)' : 'rgba(71, 85, 105, 0.08)';
    ctx.lineWidth = 1;

    const latSpacing = 110;
    for (let y = 0; y < height; y += latSpacing) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();

      ctx.fillStyle = isDark ? 'rgba(148, 163, 184, 0.22)' : 'rgba(71, 85, 105, 0.35)';
      ctx.font = '600 8px "JetBrains Mono", monospace';
      const latDeg = Math.round(90 - (y / height) * 180);
      ctx.fillText(`LAT ${Math.abs(latDeg)}°00'${latDeg >= 0 ? 'N' : 'S'}`, 14, y - 4);
    }

    const lonSpacing = 160;
    for (let x = 0; x < width; x += lonSpacing) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();

      ctx.fillStyle = isDark ? 'rgba(148, 163, 184, 0.22)' : 'rgba(71, 85, 105, 0.35)';
      ctx.font = '600 8px "JetBrains Mono", monospace';
      const lonDeg = Math.round((x / width) * 360 - 180);
      ctx.fillText(`LON ${Math.abs(lonDeg)}°00'${lonDeg >= 0 ? 'E' : 'W'}`, x + 5, height - 12);
    }
  }

  // -------------------------------------------------------------
  // WHOLE WORLD MAP RENDERING
  // -------------------------------------------------------------
  function drawWholeWorldMap() {
    const isDark = currentTheme === 'dark';

    // 1. Graticules (Equator, Prime Meridian, Tropics)
    const equatorY = height * 0.50;
    ctx.beginPath();
    ctx.moveTo(0, equatorY);
    ctx.lineTo(width, equatorY);
    ctx.strokeStyle = isDark ? 'rgba(148, 163, 184, 0.12)' : 'rgba(100, 116, 139, 0.15)';
    ctx.lineWidth = 1.0;
    ctx.setLineDash([6, 8]);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = isDark ? 'rgba(148, 163, 184, 0.40)' : 'rgba(71, 85, 105, 0.55)';
    ctx.font = '700 8px "JetBrains Mono", monospace';
    ctx.fillText('EQUATOR (0°00\'00")', width * 0.02, equatorY - 4);

    // Prime Meridian (Greenwich)
    const primeMeridianX = width * 0.45;
    ctx.beginPath();
    ctx.moveTo(primeMeridianX, 0);
    ctx.lineTo(primeMeridianX, height);
    ctx.strokeStyle = isDark ? 'rgba(148, 163, 184, 0.10)' : 'rgba(100, 116, 139, 0.14)';
    ctx.lineWidth = 1.0;
    ctx.setLineDash([4, 6]);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillText('PRIME MERIDIAN (0°E/W)', primeMeridianX + 5, 24);

    // 2. Continental Landmasses
    continents.forEach(cont => {
      cont.polygons.forEach(poly => {
        if (poly.length < 3) return;

        ctx.beginPath();
        poly.forEach((pt, idx) => {
          const px = pt[0] * width;
          const py = pt[1] * height;
          if (idx === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        });
        ctx.closePath();

        // Continent Material & Shading - Reverted back to subtle slate/neutral without excessive blue
        if (isDark) {
          ctx.fillStyle = 'rgba(23, 37, 84, 0.12)';
          ctx.strokeStyle = 'rgba(148, 163, 184, 0.14)';
          ctx.lineWidth = 1.0;
        } else {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
          ctx.strokeStyle = 'rgba(148, 163, 184, 0.25)';
          ctx.lineWidth = 1.0;
        }

        ctx.fill();
        ctx.stroke();

        // Subtle topographic grid inside continent
        ctx.save();
        ctx.clip();
        ctx.strokeStyle = isDark ? 'rgba(148, 163, 184, 0.03)' : 'rgba(71, 85, 105, 0.04)';
        ctx.lineWidth = 0.5;
        for (let ix = 0; ix < width; ix += 35) {
          ctx.beginPath();
          ctx.moveTo(ix, 0);
          ctx.lineTo(ix, height);
          ctx.stroke();
        }
        ctx.restore();
      });
    });

    // 3. Strategic Maritime Chokepoints on World Map
    strategicChokepoints.forEach(choke => {
      const cx = choke.xRatio * width;
      const cy = choke.yRatio * height;

      // Small diamond radar marker
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(Math.PI / 4);
      ctx.fillStyle = isDark ? '#38bdf8' : '#0284c7';
      ctx.fillRect(-3, -3, 6, 6);
      ctx.restore();

      ctx.fillStyle = isDark ? 'rgba(224, 242, 254, 0.75)' : '#1e293b';
      ctx.font = '700 8px "JetBrains Mono", monospace';
      ctx.fillText(`⯌ ${choke.name}`, cx + 8, cy - 2);

      ctx.fillStyle = isDark ? 'rgba(148, 163, 184, 0.5)' : '#64748b';
      ctx.font = '600 7px "JetBrains Mono", monospace';
      ctx.fillText(choke.latLon, cx + 8, cy + 7);
    });
  }

  function drawOceanWavesAndBuoys() {
    const isDark = currentTheme === 'dark';

    // Background Matrix Dots
    worldGridDots.forEach(dot => {
      const alpha = isDark
        ? 0.12 + Math.sin(time * 2 + dot.phase) * 0.08
        : 0.20 + Math.sin(time * 2 + dot.phase) * 0.10;

      ctx.beginPath();
      ctx.arc(dot.x, dot.y, 1.2, 0, Math.PI * 2);
      ctx.fillStyle = isDark ? `rgba(148, 163, 184, ${alpha})` : `rgba(71, 85, 105, ${alpha})`;
      ctx.fill();
    });

    // Navigational Buoys with flashing beacons
    ambientBuoys.forEach(buoy => {
      const bx = buoy.xRatio * width;
      const by = buoy.yRatio * height;

      const flash = Math.sin(time * 3 + bx) > 0.5;

      ctx.beginPath();
      ctx.arc(bx, by, flash ? 4.5 : 2.5, 0, Math.PI * 2);
      ctx.fillStyle = flash ? buoy.color : 'rgba(148, 163, 184, 0.3)';
      ctx.fill();

      if (flash) {
        ctx.beginPath();
        ctx.arc(bx, by, 9, 0, Math.PI * 2);
        ctx.strokeStyle = buoy.color;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }

      ctx.fillStyle = isDark ? 'rgba(148, 163, 184, 0.6)' : 'rgba(51, 65, 85, 0.75)';
      ctx.font = '600 8px "JetBrains Mono", monospace';
      ctx.fillText(buoy.label, bx + 10, by + 3);
    });
  }

  function drawTradeCorridors() {
    const isDark = currentTheme === 'dark';

    routes.forEach(route => {
      const fromNode = nodes.find(n => n.id === route.from);
      const toNode = nodes.find(n => n.id === route.to);
      if (!fromNode || !toNode) return;

      const pt = getPointOnRoute(route, 0.5);

      ctx.beginPath();
      ctx.moveTo(fromNode.x, fromNode.y);
      ctx.quadraticCurveTo(pt.cpX, pt.cpY, toNode.x, toNode.y);

      if (route.type === 'sea') {
        // Maritime Deep Blue / Cyan Lane
        ctx.strokeStyle = isDark ? 'rgba(56, 189, 248, 0.30)' : 'rgba(2, 132, 199, 0.38)';
        ctx.lineWidth = 1.6;
        ctx.setLineDash([6, 5]);
        ctx.stroke();
      } else if (route.type === 'road') {
        // Inland Amber Highway Artery
        ctx.strokeStyle = isDark ? 'rgba(251, 191, 36, 0.35)' : 'rgba(217, 119, 6, 0.45)';
        ctx.lineWidth = 2.0;
        ctx.stroke();
      } else {
        // Air Flight Corridor
        ctx.strokeStyle = isDark ? 'rgba(165, 180, 252, 0.28)' : 'rgba(79, 70, 229, 0.35)';
        ctx.lineWidth = 1.4;
        ctx.setLineDash([3, 7]);
        ctx.stroke();
      }

      ctx.setLineDash([]);
    });
  }

  function drawCargoPackets() {
    cargoPackets.forEach(pkt => {
      pkt.progress += pkt.speed * speedMultiplier;
      if (pkt.progress >= 1) pkt.progress = 0;

      const route = routes[pkt.routeIndex];
      if (!route) return;

      const pt = getPointOnRoute(route, pkt.progress);

      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pkt.size, 0, Math.PI * 2);
      ctx.fillStyle = pkt.color;
      ctx.shadowColor = pkt.color;
      ctx.shadowBlur = 6;
      ctx.fill();
      ctx.shadowBlur = 0;
    });
  }

  function drawContrails() {
    // Fading contrail vapor particles left by jets
    const isDark = currentTheme === 'dark';

    for (let i = contrailParticles.length - 1; i >= 0; i--) {
      const p = contrailParticles[i];
      p.life -= 0.012;
      p.size += 0.2;
      if (p.life <= 0) {
        contrailParticles.splice(i, 1);
        continue;
      }

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = isDark
        ? `rgba(255, 255, 255, ${p.life * 0.22})`
        : `rgba(99, 102, 241, ${p.life * 0.20})`;
      ctx.fill();
    }
  }

  function drawWakeParticles() {
    // Wake bubbles created by vessels
    const isDark = currentTheme === 'dark';

    for (let i = wakeParticles.length - 1; i >= 0; i--) {
      const p = wakeParticles[i];
      p.life -= 0.015;
      p.size += 0.15;
      if (p.life <= 0) {
        wakeParticles.splice(i, 1);
        continue;
      }

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = isDark
        ? `rgba(224, 242, 254, ${p.life * 0.35})`
        : `rgba(2, 132, 199, ${p.life * 0.25})`;
      ctx.fill();
    }
  }

  function drawVessels() {
    const isDark = currentTheme === 'dark';

    vessels.forEach(vessel => {
      vessel.progress += vessel.speed * speedMultiplier;
      if (vessel.progress >= 1) vessel.progress = 0;

      const route = routes[vessel.routeIndex];
      if (!route) return;
      const pt = getPointOnRoute(route, vessel.progress);

      // Push foam particles behind vessel
      if (Math.random() < 0.35) {
        wakeParticles.push({
          x: pt.x - Math.cos(pt.angle) * 18 + (Math.random() - 0.5) * 6,
          y: pt.y - Math.sin(pt.angle) * 18 + (Math.random() - 0.5) * 6,
          size: 1.5,
          life: 1.0
        });
      }

      ctx.save();
      ctx.translate(pt.x, pt.y);
      ctx.rotate(pt.angle);

      // Bow Thruster V-Waves
      ctx.beginPath();
      ctx.moveTo(18, 0);
      ctx.lineTo(-6, -14);
      ctx.moveTo(18, 0);
      ctx.lineTo(-6, 14);
      ctx.strokeStyle = isDark ? 'rgba(56, 189, 248, 0.4)' : 'rgba(2, 132, 199, 0.45)';
      ctx.lineWidth = 1.4;
      ctx.stroke();

      // Twin Wake Foam Trails
      ctx.beginPath();
      ctx.moveTo(-16, -6);
      ctx.lineTo(-38, -12);
      ctx.moveTo(-16, 6);
      ctx.lineTo(-38, 12);
      ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.3)' : 'rgba(203, 213, 225, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Steel Container Ship Hull
      ctx.fillStyle = isDark ? '#0f172a' : '#1e293b';
      ctx.strokeStyle = isDark ? '#38bdf8' : '#0284c7';
      ctx.lineWidth = 1.2;

      ctx.beginPath();
      ctx.moveTo(20, 0);           // Bow point
      ctx.lineTo(12, -7);
      ctx.lineTo(-18, -7);         // Port side
      ctx.lineTo(-20, -5);         // Transom stern
      ctx.lineTo(-20, 5);
      ctx.lineTo(-18, 7);          // Starboard side
      ctx.lineTo(12, 7);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Container Stacks Deck
      if (vessel.containers) {
        const startX = -14;
        const boxW = 8;
        const boxH = 4;
        vessel.containers.forEach((bay, colIdx) => {
          bay.forEach((col, rowIdx) => {
            ctx.fillStyle = col;
            ctx.fillRect(startX + colIdx * 9, -5 + rowIdx * 4, boxW, boxH);
            ctx.strokeStyle = 'rgba(0, 0, 0, 0.4)';
            ctx.lineWidth = 0.5;
            ctx.strokeRect(startX + colIdx * 9, -5 + rowIdx * 4, boxW, boxH);
          });
        });
      }

      // Bridge / Deckhouse
      ctx.fillStyle = isDark ? '#334155' : '#f8fafc';
      ctx.fillRect(-17, -4, 5, 8);

      // Rotating Marine Radar Scanner
      vessel.radarAngle += 0.12;
      const radX = -14.5;
      const radY = 0;
      ctx.beginPath();
      ctx.moveTo(radX, radY);
      ctx.lineTo(radX + Math.cos(vessel.radarAngle) * 7, radY + Math.sin(vessel.radarAngle) * 7);
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.restore();

      // Vessel HUD Tag
      ctx.fillStyle = isDark ? '#e0f2fe' : '#0f172a';
      ctx.font = '700 9px "JetBrains Mono", monospace';
      ctx.fillText(`🚢 ${vessel.name}`, pt.x + 18, pt.y - 8);

      ctx.fillStyle = isDark ? '#94a3b8' : '#475569';
      ctx.font = '500 8px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(vessel.callsign, pt.x + 18, pt.y + 6);
    });
  }

  function drawTrucks() {
    trucks.forEach(truck => {
      truck.progress += truck.speed * speedMultiplier;
      if (truck.progress >= 1) truck.progress = 0;

      const route = routes[truck.routeIndex];
      if (!route) return;
      const pt = getPointOnRoute(route, truck.progress);

      ctx.save();
      ctx.translate(pt.x, pt.y);
      ctx.rotate(pt.angle);

      // Twin Headlight Beams
      const lightGrad = ctx.createRadialGradient(16, 0, 2, 45, 0, 36);
      lightGrad.addColorStop(0, 'rgba(254, 240, 138, 0.5)');
      lightGrad.addColorStop(1, 'rgba(254, 240, 138, 0)');

      ctx.fillStyle = lightGrad;
      ctx.beginPath();
      ctx.moveTo(12, 0);
      ctx.lineTo(44, -12);
      ctx.lineTo(44, 12);
      ctx.closePath();
      ctx.fill();

      // Red Taillight Streaks
      ctx.beginPath();
      ctx.moveTo(-18, -4);
      ctx.lineTo(-32, -4);
      ctx.moveTo(-18, 4);
      ctx.lineTo(-32, 4);
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Trailer Chassis
      ctx.fillStyle = truck.trailerColor;
      ctx.fillRect(-18, -6, 22, 12);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.strokeRect(-18, -6, 22, 12);

      // Cab
      ctx.fillStyle = truck.cabColor;
      ctx.fillRect(4, -5, 9, 10);

      // Windshield
      ctx.fillStyle = '#0ea5e9';
      ctx.fillRect(9, -4, 3, 8);

      ctx.restore();

      // Truck HUD Callout Tag
      ctx.fillStyle = currentTheme === 'dark' ? '#fef08a' : '#854d0e';
      ctx.font = '700 9px "JetBrains Mono", monospace';
      ctx.fillText(`🚛 ${truck.name}`, pt.x + 14, pt.y - 7);

      ctx.fillStyle = currentTheme === 'dark' ? '#94a3b8' : '#475569';
      ctx.font = '600 8px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(truck.cargo, pt.x + 14, pt.y + 6);
    });
  }

  // -------------------------------------------------------------
  // AIR CARGO FLEET (B747-8F, B777F, A350F, MD-11F, C-17)
  // -------------------------------------------------------------
  function drawPlanes() {
    const isDark = currentTheme === 'dark';

    planes.forEach(plane => {
      plane.progress += plane.speed * speedMultiplier;
      if (plane.progress >= 1) plane.progress = 0;

      const route = routes[plane.routeIndex];
      if (!route) return;
      const pt = getPointOnRoute(route, plane.progress);

      // Spawn contrail smoke behind plane engines
      if (Math.random() < 0.45) {
        contrailParticles.push({
          x: pt.x - Math.cos(pt.angle) * 16 + (Math.random() - 0.5) * 4,
          y: pt.y - Math.sin(pt.angle) * 16 + (Math.random() - 0.5) * 4,
          size: 2.2,
          life: 1.0
        });
      }

      ctx.save();
      ctx.translate(pt.x, pt.y);
      ctx.rotate(pt.angle);

      // 1. Dual / Quad Contrail Vapor Streaks
      ctx.beginPath();
      if (plane.engines === 4) {
        // Quad engine contrails (B747-8F / C-17)
        ctx.moveTo(-10, -9);  ctx.lineTo(-50, -11);
        ctx.moveTo(-10, -5);  ctx.lineTo(-50, -6);
        ctx.moveTo(-10, 5);   ctx.lineTo(-50, 6);
        ctx.moveTo(-10, 9);   ctx.lineTo(-50, 11);
      } else if (plane.engines === 3) {
        // Tri-jet engine contrails (MD-11F)
        ctx.moveTo(-10, -7);  ctx.lineTo(-48, -9);
        ctx.moveTo(-14, 0);   ctx.lineTo(-52, 0); // Center tail engine
        ctx.moveTo(-10, 7);   ctx.lineTo(-48, 9);
      } else {
        // Twin engine contrails (B777F / A350F / B767F)
        ctx.moveTo(-12, -6);  ctx.lineTo(-50, -8);
        ctx.moveTo(-12, 6);   ctx.lineTo(-50, 8);
      }
      ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.28)' : 'rgba(79, 70, 229, 0.25)';
      ctx.lineWidth = 1.6;
      ctx.stroke();

      // 2. High-Fidelity Aircraft Silhouette
      ctx.fillStyle = isDark ? '#f8fafc' : '#1e293b';
      ctx.strokeStyle = isDark ? '#38bdf8' : '#4f46e5';
      ctx.lineWidth = 1.0;

      ctx.beginPath();
      if (plane.model === '747-8F') {
        // B747-8F Heavy Freighter (Longer fuselage + iconic upper deck hump)
        ctx.moveTo(18, 0);           // Nose
        ctx.lineTo(14, -3);          // Upper cockpit hump
        ctx.lineTo(4, -3);
        ctx.lineTo(2, -16);          // Port swept wing
        ctx.lineTo(0, -17);
        ctx.lineTo(3, -3);
        ctx.lineTo(-12, -3);
        ctx.lineTo(-18, -8);         // Port tail horizontal stabilizer
        ctx.lineTo(-20, -7);
        ctx.lineTo(-16, 0);          // Tail cone
        ctx.lineTo(-20, 7);          // Starboard tail stabilizer
        ctx.lineTo(-18, 8);
        ctx.lineTo(-12, 3);
        ctx.lineTo(3, 3);
        ctx.lineTo(0, 17);           // Starboard swept wing
        ctx.lineTo(2, 16);
        ctx.lineTo(4, 3);
        ctx.lineTo(14, 3);
      } else {
        // Widebody Jet (777F / A350F / MD-11F / C-17)
        ctx.moveTo(16, 0);           // Nose
        ctx.lineTo(4, -14);          // Left Wing
        ctx.lineTo(2, -14);
        ctx.lineTo(5, -2);
        ctx.lineTo(-11, -2);
        ctx.lineTo(-15, -7);         // Left Tail
        ctx.lineTo(-14, 0);
        ctx.lineTo(-15, 7);          // Right Tail
        ctx.lineTo(-11, 2);
        ctx.lineTo(5, 2);
        ctx.lineTo(2, 14);           // Right Wing
        ctx.lineTo(4, 14);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // 3. Jet Turbofan Engines Under Wings
      ctx.fillStyle = isDark ? '#0284c7' : '#4338ca';
      if (plane.engines === 4) {
        ctx.fillRect(-2, -11, 6, 2.5);
        ctx.fillRect(-2, -7, 6, 2.5);
        ctx.fillRect(-2, 5, 6, 2.5);
        ctx.fillRect(-2, 9, 6, 2.5);
      } else if (plane.engines === 3) {
        ctx.fillRect(-2, -8, 6, 2.5);
        ctx.fillRect(-16, -1.5, 5, 3); // Tail engine
        ctx.fillRect(-2, 6, 6, 2.5);
      } else {
        ctx.fillRect(-2, -7, 6, 2.5);
        ctx.fillRect(-2, 5, 6, 2.5);
      }

      // 4. Aviation Navigation Strobes
      plane.strobeTick += 0.16;
      const isStrobe = Math.sin(plane.strobeTick * 6) > 0.7;

      // Port (Left) Nav Light - RED
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(2, -15, 2, 0, Math.PI * 2);
      ctx.fill();

      // Starboard (Right) Nav Light - GREEN
      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.arc(2, 15, 2, 0, Math.PI * 2);
      ctx.fill();

      // Anti-Collision Strobes - Pulsing WHITE
      if (isStrobe) {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(2, -15, 3.5, 0, Math.PI * 2);
        ctx.arc(2, 15, 3.5, 0, Math.PI * 2);
        ctx.arc(-14, 0, 3, 0, Math.PI * 2); // Tail strobe
        ctx.fill();
      }

      ctx.restore();

      // Aviation HUD Telemetry Tag
      ctx.fillStyle = isDark ? '#c7d2fe' : '#1e1b4b';
      ctx.font = '700 9px "JetBrains Mono", monospace';
      ctx.fillText(`✈️ ${plane.name}`, pt.x + 18, pt.y - 8);

      ctx.fillStyle = isDark ? '#94a3b8' : '#475569';
      ctx.font = '600 8px "JetBrains Mono", monospace';
      ctx.fillText(`${plane.cargo} • ${plane.altitude} • ${plane.knots}`, pt.x + 18, pt.y + 6);
    });
  }

  function drawLogisticsNodes() {
    const isDark = currentTheme === 'dark';

    nodes.forEach(node => {
      // Radar Beacon Radiations
      const beaconSize = 10 + ((time * 22 + node.x) % 36);
      const beaconAlpha = Math.max(0, 1 - beaconSize / 46);

      ctx.beginPath();
      ctx.arc(node.x, node.y, beaconSize, 0, Math.PI * 2);
      ctx.strokeStyle = node.accent;
      ctx.lineWidth = 1.2;
      ctx.globalAlpha = beaconAlpha * (isDark ? 0.7 : 0.85);
      ctx.stroke();
      ctx.globalAlpha = ambientAlpha;

      // Node Structure Graphics
      if (node.type === 'stadium') {
        // Detailed Oval Arena Graphics (🏟️)
        ctx.save();
        ctx.translate(node.x, node.y);

        // Outer Bowl
        ctx.fillStyle = isDark ? 'rgba(15, 23, 42, 0.85)' : 'rgba(255, 255, 255, 0.95)';
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(0, 0, 18, 12, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Pitch / Field
        ctx.fillStyle = '#059669';
        ctx.beginPath();
        ctx.ellipse(0, 0, 11, 6.5, 0, 0, Math.PI * 2);
        ctx.fill();

        // Pitch center line
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, -6.5);
        ctx.lineTo(0, 6.5);
        ctx.stroke();

        // Sweeping Floodlights
        const sweepRot = time * 1.5;
        ctx.strokeStyle = 'rgba(254, 240, 138, 0.45)';
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(-16, -9);
        ctx.lineTo(-16 + Math.cos(sweepRot) * 22, -9 + Math.sin(sweepRot) * 22);
        ctx.moveTo(16, 9);
        ctx.lineTo(16 - Math.cos(sweepRot) * 22, 9 - Math.sin(sweepRot) * 22);
        ctx.stroke();

        ctx.restore();

        // Stadium Badge
        ctx.fillStyle = '#10b981';
        ctx.font = '800 10px "Plus Jakarta Sans", sans-serif';
        ctx.fillText(`🏟️ ${node.name}`, node.x + 24, node.y - 5);

        ctx.fillStyle = isDark ? '#94a3b8' : '#475569';
        ctx.font = '600 8px "JetBrains Mono", monospace';
        ctx.fillText(node.status, node.x + 24, node.y + 7);

      } else if (node.type === 'purchasing') {
        // London Sourcing Clearinghouse (📋)
        ctx.save();
        ctx.translate(node.x, node.y);

        ctx.fillStyle = isDark ? 'rgba(30, 27, 75, 0.9)' : 'rgba(238, 242, 255, 0.95)';
        ctx.strokeStyle = '#6366f1';
        ctx.lineWidth = 1.5;
        ctx.fillRect(-14, -14, 28, 28);
        ctx.strokeRect(-14, -14, 28, 28);

        ctx.fillStyle = '#6366f1';
        ctx.font = '700 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('📋', 0, 0);

        ctx.restore();

        ctx.fillStyle = '#818cf8';
        ctx.font = '800 10px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`📋 ${node.name}`, node.x + 20, node.y - 5);

        ctx.fillStyle = isDark ? '#94a3b8' : '#475569';
        ctx.font = '600 8px "JetBrains Mono", monospace';
        ctx.fillText(node.status, node.x + 20, node.y + 7);

      } else {
        // Ports, Freight & Gateways
        ctx.beginPath();
        ctx.arc(node.x, node.y, 7, 0, Math.PI * 2);
        ctx.fillStyle = isDark ? '#0f172a' : '#ffffff';
        ctx.strokeStyle = node.accent;
        ctx.lineWidth = 2;
        ctx.fill();
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(node.x, node.y, 3, 0, Math.PI * 2);
        ctx.fillStyle = node.accent;
        ctx.fill();

        ctx.fillStyle = isDark ? '#f8fafc' : '#0f172a';
        ctx.font = '800 10px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`${node.icon} ${node.name}`, node.x + 14, node.y - 4);

        ctx.fillStyle = isDark ? '#94a3b8' : '#475569';
        ctx.font = '600 8px "JetBrains Mono", monospace';
        ctx.fillText(node.status, node.x + 14, node.y + 8);
      }
    });
  }

  function drawInteractiveTelemetry() {
    // Sonar Cursor Sweep
    if (mouse.active) {
      const sweep = (time * 3) % (Math.PI * 2);
      ctx.beginPath();
      ctx.arc(mouse.x, mouse.y, mouse.radius, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.2)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(mouse.x, mouse.y);
      ctx.arc(mouse.x, mouse.y, mouse.radius, sweep, sweep + 0.35);
      ctx.closePath();
      ctx.fillStyle = 'rgba(56, 189, 248, 0.08)';
      ctx.fill();
    }

    // Click Shockwave
    if (mouse.clickRipple > 0) {
      ctx.beginPath();
      ctx.arc(mouse.clickX, mouse.clickY, (1 - mouse.clickRipple) * 260, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(56, 189, 248, ${mouse.clickRipple * 0.7})`;
      ctx.lineWidth = 2.5;
      ctx.stroke();
      mouse.clickRipple -= 0.02;
    }
  }

  // Event Listeners for Interaction
  function handleMouseMove(e) {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
    mouse.active = true;
  }

  function handleMouseLeave() {
    mouse.active = false;
  }

  function handleClick(e) {
    const rect = canvas.getBoundingClientRect();
    mouse.clickX = e.clientX - rect.left;
    mouse.clickY = e.clientY - rect.top;
    mouse.clickRipple = 1.0;

    // Temporary surge in logistics activity
    speedMultiplier = 1.8;
    setTimeout(() => {
      speedMultiplier = 1.0;
    }, 1500);
  }

  window.addEventListener('resize', resize);
  canvas.addEventListener('mousemove', handleMouseMove);
  canvas.addEventListener('mouseleave', handleMouseLeave);
  canvas.addEventListener('click', handleClick);

  resize();
  animFrameId = requestAnimationFrame(render);

  return () => {
    window.removeEventListener('resize', resize);
    canvas.removeEventListener('mousemove', handleMouseMove);
    canvas.removeEventListener('mouseleave', handleMouseLeave);
    canvas.removeEventListener('click', handleClick);
    if (animFrameId) cancelAnimationFrame(animFrameId);
  };
}

/**
 * Retain initDashboardRadar export for backwards-compatibility
 */
export function initDashboardRadar(canvasId = 'dashboard-radar-canvas') {
  return null;
}
