/**
 * Content Protection & Anti-Copy Security Engine
 * 
 * NOTE: OS-level screenshots cannot be technically blocked by a webpage.
 * This security layer provides deterrence, access obfuscation, and audit logging.
 */

import { apiConfig } from './api-config.js';

document.addEventListener('DOMContentLoaded', () => {
  const activeStudent = apiConfig.getStoredStudent();
  const urlParams = new URLSearchParams(window.location.search);
  const moduleCode = urlParams.get('module') || 'GENERAL';
  const studentEmail = activeStudent ? activeStudent.email : 'Unknown';

  const blurBanner = document.getElementById('security-blur-banner');
  const btnResume = document.getElementById('btn-resume-view');
  const watermarkContainer = document.getElementById('watermark-overlay');

  let alertCooldown = false;

  // 1. Generate Dynamic Watermark Overlay
  if (watermarkContainer) {
    const timestampStr = new Date().toLocaleDateString('en-GB', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
    const watermarkText = `${studentEmail} • CIPS LMS SECURED • ${timestampStr}`;

    // Create 12 tiled watermark instances
    let tilesHtml = '';
    for (let i = 0; i < 12; i++) {
      tilesHtml += `<div class="watermark-text">${watermarkText}</div>`;
    }
    watermarkContainer.innerHTML = tilesHtml;
  }

  // 2. Disable Right-Click Context Menu
  document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    triggerSecurityAlert('RIGHT_CLICK_ATTEMPT', 'User attempted right-click context menu access.');
    return false;
  });

  // 3. Disable Keyboard Shortcuts (Ctrl+P, Ctrl+S, Ctrl+Shift+I, F12, Ctrl+U, etc.)
  document.addEventListener('keydown', (e) => {
    // F12 key
    if (e.key === 'F12' || e.keyCode === 123) {
      e.preventDefault();
      triggerSecurityAlert('DEVTOOLS_F12_KEY', 'F12 Developer Tools key pressed.');
      pauseAndBlur('DevTools Shortcut Detected');
      return false;
    }

    // Ctrl / Cmd combinations
    if (e.ctrlKey || e.metaKey) {
      const key = e.key.toLowerCase();
      // Print (Ctrl+P), Save (Ctrl+S), View Source (Ctrl+U)
      if (key === 'p' || key === 's' || key === 'u') {
        e.preventDefault();
        triggerSecurityAlert(`KEYBOARD_SHORTCUT_${key.toUpperCase()}`, `Shortcut Ctrl+${key.toUpperCase()} pressed.`);
        pauseAndBlur('Print/Save Attempt Detected');
        return false;
      }

      // DevTools (Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+Shift+C)
      if (e.shiftKey && (key === 'i' || key === 'j' || key === 'c')) {
        e.preventDefault();
        triggerSecurityAlert('DEVTOOLS_SHORTCUT', `Shortcut Ctrl+Shift+${key.toUpperCase()} pressed.`);
        pauseAndBlur('Developer Tools Inspector Attempt');
        return false;
      }
    }
  });

  // 4. Tab Focus Loss & Window Resize Detection (Screenshot / Screen Grab Pattern)
  window.addEventListener('blur', () => {
    triggerSecurityAlert('WINDOW_BLUR', 'Window focus lost / screen capture application interaction.');
    pauseAndBlur('Tab Focus Lost');
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      triggerSecurityAlert('TAB_HIDDEN', 'Tab hidden / window minimized.');
      pauseAndBlur('Tab Hidden');
    }
  });

  let initialWidth = window.innerWidth;
  window.addEventListener('resize', () => {
    const widthDiff = Math.abs(window.innerWidth - initialWidth);
    // Suspicious window resize anomaly (> 180px rapid shift often caused by screen capture overlay tools or DevTools docking)
    if (widthDiff > 180) {
      triggerSecurityAlert('SUSPICIOUS_WINDOW_RESIZE', `Window resized rapidly by ${widthDiff}px.`);
      initialWidth = window.innerWidth;
    }
  });

  // Resume viewing button event
  if (btnResume && blurBanner) {
    btnResume.addEventListener('click', () => {
      blurBanner.style.display = 'none';
    });
  }

  function pauseAndBlur(reason) {
    // Pause any playing HTML5 video
    const videos = document.querySelectorAll('video');
    videos.forEach(v => {
      if (!v.paused) v.pause();
    });

    if (blurBanner) {
      blurBanner.style.display = 'flex';
    }
  }

  function triggerSecurityAlert(type, details) {
    if (alertCooldown) return;
    alertCooldown = true;

    apiConfig.postSecurityAlert(studentEmail, moduleCode, type, details);

    // 3 second cooldown to avoid spamming alerts
    setTimeout(() => {
      alertCooldown = false;
    }, 3000);
  }
});
