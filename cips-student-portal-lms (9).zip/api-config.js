/**
 * API Config & Wrapper Layer
 * Centralized client API communication for both the CIPS Student Portal & Admin Panel
 */

const API_BASE_URL = window.location.origin;

export const apiConfig = {
  baseUrl: API_BASE_URL,

  /**
   * Helper to retrieve or generate persistent device token
   */
  getDeviceToken() {
    let token = localStorage.getItem('cips_device_token');
    if (!token) {
      token = 'DEV_TOK_' + Math.random().toString(36).substring(2, 11) + '_' + Date.now().toString(36);
      localStorage.setItem('cips_device_token', token);
    }
    return token;
  },

  /**
   * Generates browser + OS fingerprint
   */
  getDeviceFingerprint() {
    const userAgent = navigator.userAgent;
    let browser = 'Unknown Browser';
    if (userAgent.indexOf('Chrome') > -1) browser = 'Chrome';
    else if (userAgent.indexOf('Safari') > -1) browser = 'Safari';
    else if (userAgent.indexOf('Firefox') > -1) browser = 'Firefox';
    else if (userAgent.indexOf('Edg') > -1) browser = 'Edge';

    let os = 'Unknown OS';
    if (userAgent.indexOf('Win') > -1) os = 'Windows';
    else if (userAgent.indexOf('Mac') > -1) os = 'macOS';
    else if (userAgent.indexOf('Linux') > -1) os = 'Linux';
    else if (userAgent.indexOf('Android') > -1) os = 'Android';
    else if (userAgent.indexOf('iPhone') > -1) os = 'iOS';

    return {
      browser,
      os,
      deviceToken: this.getDeviceToken()
    };
  },

  /**
   * Student session helpers
   */
  getStoredStudent() {
    const raw = sessionStorage.getItem('cips_active_student') || localStorage.getItem('cips_active_student');
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  },

  setStoredStudent(studentData) {
    sessionStorage.setItem('cips_active_student', JSON.stringify(studentData));
    localStorage.setItem('cips_active_student', JSON.stringify(studentData));
  },

  clearStoredStudent() {
    sessionStorage.removeItem('cips_active_student');
    localStorage.removeItem('cips_active_student');
  },

  /**
   * Admin session helpers
   */
  getStoredAdmin() {
    const raw = sessionStorage.getItem('cips_admin_session') || localStorage.getItem('cips_admin_session');
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  },

  setStoredAdmin(adminData) {
    sessionStorage.setItem('cips_admin_session', JSON.stringify(adminData));
    localStorage.setItem('cips_admin_session', JSON.stringify(adminData));
  },

  clearStoredAdmin() {
    sessionStorage.removeItem('cips_admin_session');
    localStorage.removeItem('cips_admin_session');
  },

  /**
   * Student Login
   */
  async login(studentId, email, password) {
    const fingerprint = this.getDeviceFingerprint();
    const res = await fetch(`${this.baseUrl}/api/student/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentId: studentId.trim(),
        email: email.trim().toLowerCase(),
        password: password ? password.trim() : '',
        deviceFingerprint: fingerprint
      })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Login failed');
    }

    this.setStoredStudent({
      studentId: data.student.studentId,
      email: data.student.email,
      name: data.student.name || data.student.studentId,
      deviceToken: data.deviceToken
    });

    return data;
  },

  /**
   * Student Registration
   */
  async register(studentId, email, password, name) {
    const fingerprint = this.getDeviceFingerprint();
    const res = await fetch(`${this.baseUrl}/api/student/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentId: studentId.trim(),
        email: email.trim().toLowerCase(),
        password: password.trim(),
        name: name || studentId.trim(),
        deviceFingerprint: fingerprint
      })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Registration failed');
    }

    this.setStoredStudent({
      studentId: data.student.studentId,
      email: data.student.email,
      name: data.student.name || data.student.studentId,
      deviceToken: data.deviceToken
    });

    return data;
  },

  /**
   * Fetch Access Control List for student
   */
  async getAccess(studentEmail) {
    const res = await fetch(`${this.baseUrl}/api/access/${encodeURIComponent(studentEmail)}`);
    if (!res.ok) {
      throw new Error('Failed to fetch access rules');
    }
    return await res.json();
  },

  /**
   * Fetch All CIPS Modules Dataset
   */
  async getModulesData() {
    const res = await fetch(`${this.baseUrl}/api/modules-data`);
    if (!res.ok) {
      throw new Error('Failed to load CIPS modules dataset');
    }
    return await res.json();
  },

  /**
   * Fetch Module Content
   */
  async getModuleContent(moduleCode, studentEmail) {
    const url = `${this.baseUrl}/api/module-content/${encodeURIComponent(moduleCode)}?email=${encodeURIComponent(studentEmail)}`;
    const res = await fetch(url);
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to load module content');
    }
    return data;
  },

  /**
   * Verify Quiz Password & Attempt Count
   */
  async verifyQuizPassword(email, quizPassword, moduleCode) {
    const res = await fetch(`${this.baseUrl}/api/quiz-access/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, quizPassword, moduleCode })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Quiz authentication failed');
    }
    return data;
  },

  /**
   * Submit Quiz Results
   */
  async submitQuizAnswers(resultsPayload) {
    const res = await fetch(`${this.baseUrl}/api/quiz-results`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(resultsPayload)
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to submit quiz results');
    }
    return data;
  },

  /**
   * Fetch a student's personal quiz result history
   */
  async getStudentQuizResults(studentEmail) {
    const email = studentEmail || (this.getStoredStudent() ? this.getStoredStudent().email : '');
    if (!email) return [];
    try {
      const res = await fetch(`${this.baseUrl}/api/student/quiz-results?studentEmail=${encodeURIComponent(email)}`);
      if (res.ok) {
        const data = await res.json();
        return data.results || [];
      }
    } catch (e) {
      console.warn('Student quiz results primary fetch error:', e);
    }
    // Fallback to admin results query
    try {
      const fallbackRes = await fetch(`${this.baseUrl}/api/admin/quiz-results?studentEmail=${encodeURIComponent(email)}`);
      if (fallbackRes.ok) {
        const data = await fallbackRes.json();
        return data.results || [];
      }
    } catch (err) {
      console.warn('Fallback quiz results fetch error:', err);
    }
    return [];
  },

  /**
   * Fetch single quiz result details including questions snapshot
   */
  async getQuizResultDetail(resultId) {
    try {
      const res = await fetch(`${this.baseUrl}/api/student/quiz-results/${encodeURIComponent(resultId)}`);
      if (res.ok) {
        const data = await res.json();
        return data.result;
      }
    } catch (e) {
      console.warn('Error fetching quiz result detail:', e);
    }
    return null;
  },

  /**
   * Report Security Event / DevTools detection
   */
  async postSecurityAlert(studentEmail, moduleCode, type, details) {
    try {
      await fetch(`${this.baseUrl}/api/security-alert`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentEmail, moduleCode, type, details })
      });
    } catch (e) {
      console.warn('Security event broadcast error:', e);
    }
  },

  // ==========================================
  // ADMIN PANEL CLIENT METHODS
  // ==========================================

  async adminLogin(username, password) {
    const res = await fetch(`${this.baseUrl}/api/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Admin login failed');
    }

    this.setStoredAdmin({
      username: data.username,
      token: data.token,
      isFirstLogin: data.isFirstLogin
    });

    return data;
  },

  async changeAdminPassword(username, currentPassword, newPassword) {
    const res = await fetch(`${this.baseUrl}/api/admin/change-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, currentPassword, newPassword })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to update admin password');
    }

    const admin = this.getStoredAdmin();
    if (admin) {
      admin.isFirstLogin = false;
      this.setStoredAdmin(admin);
    }

    return data;
  },

  async getAdminStudents() {
    const res = await fetch(`${this.baseUrl}/api/admin/students`);
    if (!res.ok) throw new Error('Failed to fetch students list');
    return await res.json();
  },

  async getAllStudents() {
    return await this.getAdminStudents();
  },

  async saveStudent(studentPayload) {
    const res = await fetch(`${this.baseUrl}/api/admin/students/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(studentPayload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save student');
    return data;
  },

  async approveDeviceLock(studentEmail, eventId) {
    const res = await fetch(`${this.baseUrl}/api/admin/device-unlock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentEmail, eventId })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to approve device unlock');
    return data;
  },

  async revokeStudentAccess(studentEmail) {
    const res = await fetch(`${this.baseUrl}/api/admin/revoke-access`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentEmail })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to revoke student session');
    return data;
  },

  async deleteStudent(email) {
    const res = await fetch(`${this.baseUrl}/api/admin/students/${encodeURIComponent(email)}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete student');
    return data;
  },

  async toggleStudentAccess(studentEmail, accessStatus) {
    const res = await fetch(`${this.baseUrl}/api/admin/students/toggle-access`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentEmail, accessStatus })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to toggle student access');
    return data;
  },

  async toggleStudentQuizAccess(studentEmail, quizAccessStatus) {
    const res = await fetch(`${this.baseUrl}/api/admin/students/toggle-quiz-access`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentEmail, quizAccessStatus })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to toggle student quiz access');
    return data;
  },

  async deleteQuizPassword(target) {
    const res = await fetch(`${this.baseUrl}/api/admin/quiz-passwords/${encodeURIComponent(target)}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete quiz password entry');
    return data;
  },

  async getStudentRemarks(email, moduleCode, docId) {
    const res = await fetch(`${this.baseUrl}/api/student/remarks?email=${encodeURIComponent(email)}&moduleCode=${encodeURIComponent(moduleCode)}&docId=${encodeURIComponent(docId)}`);
    if (!res.ok) throw new Error('Failed to fetch remarks');
    const data = await res.json();
    return data.remarks;
  },

  async saveStudentRemarks(email, moduleCode, docId, remarks, drawings) {
    const res = await fetch(`${this.baseUrl}/api/student/remarks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, moduleCode, docId, remarks, drawings })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save remarks');
    return data;
  },

  async getActiveMonitoring() {
    const res = await fetch(`${this.baseUrl}/api/admin/active-monitoring`);
    if (!res.ok) throw new Error('Failed to fetch active monitoring data');
    return await res.json();
  },

  async saveAdminModuleContent(moduleCode, contentPayload) {
    const res = await fetch(`${this.baseUrl}/api/admin/module-content/${encodeURIComponent(moduleCode)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(contentPayload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save module content');
    return data;
  },

  async getAdminQuizPasswords() {
    const res = await fetch(`${this.baseUrl}/api/admin/quiz-passwords`);
    if (!res.ok) throw new Error('Failed to fetch quiz passwords');
    return await res.json();
  },

  async getStudentQuizMatrix() {
    const res = await fetch(`${this.baseUrl}/api/admin/quiz-passwords/student-matrix`);
    if (!res.ok) throw new Error('Failed to fetch student quiz matrix');
    return await res.json();
  },

  async saveAdminQuizPassword(payload) {
    const res = await fetch(`${this.baseUrl}/api/admin/quiz-passwords/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save quiz password settings');
    return data;
  },

  async setCustomStudentQuizLimit(studentEmail, moduleCode, customLimit) {
    const res = await fetch(`${this.baseUrl}/api/admin/quiz-passwords/custom-limit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentEmail, moduleCode, customLimit })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to set custom student quiz limit');
    return data;
  },

  async resetStudentQuizAttempts(studentEmail, moduleCode = 'ALL') {
    const res = await fetch(`${this.baseUrl}/api/admin/quiz-passwords/reset-attempts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentEmail, moduleCode })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to reset quiz attempts');
    return data;
  },

  async clearAllCustomStudentQuizLimits() {
    const res = await fetch(`${this.baseUrl}/api/admin/quiz-passwords/clear-all-custom-limits`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to clear custom student limits');
    return data;
  },

  async importQuizCSV(moduleCode, questions) {
    const res = await fetch(`${this.baseUrl}/api/admin/import-quiz`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ moduleCode, questions })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to import quiz bank');
    return data;
  },

  async convertDocumentToQuiz(formData) {
    const res = await fetch(`${this.baseUrl}/api/convert-document`, {
      method: 'POST',
      body: formData
    });

    let data;
    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      data = await res.json();
    } else {
      const raw = await res.text();
      const clean = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      throw new Error(clean || `Server returned unexpected response (HTTP ${res.status})`);
    }

    if (!res.ok) {
      throw new Error(data.error || data.message || `Document conversion failed (Status ${res.status})`);
    }
    return data;
  },

  async exportQuestionsCsvFile(questions, fileName = 'CIPS_Quiz_Questions') {
    const res = await fetch(`${this.baseUrl}/api/export/csv`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ questions, fileName })
    });
    if (!res.ok) throw new Error('Failed to export CSV file');
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (fileName.replace(/\.[^/.]+$/, '') || 'CIPS_Quiz_Questions') + '.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  },

  async exportQuestionsExcelFile(questions, fileName = 'CIPS_Quiz_Questions') {
    const res = await fetch(`${this.baseUrl}/api/export/excel`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ questions, fileName })
    });
    if (!res.ok) throw new Error('Failed to export Excel file');
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (fileName.replace(/\.[^/.]+$/, '') || 'CIPS_Quiz_Questions') + '.xlsx';
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  },

  async getAdminQuizBank(moduleCode) {
    const res = await fetch(`${this.baseUrl}/api/admin/quiz-bank/${encodeURIComponent(moduleCode)}`);
    if (!res.ok) throw new Error('Failed to fetch quiz bank');
    return await res.json();
  },

  async getAdminIntegrations() {
    const res = await fetch(`${this.baseUrl}/api/admin/integrations`);
    if (!res.ok) throw new Error('Failed to fetch Google integrations config');
    return await res.json();
  },

  async saveAdminIntegrations(googleSheetId, googleDriveFolderId, googleSheetWebhookUrl) {
    const res = await fetch(`${this.baseUrl}/api/admin/integrations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ googleSheetId, googleDriveFolderId, googleSheetWebhookUrl })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save integration config');
    return data;
  },

  async syncAllToGoogleSheets() {
    const res = await fetch(`${this.baseUrl}/api/admin/sync-all-to-sheets`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to bulk sync data to Google Sheets');
    return data;
  },

  async migrateToGoogleSheets() {
    const res = await fetch(`${this.baseUrl}/api/admin/migrate-to-sheets`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to migrate data to Google Sheets');
    return data;
  },

  async testSheetsConnection(webhookUrl) {
    const res = await fetch(`${this.baseUrl}/api/admin/test-sheets-connection`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ webhookUrl })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Connection test failed');
    return data;
  },

  async getAppsScriptTemplate() {
    const res = await fetch(`${this.baseUrl}/api/admin/apps-script-template`);
    if (!res.ok) throw new Error('Failed to fetch Apps Script code template');
    return await res.json();
  },

  async getAdminStudentInquiries() {
    const res = await fetch(`${this.baseUrl}/api/admin/new-students`);
    if (!res.ok) throw new Error('Failed to fetch student inquiries');
    return await res.json();
  },

  async submitNewStudentInquiry(studentData) {
    const res = await fetch(`${this.baseUrl}/api/new-student`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(studentData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to submit student information');
    return data;
  },

  async getAdminDriveFiles(folderId) {
    const url = folderId
      ? `${this.baseUrl}/api/admin/drive-files?folderId=${encodeURIComponent(folderId)}`
      : `${this.baseUrl}/api/admin/drive-files`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch Drive files');
    return await res.json();
  },

  async getAdminAlerts() {
    const res = await fetch(`${this.baseUrl}/api/admin/alerts`);
    if (!res.ok) throw new Error('Failed to fetch alerts feed');
    return await res.json();
  },

  async getAdminQuizResults(studentEmail) {
    const url = studentEmail
      ? `${this.baseUrl}/api/admin/quiz-results?studentEmail=${encodeURIComponent(studentEmail)}`
      : `${this.baseUrl}/api/admin/quiz-results`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch quiz results');
    return await res.json();
  },

  getExportResultsUrl(studentEmail) {
    return studentEmail
      ? `${this.baseUrl}/api/admin/export-results?studentEmail=${encodeURIComponent(studentEmail)}`
      : `${this.baseUrl}/api/admin/export-results`;
  },

  // --- LMS Integration Helpers ---
  async getLmsConfig() {
    const res = await fetch(`${this.baseUrl}/api/lms/config`);
    if (!res.ok) throw new Error('Failed to load LMS config');
    return await res.json();
  },

  async saveLmsConfig(config) {
    const res = await fetch(`${this.baseUrl}/api/lms/config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save LMS config');
    return data;
  },

  async testLmsConnection(config) {
    const res = await fetch(`${this.baseUrl}/api/lms/test-connection`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to test LMS connection');
    return data;
  },

  async exportToLms(payload) {
    const res = await fetch(`${this.baseUrl}/api/lms/export`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to export to LMS');
    return data;
  },

  // --- Student Invoice Management ---
  async getInvoices(studentEmail) {
    const url = studentEmail
      ? `${this.baseUrl}/api/admin/invoices?studentEmail=${encodeURIComponent(studentEmail)}`
      : `${this.baseUrl}/api/admin/invoices`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to load invoices');
    return await res.json();
  },

  async getInvoiceById(id) {
    const res = await fetch(`${this.baseUrl}/api/admin/invoices/${encodeURIComponent(id)}`);
    if (!res.ok) throw new Error('Failed to load invoice details');
    return await res.json();
  },

  async saveInvoice(invoicePayload) {
    const res = await fetch(`${this.baseUrl}/api/admin/invoices`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(invoicePayload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save invoice');
    return data;
  },

  async deleteInvoice(id) {
    const res = await fetch(`${this.baseUrl}/api/admin/invoices/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete invoice');
    return data;
  }
};

window.apiConfig = apiConfig;
