/**
 * Dashboard & Access Control Logic
 * Powered by Logistics, Maritime, Stadium Projects & Purchasing Themes
 */

import { apiConfig } from './api-config.js';
import { initDashboardRadar } from './logistics-animation.js';
import { downloadExamPaperResultPdf } from './exam-result-pdf.js';

document.addEventListener('DOMContentLoaded', async () => {
  const activeStudent = apiConfig.getStoredStudent();
  if (!activeStudent || !activeStudent.email) {
    window.location.href = 'student-login.html';
    return;
  }

  // Initialize Live Logistics Radar Simulator
  let cleanupRadar = null;
  const radarCanvas = document.getElementById('dashboard-radar-canvas');
  if (radarCanvas) {
    cleanupRadar = initDashboardRadar('dashboard-radar-canvas');
  }

  // Setup Radar Toggle
  const btnToggleRadar = document.getElementById('btn-toggle-radar');
  const radarContainer = document.getElementById('radar-container');
  const radarStatusSpan = document.getElementById('radar-toggle-status');
  if (btnToggleRadar && radarContainer) {
    let radarVisible = true;
    btnToggleRadar.addEventListener('click', () => {
      radarVisible = !radarVisible;
      radarContainer.style.display = radarVisible ? 'block' : 'none';
      if (radarStatusSpan) {
        radarStatusSpan.textContent = radarVisible ? 'Online' : 'Standby';
        radarStatusSpan.style.color = radarVisible ? '#059669' : '#64748b';
      }
    });
  }

  // Update navbar user profile
  const userDisplayName = document.getElementById('user-display-name');
  if (userDisplayName) {
    userDisplayName.textContent = `${activeStudent.name || activeStudent.studentId} (${activeStudent.email})`;
  }

  // Handle Logout
  const logoutBtn = document.getElementById('btn-logout-header');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      apiConfig.clearStoredStudent();
      window.location.href = 'student-login.html';
    });
  }

  // Modal elements
  const accessModal = document.getElementById('access-modal');
  const modalLockTitle = document.getElementById('modal-lock-title');
  const modalLockMsg = document.getElementById('modal-lock-message');
  const btnCloseModal = document.getElementById('btn-close-modal');

  if (btnCloseModal) {
    btnCloseModal.addEventListener('click', hideModal);
  }

  function showLockModal(title, message) {
    if (modalLockTitle) modalLockTitle.textContent = title;
    if (modalLockMsg) modalLockMsg.textContent = message;
    if (accessModal) accessModal.classList.add('active');
  }

  function hideModal() {
    if (accessModal) accessModal.classList.remove('active');
  }

  // State variables
  let studentAccess = { approvedLevels: [], approvedModules: [] };
  let modulesDataset = {};

  try {
    // Fetch student's access list and CIPS modules dataset in parallel
    const [accessData, modulesData] = await Promise.all([
      apiConfig.getAccess(activeStudent.email),
      apiConfig.getModulesData()
    ]);

    studentAccess = accessData;
    modulesDataset = modulesData;

    // Update summary badge
    const approvedSummaryText = document.getElementById('approved-summary-text');
    if (approvedSummaryText) {
      const levelsCount = studentAccess.approvedLevels.length;
      const modulesCount = studentAccess.approvedModules.length;
      approvedSummaryText.textContent = `${levelsCount} Level(s) & ${modulesCount} Module(s) Unlocked`;
    }

    renderLevelCards();

    // Initialize Result History & Tab Switching
    initResultHistoryAndTabs();

  } catch (err) {
    console.error('Error initializing dashboard access:', err);
    showLockModal('System Connection Error', 'Unable to load enrollment records. Please refresh or contact support.');
  }

  // Render 5 Level Cards with Logistics, Maritime & Stadium Themes
  function renderLevelCards() {
    const gridContainer = document.getElementById('levels-grid-container');
    if (!gridContainer) return;

    gridContainer.innerHTML = '';

    const levels = [
      { 
        num: 2, 
        key: 'level2', 
        title: 'CIPS Level 2', 
        badge: 'Certificate',
        icon: '🚛',
        domain: 'Inland Freight & Warehouse Logistics',
        domainClass: 'domain-truck',
        sub: 'Truck haulage, delivery dispatch, order fulfillment & inventory control.'
      },
      { 
        num: 3, 
        key: 'level3', 
        title: 'CIPS Level 3', 
        badge: 'Advanced Cert',
        icon: '📋',
        domain: 'Tactical Purchasing & Commercial POs',
        domainClass: 'domain-purchasing',
        sub: 'Requisition lifecycle, Incoterms compliance, supplier expediting & contracts.'
      },
      { 
        num: 4, 
        key: 'level4', 
        title: 'CIPS Level 4', 
        badge: 'Diploma',
        icon: '🚢',
        domain: 'Maritime Shipping & Global Freight',
        domainClass: 'domain-ship',
        sub: 'Ocean container logistics, sea bills of lading, customs & port operations.'
      },
      { 
        num: 5, 
        key: 'level5', 
        title: 'CIPS Level 5', 
        badge: 'Advanced Dip',
        icon: '🏟️',
        domain: 'Stadium Mega-Projects & Turnkey Procurement',
        domainClass: 'domain-stadium',
        sub: 'Arena infrastructure, turf & luminaire tenders, and high-value capital contracts.'
      },
      { 
        num: 6, 
        key: 'level6', 
        title: 'CIPS Level 6', 
        badge: 'Professional',
        icon: '🌐',
        domain: 'Global Supply Chain Ecosystems',
        domainClass: 'domain-global',
        sub: 'Multinational shipping alliances, enterprise risk & sustainable global logistics.'
      }
    ];

    levels.forEach(lvl => {
      const levelData = modulesDataset[lvl.key] || { modules: [] };
      const totalModules = levelData.modules.length;

      // Count how many modules in this level student has access to
      const approvedInLevel = levelData.modules.filter(m => 
        studentAccess.approvedModules.includes(m.code)
      ).length;

      const hasZeroAccess = !studentAccess.approvedLevels.includes(lvl.num) && approvedInLevel === 0;
      const hasFullAccess = approvedInLevel === totalModules && totalModules > 0;

      const card = document.createElement('div');
      card.className = `level-card ${hasZeroAccess ? 'locked-level' : ''}`;

      let statusHtml = '';
      if (hasZeroAccess) {
        statusHtml = `<span class="status-locked">🔒 Locked</span>`;
      } else if (hasFullAccess) {
        statusHtml = `<span class="status-unlocked">✓ Full Access</span>`;
      } else {
        statusHtml = `<span class="status-partial">⚡ ${approvedInLevel}/${totalModules} Unlocked</span>`;
      }

      card.innerHTML = `
        <div>
          <div class="level-card-header">
            <span class="level-number-badge">${lvl.badge}</span>
            ${hasZeroAccess ? '<span class="lock-badge-icon">🔒</span>' : '<span class="lock-badge-icon">🔓</span>'}
          </div>
          <div class="level-card-icon-banner">${lvl.icon}</div>
          <h3 class="level-card-title">${lvl.title}</h3>
          <span class="level-domain-tag ${lvl.domainClass}">${lvl.domain}</span>
          <p class="level-card-sub" style="margin-top: 0.75rem;">${lvl.sub}</p>
        </div>
        <div class="level-card-footer" style="margin-top: 1.25rem;">
          <span>${totalModules} Modules</span>
          ${statusHtml}
        </div>
      `;

      card.addEventListener('click', () => {
        if (hasZeroAccess) {
          // Zero access modal requirement
          showLockModal('Access Denied', `Pay fees to unlock CIPS Level ${lvl.num} (${lvl.domain})`);
        } else {
          // Take directly to the next page for the level's content
          window.location.href = `level-content.html?level=${lvl.num}`;
        }
      });

      gridContainer.appendChild(card);
    });
  }

  // =========================================================
  // STUDENT PORTAL: RESULT HISTORY & TRANSCRIPT ENGINE
  // =========================================================
  function initResultHistoryAndTabs() {
    const tabBtnQualifications = document.getElementById('tab-btn-qualifications');
    const tabBtnResults = document.getElementById('tab-btn-results');
    const navBtnResultHistory = document.getElementById('nav-btn-result-history');
    const qualificationsSection = document.getElementById('qualifications-view-section');
    const resultsSection = document.getElementById('results-history-section');
    const portalHeading = document.getElementById('portal-view-heading');
    const portalSub = document.getElementById('portal-view-sub');
    const navResultsBadge = document.getElementById('nav-results-badge');
    const resultsCountBadge = document.getElementById('results-count-badge');
    const btnTakeExam = document.getElementById('btn-portal-take-exam');

    const searchInput = document.getElementById('results-search-input');
    const filterSelect = document.getElementById('results-filter-select');
    const btnRefresh = document.getElementById('btn-refresh-results-list');
    const resultsContainer = document.getElementById('results-cards-container');

    const detailModal = document.getElementById('result-detail-modal');
    const detailModalBody = document.getElementById('detail-modal-body');
    const detailModalTitle = document.getElementById('detail-modal-title');
    const detailModalSubtitle = document.getElementById('detail-modal-subtitle');
    const btnCloseDetailModal = document.getElementById('btn-close-detail-modal');
    const btnModalCloseFooter = document.getElementById('btn-modal-close-footer');
    const btnModalDownloadPdf = document.getElementById('btn-modal-download-pdf');

    let currentResults = [];
    let activeDetailResult = null;

    // Tab Switching Function
    function switchTab(tabName) {
      if (tabName === 'results') {
        if (tabBtnResults) tabBtnResults.classList.add('active');
        if (tabBtnQualifications) tabBtnQualifications.classList.remove('active');
        if (qualificationsSection) qualificationsSection.style.display = 'none';
        if (resultsSection) resultsSection.style.display = 'flex';

        if (portalHeading) portalHeading.textContent = 'Candidate Examination Result History';
        if (portalSub) portalSub.textContent = 'Official examination transcripts, Objective Response (OR) test scores, and Constructive Response (CR) case study submissions.';

        loadResultsData();
      } else {
        if (tabBtnQualifications) tabBtnQualifications.classList.add('active');
        if (tabBtnResults) tabBtnResults.classList.remove('active');
        if (qualificationsSection) qualificationsSection.style.display = 'block';
        if (resultsSection) resultsSection.style.display = 'none';

        if (portalHeading) portalHeading.textContent = 'Qualification Levels & Study Modules';
        if (portalSub) portalSub.textContent = 'Select your enrolled CIPS level below to access syllabus study guides, class recordings, and practice exam engines.';
      }
    }

    if (tabBtnQualifications) {
      tabBtnQualifications.addEventListener('click', () => switchTab('qualifications'));
    }

    if (tabBtnResults) {
      tabBtnResults.addEventListener('click', () => switchTab('results'));
    }

    if (navBtnResultHistory) {
      navBtnResultHistory.addEventListener('click', () => switchTab('results'));
    }

    if (btnTakeExam) {
      btnTakeExam.addEventListener('click', () => switchTab('qualifications'));
    }

    // Modal close bindings
    if (btnCloseDetailModal) {
      btnCloseDetailModal.addEventListener('click', () => {
        if (detailModal) detailModal.classList.remove('active');
      });
    }

    if (btnModalCloseFooter) {
      btnModalCloseFooter.addEventListener('click', () => {
        if (detailModal) detailModal.classList.remove('active');
      });
    }

    if (btnModalDownloadPdf) {
      btnModalDownloadPdf.addEventListener('click', () => {
        if (activeDetailResult) {
          downloadExamPaperResultPdf(activeDetailResult);
        }
      });
    }

    // Filter and search bindings
    if (searchInput) {
      searchInput.addEventListener('input', () => renderFilteredResults());
    }

    if (filterSelect) {
      filterSelect.addEventListener('change', () => renderFilteredResults());
    }

    if (btnRefresh) {
      btnRefresh.addEventListener('click', () => {
        btnRefresh.innerHTML = '<span>🔄</span> Loading...';
        loadResultsData().finally(() => {
          btnRefresh.innerHTML = '<span>🔄</span> Refresh';
        });
      });
    }

    // Fetch and calculate stats
    async function loadResultsData() {
      try {
        const list = await apiConfig.getStudentQuizResults(activeStudent.email);
        currentResults = Array.isArray(list) ? list : [];

        // Normalize student metadata for PDF generator
        currentResults = currentResults.map(r => ({
          ...r,
          studentName: r.studentName || activeStudent.name || activeStudent.studentId,
          studentId: r.studentId || activeStudent.studentId || 'STU1001',
          studentEmail: r.studentEmail || activeStudent.email
        }));

        // Update count badges
        const count = currentResults.length;
        if (navResultsBadge) navResultsBadge.textContent = count;
        if (resultsCountBadge) resultsCountBadge.textContent = count;

        // Calculate KPI Metrics
        updateKpis(currentResults);

        // Render card feed
        renderFilteredResults();
      } catch (err) {
        console.error('Failed to load quiz results:', err);
        if (resultsContainer) {
          resultsContainer.innerHTML = `
            <div class="results-empty-state">
              <div class="results-empty-icon">⚠️</div>
              <h3 class="results-empty-title">Error Loading Results</h3>
              <p class="results-empty-desc">Could not connect to the result server. Please click refresh to try again.</p>
            </div>
          `;
        }
      }
    }

    function updateKpis(results) {
      const kpiTotal = document.getElementById('kpi-total-attempts');
      const kpiPassed = document.getElementById('kpi-passed-count');
      const kpiPassRate = document.getElementById('kpi-pass-rate');
      const kpiHighest = document.getElementById('kpi-highest-score');
      const kpiAvgDuration = document.getElementById('kpi-avg-duration');

      if (!results || results.length === 0) {
        if (kpiTotal) kpiTotal.textContent = '0';
        if (kpiPassed) kpiPassed.textContent = '0';
        if (kpiPassRate) kpiPassRate.textContent = 'Passed (0%)';
        if (kpiHighest) kpiHighest.textContent = '--';
        if (kpiAvgDuration) kpiAvgDuration.textContent = '--';
        return;
      }

      const total = results.length;
      const passedCount = results.filter(r => r.passed === true || (typeof r.score === 'number' && r.score >= 42)).length;
      const passRate = Math.round((passedCount / total) * 100);

      // Highest score
      let highestPct = 0;
      let highestScoreStr = '--';
      let totalSeconds = 0;
      let durationCount = 0;

      results.forEach(r => {
        if (typeof r.score === 'number' && typeof r.totalQuestions === 'number' && r.totalQuestions > 0) {
          const pct = Math.round((r.score / r.totalQuestions) * 100);
          if (pct >= highestPct) {
            highestPct = pct;
            highestScoreStr = `${r.score}/${r.totalQuestions} (${pct}%)`;
          }
        }
        if (typeof r.durationSeconds === 'number' && r.durationSeconds > 0) {
          totalSeconds += r.durationSeconds;
          durationCount++;
        }
      });

      const avgSecs = durationCount > 0 ? Math.round(totalSeconds / durationCount) : 0;
      const avgMin = Math.floor(avgSecs / 60);
      const avgRemSec = avgSecs % 60;
      const avgDurationStr = durationCount > 0 ? `${avgMin}m ${avgRemSec}s` : '--';

      if (kpiTotal) kpiTotal.textContent = total;
      if (kpiPassed) kpiPassed.textContent = passedCount;
      if (kpiPassRate) kpiPassRate.textContent = `Passed (${passRate}%)`;
      if (kpiHighest) kpiHighest.textContent = highestScoreStr;
      if (kpiAvgDuration) kpiAvgDuration.textContent = avgDurationStr;
    }

    function renderFilteredResults() {
      if (!resultsContainer) return;

      const query = (searchInput ? searchInput.value : '').trim().toLowerCase();
      const filter = filterSelect ? filterSelect.value : 'ALL';

      const filtered = currentResults.filter(r => {
        // Query match
        const modCode = (r.moduleCode || '').toLowerCase();
        const modTitle = (r.moduleTitle || '').toLowerCase();
        const receipt = (r.id || '').toLowerCase();
        const matchesQuery = !query || modCode.includes(query) || modTitle.includes(query) || receipt.includes(query);

        if (!matchesQuery) return false;

        // Status match
        const isCr = (r.examType || '').toLowerCase().includes('cr') || (r.examType || '').toLowerCase().includes('case');
        const isPass = r.passed === true || (typeof r.score === 'number' && r.score >= 42);

        if (filter === 'PASS') return !isCr && isPass;
        if (filter === 'FAIL') return !isCr && !isPass;
        if (filter === 'CR') return isCr;
        return true;
      });

      if (filtered.length === 0) {
        resultsContainer.innerHTML = `
          <div class="results-empty-state">
            <div class="results-empty-icon">📂</div>
            <h3 class="results-empty-title">${currentResults.length === 0 ? 'No Examination Attempts Recorded' : 'No Matching Results Found'}</h3>
            <p class="results-empty-desc">
              ${currentResults.length === 0 
                ? 'You have not attempted any CIPS mock quizzes yet. Select any enrolled study module and test your knowledge to generate official transcripts.'
                : 'Try adjusting your search criteria or clearing your filters to see past exam attempts.'}
            </p>
            ${currentResults.length === 0 ? `
              <button id="btn-empty-start-quiz" class="btn btn-primary" style="padding: 0.65rem 1.25rem; font-weight: 700;">
                <span>📚</span> Browse Study Modules
              </button>
            ` : ''}
          </div>
        `;

        const emptyBtn = document.getElementById('btn-empty-start-quiz');
        if (emptyBtn) {
          emptyBtn.addEventListener('click', () => switchTab('qualifications'));
        }
        return;
      }

      // Render cards
      resultsContainer.innerHTML = '';

      filtered.forEach((res, index) => {
        const isCr = (res.examType || '').toLowerCase().includes('cr') || (res.examType || '').toLowerCase().includes('case');
        const isPass = res.passed === true || (typeof res.score === 'number' && res.score >= 42);

        let dateStr = 'Recent';
        try {
          if (res.submittedAt) {
            const d = new Date(res.submittedAt);
            dateStr = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
          }
        } catch (e) {}

        const durationMin = res.durationSeconds ? Math.floor(res.durationSeconds / 60) : 0;
        const durationSec = res.durationSeconds ? res.durationSeconds % 60 : 0;
        const durationStr = res.durationSeconds ? `${durationMin}m ${durationSec}s` : 'Standard Duration';

        let scoreDisplay = '';
        let statusBadge = '';

        if (isCr) {
          scoreDisplay = `<span class="result-score-num cr">Case Study</span>`;
          statusBadge = `<span class="result-status-pill cr">📝 Evaluated Submission</span>`;
        } else {
          const totalQ = res.totalQuestions || 60;
          const scoreVal = typeof res.score === 'number' ? res.score : 0;
          const pct = Math.round((scoreVal / totalQ) * 100);

          scoreDisplay = `<span class="result-score-num ${isPass ? 'pass' : 'fail'}">${scoreVal}/${totalQ} (${pct}%)</span>`;
          statusBadge = isPass 
            ? `<span class="result-status-pill pass">✓ Pass Accredited</span>`
            : `<span class="result-status-pill fail">✕ Requires Revision</span>`;
        }

        const card = document.createElement('div');
        card.className = 'result-card-item';
        card.innerHTML = `
          <div class="result-item-main">
            <div class="result-module-badge">${res.moduleCode || 'CIPS'}</div>
            <div class="result-meta-info">
              <div class="result-module-title">${res.moduleTitle || (res.moduleCode + ' Exam Assessment')}</div>
              <div class="result-meta-sub">
                <span>🗓️ ${dateStr}</span>
                <span>⏱️ ${durationStr}</span>
                <span>📋 Format: ${isCr ? 'Case Study (CR)' : 'Objective Response (OR - 60 MCQs)'}</span>
                <span>🏷️ Ref: <code style="background: rgba(255,255,255,0.1); padding: 1px 4px; border-radius: 4px; font-size: 0.78rem;">${res.id || ('RES_' + index)}</code></span>
              </div>
            </div>
          </div>

          <div class="result-item-scores">
            <div class="result-score-block">
              ${scoreDisplay}
              <div>${statusBadge}</div>
            </div>

            <div class="result-actions-group">
              <button class="btn-download-result-action" data-index="${index}" title="Download Official Exam Paper Result PDF">
                <span>📄</span> Download Result
              </button>
              <button class="btn-view-breakdown-action" data-index="${index}" title="View Itemized Question Breakdown">
                <span>👁️</span> Breakdown
              </button>
            </div>
          </div>
        `;

        // Bind buttons
        const downloadBtn = card.querySelector('.btn-download-result-action');
        downloadBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          downloadExamPaperResultPdf(res);
        });

        const breakdownBtn = card.querySelector('.btn-view-breakdown-action');
        breakdownBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          openBreakdownModal(res);
        });

        resultsContainer.appendChild(card);
      });
    }

    function openBreakdownModal(res) {
      activeDetailResult = res;
      if (!detailModal || !detailModalBody) return;

      const isCr = (res.examType || '').toLowerCase().includes('cr') || (res.examType || '').toLowerCase().includes('case');
      const isPass = res.passed === true || (typeof res.score === 'number' && res.score >= 42);

      if (detailModalTitle) {
        detailModalTitle.textContent = `${res.moduleCode} - ${res.moduleTitle || 'Examination Result'}`;
      }
      if (detailModalSubtitle) {
        detailModalSubtitle.textContent = `Candidate: ${res.studentName || activeStudent.name || activeStudent.email} | Ref: ${res.id || 'N/A'}`;
      }

      let dateStr = 'N/A';
      try {
        if (res.submittedAt) {
          dateStr = new Date(res.submittedAt).toLocaleString('en-GB');
        }
      } catch (e) {}

      const durationMin = res.durationSeconds ? Math.floor(res.durationSeconds / 60) : 0;
      const durationSec = res.durationSeconds ? res.durationSeconds % 60 : 0;

      let scoreHeaderHtml = '';
      if (isCr) {
        scoreHeaderHtml = `
          <div style="background: rgba(30, 58, 138, 0.25); border: 1px solid rgba(56, 189, 248, 0.4); border-radius: 10px; padding: 1.25rem; margin-bottom: 1.25rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
              <div>
                <span style="background: #0284c7; color: white; padding: 3px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 700;">CONSTRUCTIVE RESPONSE</span>
                <h4 style="font-size: 1.2rem; font-weight: 800; color: #ffffff; margin: 0.35rem 0 0.25rem 0;">Written Essay Submission Logged</h4>
                <p style="font-size: 0.85rem; color: #cbd5e1; margin: 0;">Completed and timestamped into the examination repository.</p>
              </div>
              <button id="btn-breakdown-top-download" class="btn-download-result-action">
                <span>📄</span> Download Exam Paper Result
              </button>
            </div>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 1rem; font-size: 0.85rem; color: #cbd5e1; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 0.75rem;">
              <div><strong>Receipt Ref:</strong> <code>${res.id || 'N/A'}</code></div>
              <div><strong>Date & Time:</strong> ${dateStr}</div>
              <div><strong>Duration:</strong> ${durationMin}m ${durationSec}s</div>
            </div>
          </div>
        `;
      } else {
        const totalQ = res.totalQuestions || 60;
        const scoreVal = typeof res.score === 'number' ? res.score : 0;
        const pct = Math.round((scoreVal / totalQ) * 100);

        scoreHeaderHtml = `
          <div style="background: ${isPass ? 'rgba(5, 150, 105, 0.15)' : 'rgba(220, 38, 38, 0.15)'}; border: 1px solid ${isPass ? 'rgba(16, 185, 129, 0.4)' : 'rgba(239, 68, 68, 0.4)'}; border-radius: 10px; padding: 1.25rem; margin-bottom: 1.25rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
              <div>
                <span style="background: ${isPass ? '#059669' : '#dc2626'}; color: white; padding: 3px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 800;">
                  ${isPass ? '✓ PASS ACCREDITED (70%+)' : '✕ REQUIRES REVISION (<70%)'}
                </span>
                <div style="font-size: 1.6rem; font-weight: 800; color: ${isPass ? '#34d399' : '#f87171'}; margin-top: 0.25rem;">
                  ${scoreVal} / ${totalQ} (${pct}%)
                </div>
                <div style="font-size: 0.85rem; color: #cbd5e1;">CIPS Qualifying Benchmark: 42/60 marks (70%)</div>
              </div>
              <button id="btn-breakdown-top-download" class="btn-download-result-action">
                <span>📄</span> Download Exam Paper Result
              </button>
            </div>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 1rem; font-size: 0.85rem; color: #cbd5e1; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 0.75rem;">
              <div><strong>Receipt Ref:</strong> <code>${res.id || 'N/A'}</code></div>
              <div><strong>Date & Time:</strong> ${dateStr}</div>
              <div><strong>Duration:</strong> ${durationMin}m ${durationSec}s</div>
            </div>
          </div>
        `;
      }

      // Render Itemized Questions
      let questionsHtml = '';
      if (res.questionsSnapshot && Array.isArray(res.questionsSnapshot) && res.questionsSnapshot.length > 0) {
        questionsHtml = `
          <h4 style="font-size: 1rem; font-weight: 800; color: #ffffff; margin-bottom: 0.75rem;">
            📝 Itemized Question Analysis &amp; Recorded Responses (${res.questionsSnapshot.length} Questions)
          </h4>
          <div style="display: flex; flex-direction: column; gap: 0.75rem;">
        `;

        res.questionsSnapshot.forEach((q, idx) => {
          if (isCr) {
            questionsHtml += `
              <div style="background: rgba(30, 41, 59, 0.6); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 1rem;">
                <div style="display: flex; justify-content: space-between; font-weight: 700; color: #38bdf8; margin-bottom: 0.35rem;">
                  <span>Question ${q.questionNumber || (idx + 1)}: ${q.title || 'Case Essay'}</span>
                  <span>${q.marks || 25} Marks</span>
                </div>
                <p style="font-size: 0.88rem; color: #cbd5e1; margin-bottom: 0.5rem;">${q.prompt || ''}</p>
                <div style="background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 6px; padding: 0.75rem; font-size: 0.85rem; color: #f8fafc; white-space: pre-wrap;">
                  ${q.studentAnswer || res.answers?.[idx] || 'No answer recorded.'}
                </div>
                <div style="font-size: 0.78rem; color: #94a3b8; margin-top: 0.35rem; text-align: right;">
                  Word count: ${q.wordCount || (q.studentAnswer ? q.studentAnswer.trim().split(/\s+/).length : 0)}
                </div>
              </div>
            `;
          } else {
            const studentChoice = typeof q.studentAnswer !== 'undefined' ? q.studentAnswer : res.answers?.[idx];
            const isCorrect = typeof q.isCorrect === 'boolean' 
              ? q.isCorrect 
              : (studentChoice !== undefined && studentChoice === q.correctAnswer);

            const optionsList = Array.isArray(q.options) ? q.options : [];

            questionsHtml += `
              <div style="background: rgba(30, 41, 59, 0.6); border: 1px solid ${isCorrect ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}; border-radius: 8px; padding: 0.85rem;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; margin-bottom: 0.4rem;">
                  <span style="font-weight: 700; font-size: 0.9rem; color: #ffffff;">
                    Q${q.questionNumber || (idx + 1)}. ${q.questionText || q.prompt || ''}
                  </span>
                  <span style="font-size: 0.75rem; font-weight: 800; padding: 2px 6px; border-radius: 4px; background: ${isCorrect ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)'}; color: ${isCorrect ? '#34d399' : '#f87171'};">
                    ${isCorrect ? 'CORRECT' : 'INCORRECT'}
                  </span>
                </div>
                <div style="font-size: 0.82rem; color: #cbd5e1; display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 0.35rem;">
                  <div>
                    <span style="color: #94a3b8;">Your Answer:</span> 
                    <strong>${studentChoice !== undefined ? (optionsList[studentChoice] || `Option ${studentChoice}`) : 'Skipped'}</strong>
                  </div>
                  <div>
                    <span style="color: #94a3b8;">Correct Answer:</span> 
                    <strong style="color: #34d399;">${q.correctAnswer !== undefined ? (optionsList[q.correctAnswer] || `Option ${q.correctAnswer}`) : 'Ref Key'}</strong>
                  </div>
                </div>
                ${q.explanation ? `
                  <div style="margin-top: 0.5rem; padding: 0.5rem; background: rgba(15, 23, 42, 0.5); border-left: 3px solid #38bdf8; font-size: 0.8rem; color: #94a3b8;">
                    <strong>Syllabus Learning Note:</strong> ${q.explanation}
                  </div>
                ` : ''}
              </div>
            `;
          }
        });

        questionsHtml += `</div>`;
      } else {
        questionsHtml = `
          <div style="padding: 1.5rem; background: rgba(30, 41, 59, 0.4); border-radius: 8px; text-align: center; color: #94a3b8; font-size: 0.88rem;">
            Attempt score, timestamp, and audit metadata are fully recorded. Download the official PDF transcript for an itemized breakdown.
          </div>
        `;
      }

      detailModalBody.innerHTML = `
        ${scoreHeaderHtml}
        ${questionsHtml}
      `;

      const topDownloadBtn = document.getElementById('btn-breakdown-top-download');
      if (topDownloadBtn) {
        topDownloadBtn.addEventListener('click', () => {
          downloadExamPaperResultPdf(res);
        });
      }

      detailModal.classList.add('active');
    }

    // Check URL parameters for tab routing (e.g. ?tab=results or ?view=history)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('tab') === 'results' || urlParams.get('view') === 'history' || window.location.hash === '#results') {
      switchTab('results');
    } else {
      // Preload count for nav badge
      loadResultsData();
    }
  }
});

