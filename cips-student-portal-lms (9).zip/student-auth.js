/**
 * Student Authentication & New Student Registration Logic
 * Features Precision Animated Diagonal Transitions, Single-Device Lock & Demo Auto-fills
 */

import { apiConfig } from './api-config.js';

document.addEventListener('DOMContentLoaded', () => {
  const authWrapper = document.getElementById('auth-panel-wrapper');
  const linkToNewStudent = document.getElementById('link-to-new-student');
  const linkToStudentLogin = document.getElementById('link-to-student-login');

  const studentLoginForm = document.getElementById('student-login-form');
  const loginAlertBox = document.getElementById('login-alert');
  const loginAlertText = document.getElementById('login-alert-text');
  const loginSubmitBtn = document.getElementById('btn-submit-login');

  const quickNewStudentForm = document.getElementById('quick-new-student-form');
  const newStudentAlertBox = document.getElementById('new-student-alert');
  const newStudentAlertText = document.getElementById('new-student-alert-text');
  const newStudentSubmitBtn = document.getElementById('btn-submit-quick-inquiry');

  const deviceInfoLabel = document.getElementById('device-info-label');

  // Lock authWrapper scroll coordinates to eliminate browser offset jumps
  if (authWrapper) {
    authWrapper.scrollLeft = 0;
    authWrapper.scrollTop = 0;
    authWrapper.addEventListener('scroll', () => {
      if (authWrapper.scrollLeft !== 0) authWrapper.scrollLeft = 0;
      if (authWrapper.scrollTop !== 0) authWrapper.scrollTop = 0;
    }, { passive: true });
  }

  // Display device fingerprint details
  const fp = apiConfig.getDeviceFingerprint();
  if (deviceInfoLabel) {
    deviceInfoLabel.textContent = `🔒 Active Device: ${fp.browser} on ${fp.os} (ID: ${fp.deviceToken.substring(0, 8)}...) • CIPS LMS v4.2`;
  }

  // Smooth Precise Switch to New Student Form
  if (linkToNewStudent && authWrapper) {
    linkToNewStudent.addEventListener('click', (e) => {
      e.preventDefault();
      authWrapper.scrollLeft = 0;
      authWrapper.scrollTop = 0;
      authWrapper.classList.add('active');
      hideLoginAlert();
      hideNewStudentAlert();
      try {
        history.replaceState(null, '', 'student-login.html?mode=new');
      } catch (_) {}
    });
  }

  // Smooth Precise Switch back to Student Login
  if (linkToStudentLogin && authWrapper) {
    linkToStudentLogin.addEventListener('click', (e) => {
      e.preventDefault();
      authWrapper.scrollLeft = 0;
      authWrapper.scrollTop = 0;
      authWrapper.classList.remove('active');
      hideLoginAlert();
      hideNewStudentAlert();
      try {
        history.replaceState(null, '', 'student-login.html');
      } catch (_) {}
    });
  }

  // Input Box Floating Label Synchronization
  document.querySelectorAll('.auth-panel-wrapper .input-box input').forEach(input => {
    const updateHasValue = () => {
      if (input.value && input.value.length > 0) {
        input.parentElement.classList.add('has-value');
      } else {
        input.parentElement.classList.remove('has-value');
      }
    };
    input.addEventListener('input', updateHasValue);
    input.addEventListener('change', updateHasValue);
    updateHasValue();
  });

  // Student Password Visibility Toggle
  const btnToggleLoginPass = document.getElementById('btn-toggle-login-pass');
  const studentPasswordInput = document.getElementById('studentPassword');
  if (btnToggleLoginPass && studentPasswordInput) {
    btnToggleLoginPass.addEventListener('click', () => {
      const isPass = studentPasswordInput.type === 'password';
      studentPasswordInput.type = isPass ? 'text' : 'password';
      btnToggleLoginPass.style.opacity = isPass ? '1' : '0.65';
    });
  }

  // Handle URL mode for direct New Student navigation (?mode=new or #new)
  const urlParams = new URLSearchParams(window.location.search);
  const isNewMode = urlParams.get('mode') === 'new' || window.location.hash === '#new';
  if (isNewMode && authWrapper) {
    authWrapper.scrollLeft = 0;
    authWrapper.scrollTop = 0;
    authWrapper.classList.add('active');
  }

  // Check if student is already logged in
  const activeStudent = apiConfig.getStoredStudent();
  if (!isNewMode && activeStudent && activeStudent.email) {
    window.location.href = 'dashboard.html';
    return;
  }

  // Global Demo Sign-In Auto-Fill Handler for Students
  window.fillDemo = (id, email, pass) => {
    if (authWrapper) {
      authWrapper.scrollLeft = 0;
      authWrapper.scrollTop = 0;
      if (authWrapper.classList.contains('active')) {
        authWrapper.classList.remove('active');
      }
    }

    try {
      history.replaceState(null, '', 'student-login.html');
    } catch (_) {}

    const idInput = document.getElementById('studentId');
    const emailInput = document.getElementById('studentEmail');
    const passInput = document.getElementById('studentPassword');

    if (idInput) {
      idInput.value = id;
      idInput.dispatchEvent(new Event('input', { bubbles: true }));
      idInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (emailInput) {
      emailInput.value = email;
      emailInput.dispatchEvent(new Event('input', { bubbles: true }));
      emailInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (passInput) {
      passInput.value = pass;
      passInput.dispatchEvent(new Event('input', { bubbles: true }));
      passInput.dispatchEvent(new Event('change', { bubbles: true }));
    }

    hideLoginAlert();
    hideNewStudentAlert();

    setTimeout(() => {
      if (authWrapper) {
        authWrapper.scrollLeft = 0;
        authWrapper.scrollTop = 0;
      }
      if (loginSubmitBtn && typeof loginSubmitBtn.focus === 'function') {
        loginSubmitBtn.focus({ preventScroll: true });
      }
    }, 400);
  };

  // Student Login Form Submission
  if (studentLoginForm) {
    studentLoginForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const studentId = document.getElementById('studentId').value.trim();
      const email = document.getElementById('studentEmail').value.trim();
      const password = studentPasswordInput ? studentPasswordInput.value.trim() : '';

      if (!studentId || !email || !password) {
        showLoginAlert('Please enter your Student UserID, Registered Email, and Password.');
        return;
      }

      hideLoginAlert();
      loginSubmitBtn.disabled = true;
      loginSubmitBtn.textContent = 'Verifying Credentials & Device...';

      try {
        const response = await apiConfig.login(studentId, email, password);

        if (response.success) {
          loginSubmitBtn.textContent = 'Redirecting to Dashboard...';
          setTimeout(() => {
            window.location.href = 'dashboard.html';
          }, 350);
        }
      } catch (err) {
        console.error('Student login error:', err);
        showLoginAlert(err.message || 'Authentication error occurred.');
        loginSubmitBtn.disabled = false;
        loginSubmitBtn.textContent = 'Login';
      }
    });
  }

  // Quick New Student Information Form Submission
  if (quickNewStudentForm) {
    quickNewStudentForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const name = (document.getElementById('newStudentName')?.value || '').trim();
      const email = (document.getElementById('newStudentEmail')?.value || '').trim();
      const countryCode = (document.getElementById('newStudentCountryCode')?.value || '+44').trim();
      const rawPhone = (document.getElementById('newStudentPhone')?.value || '').trim();

      if (!name || !email || !rawPhone) {
        showNewStudentAlert('Please provide your name, email, and phone number.');
        return;
      }

      const fullPhone = `${countryCode} ${rawPhone}`;

      hideNewStudentAlert();
      newStudentSubmitBtn.disabled = true;
      newStudentSubmitBtn.textContent = 'Submitting & Syncing...';

      try {
        const res = await fetch('/api/new-student', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name,
            email,
            phone: fullPhone,
            countryCode,
            cipsLevel: 'General Inquiry / Enrollment',
            notes: 'Submitted via Student Portal quick inquiry box',
            source: 'student-login-box'
          })
        });

        const data = await res.json();

        if (data.success) {
          showNewStudentAlert(`✓ Thank you, ${name}! Your information was received. Admissions will contact you shortly.`, 'success');
          quickNewStudentForm.reset();
          newStudentSubmitBtn.disabled = false;
          newStudentSubmitBtn.textContent = 'Submitted Successfully!';
          setTimeout(() => {
            newStudentSubmitBtn.textContent = 'Submit Information';
          }, 4000);
        } else {
          showNewStudentAlert(data.message || 'Error submitting registration.');
          newStudentSubmitBtn.disabled = false;
          newStudentSubmitBtn.textContent = 'Submit Information';
        }
      } catch (err) {
        console.error('New student submission error:', err);
        showNewStudentAlert('Connection error while saving info.');
        newStudentSubmitBtn.disabled = false;
        newStudentSubmitBtn.textContent = 'Submit Information';
      }
    });
  }

  function showLoginAlert(msg, type = 'error') {
    if (loginAlertBox && loginAlertText) {
      loginAlertText.textContent = msg;
      loginAlertBox.style.display = 'flex';
      if (type === 'success') {
        loginAlertBox.style.borderColor = 'rgba(16, 185, 129, 0.4)';
        loginAlertBox.style.background = 'rgba(16, 185, 129, 0.12)';
        loginAlertBox.style.color = '#059669';
      } else {
        loginAlertBox.style.borderColor = '';
        loginAlertBox.style.background = '';
        loginAlertBox.style.color = '';
      }
    }
  }

  function hideLoginAlert() {
    if (loginAlertBox) {
      loginAlertBox.style.display = 'none';
    }
  }

  function showNewStudentAlert(msg, type = 'error') {
    if (newStudentAlertBox && newStudentAlertText) {
      newStudentAlertText.textContent = msg;
      newStudentAlertBox.style.display = 'flex';
      if (type === 'success') {
        newStudentAlertBox.style.borderColor = 'rgba(16, 185, 129, 0.4)';
        newStudentAlertBox.style.background = 'rgba(16, 185, 129, 0.12)';
        newStudentAlertBox.style.color = '#059669';
        const icon = newStudentAlertBox.querySelector('.alert-icon');
        if (icon) icon.textContent = '✅';
      } else {
        newStudentAlertBox.style.borderColor = '';
        newStudentAlertBox.style.background = '';
        newStudentAlertBox.style.color = '';
        const icon = newStudentAlertBox.querySelector('.alert-icon');
        if (icon) icon.textContent = '⚠️';
      }
    }
  }

  function hideNewStudentAlert() {
    if (newStudentAlertBox) {
      newStudentAlertBox.style.display = 'none';
    }
  }
});
