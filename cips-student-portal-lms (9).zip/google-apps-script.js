/**
 * =========================================================================
 * CIPS EXAM PORTAL LMS - GOOGLE SHEET CLOUD DATABASE BACKEND
 * =========================================================================
 * Complete Google Apps Script that transforms any Google Spreadsheet into
 * an automated relational database for the CIPS Student Portal LMS.
 * 
 * INSTRUCTIONS:
 * 1. Open Google Sheets at https://sheets.new
 * 2. In the menu: Extensions > Apps Script
 * 3. Delete any default code in Code.gs, paste this ENTIRE file, and Save (Ctrl+S / Cmd+S).
 * 4. Run "setupDatabase" once from the toolbar to auto-create and format all sheet tabs,
 *    and instantly seed all existing student & access control records!
 * 5. Click "Deploy" > "New deployment" > Select type: "Web app"
 *    - Execute as: "Me"
 *    - Who has access: "Anyone"
 * 6. Copy the Web App URL and paste it into CIPS Admin Console > Google Integrations.
 * =========================================================================
 */

// -------------------------------------------------------------
// TABLE DEFINITIONS & COLUMN SCHEMAS
// -------------------------------------------------------------

var SCHEMA = {
  STUDENT_RECORDS: {
    name: 'Student Records',
    headers: [
      'Student ID',
      'Full Name',
      'Email Address',
      'Password / Access PIN',
      'Approved Levels',
      'Approved Modules',
      'Account Status',
      'Quiz Access Status',
      'Device Status',
      'Last Login Timestamp',
      'Login Count',
      'Registration Date'
    ]
  },
  ACCESS_CONTROL: {
    name: 'Access Control',
    headers: [
      'Student ID',
      'Student Email',
      'Candidate Name',
      'Portal Access Status',
      'Quiz Access Status',
      'Allowed Modules',
      'Max Attempts Allowed',
      'Attempts Used',
      'Device Lock Active',
      'Device Info',
      'Security Flags',
      'Last Updated'
    ]
  },
  NEW_STUDENT_REGISTRATION: {
    name: 'New Student Registration',
    headers: [
      'Name',
      'Email',
      'Phone Number',
      'Registration Timestamp',
      'Country Code',
      'Target CIPS Level',
      'Notes',
      'Follow-up Status'
    ]
  },
  EXAM_RESULTS: {
    name: 'Exam Results',
    headers: [
      'Receipt ID',
      'Submission Date',
      'Student ID',
      'Candidate Name',
      'Candidate Email',
      'Module Code',
      'Module Title',
      'Exam Type',
      'Score',
      'Total Questions',
      'Score %',
      'Result Status',
      'Duration (Seconds)',
      'Auto-Submitted'
    ]
  },
  LOGIN_SECURITY_AUDIT: {
    name: 'Login & Security Audit',
    headers: [
      'Timestamp',
      'Student Email',
      'Student ID',
      'Event Type',
      'Browser / OS',
      'Device Token',
      'Status',
      'Incident Details'
    ]
  }
};

// -------------------------------------------------------------
// MENU TRIGGER & AUTO-SETUP
// -------------------------------------------------------------

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('🎓 CIPS Exam Portal')
    .addItem('⚡ Setup All Database Sheets & Headers', 'setupDatabase')
    .addItem('🚀 Seed Existing Student & Access Data', 'seedExistingLMSData')
    .addSeparator()
    .addItem('📋 Verify Database Schema', 'verifyDatabaseSchema')
    .addToUi();
}

/**
 * Main Setup function. Creates every tab with styled headers
 * and seeds initial records so the database is ready immediately.
 */
function setupDatabase() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // 1. Create or verify each sheet tab with precise headers and formatting
  getOrCreateStyledSheet(ss, SCHEMA.STUDENT_RECORDS.name, SCHEMA.STUDENT_RECORDS.headers);
  getOrCreateStyledSheet(ss, SCHEMA.ACCESS_CONTROL.name, SCHEMA.ACCESS_CONTROL.headers);
  getOrCreateStyledSheet(ss, SCHEMA.NEW_STUDENT_REGISTRATION.name, SCHEMA.NEW_STUDENT_REGISTRATION.headers);
  getOrCreateStyledSheet(ss, SCHEMA.EXAM_RESULTS.name, SCHEMA.EXAM_RESULTS.headers);
  getOrCreateStyledSheet(ss, SCHEMA.LOGIN_SECURITY_AUDIT.name, SCHEMA.LOGIN_SECURITY_AUDIT.headers);

  // 2. Remove default blank "Sheet1" if present and other sheets exist
  var defaultSheet = ss.getSheetByName('Sheet1');
  if (defaultSheet && defaultSheet.getLastRow() === 0 && ss.getSheets().length > 1) {
    try {
      ss.deleteSheet(defaultSheet);
    } catch (e) {
      // Ignored if it's the only sheet
    }
  }

  // 3. Seed existing student records, access controls, registration leads, and exam results
  seedExistingLMSData();

  Logger.log('CIPS Exam Portal Database structure successfully initialized!');
}

/**
 * Inserts or verifies existing CIPS student records & access controls
 */
function seedExistingLMSData() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // Existing Students Data from CIPS Exam Portal
  var existingStudents = [
    {
      studentId: 'STU1001',
      name: 'Alex Mercer',
      email: 'student@cips.edu',
      password: 'CIPS2026',
      approvedLevels: [2, 3, 4],
      approvedModules: ['L2M1', 'L2M2', 'L2M3', 'L2M4', 'L2M5', 'L3M1', 'L3M2', 'L3M3', 'L3M4', 'L3M5', 'L4M1', 'L4M2', 'L4M3', 'L4M4', 'L4M5'],
      accessStatus: 'ENABLED',
      quizAccessStatus: 'ENABLED',
      activeDeviceInfo: 'Chrome on Windows',
      activeDeviceToken: 'DEV_TOK_ikv2cwsa9_mrv4g53k',
      registeredAt: '2026-08-15T09:30:00.000Z',
      lastLogin: '2026-09-13T08:05:45.429Z',
      loginCount: 5,
      maxAttempts: 3,
      attemptsUsed: 2
    },
    {
      studentId: 'STU1002',
      name: 'John Doe',
      email: 'john.doe@cips.edu',
      password: 'QUIZ123',
      approvedLevels: [4, 5],
      approvedModules: ['L4M1', 'L4M2', 'L4M3', 'L4M4', 'L4M5', 'L4M6', 'L4M7', 'L4M8', 'L5M1', 'L5M2', 'L5M3'],
      accessStatus: 'ENABLED',
      quizAccessStatus: 'ENABLED',
      activeDeviceInfo: null,
      activeDeviceToken: null,
      registeredAt: '2026-08-22T14:15:00.000Z',
      lastLogin: '2026-09-06T16:45:10.000Z',
      loginCount: 2,
      maxAttempts: 3,
      attemptsUsed: 0
    },
    {
      studentId: 'STU1003',
      name: 'Mary Smith',
      email: 'mary.smith@cips.edu',
      password: 'PASS2026',
      approvedLevels: [2],
      approvedModules: ['L2M1', 'L2M2'],
      accessStatus: 'ENABLED',
      quizAccessStatus: 'ENABLED',
      activeDeviceInfo: null,
      activeDeviceToken: null,
      registeredAt: '2026-08-28T11:00:00.000Z',
      lastLogin: '2026-09-07T08:12:30.000Z',
      loginCount: 5,
      maxAttempts: 3,
      attemptsUsed: 2
    },
    {
      studentId: 'STU1004',
      name: 'Victoria Sterling',
      email: 'executive@cips.edu',
      password: 'EXEC999',
      approvedLevels: [5, 6],
      approvedModules: ['L5M1', 'L5M2', 'L5M3', 'L5M4', 'L5M5', 'L5M6', 'L5M7', 'L5M8', 'L6M1', 'L6M2', 'L6M3', 'L6M4'],
      accessStatus: 'ENABLED',
      quizAccessStatus: 'ENABLED',
      activeDeviceInfo: null,
      activeDeviceToken: null,
      registeredAt: '2026-09-02T13:40:00.000Z',
      lastLogin: '2026-09-05T19:22:00.000Z',
      loginCount: 1,
      maxAttempts: 3,
      attemptsUsed: 0
    }
  ];

  // Seed Students and Access Control
  existingStudents.forEach(function(student) {
    handleStudentUpsert(ss, student);
  });

  // Seed existing New Student Registration lead
  var existingRegistration = {
    name: 'Alexander Wright',
    email: 'alex.wright@example.com',
    phone: '+44 7911 123456',
    countryCode: '+44',
    level: 'Level 4 Diploma',
    notes: 'Interested in Procurement Strategy',
    submittedAt: '2026-09-13T08:11:47.550Z',
    status: 'PENDING_CONTACT'
  };
  handleNewStudentRegistration(ss, existingRegistration);

  // Seed existing Exam Results
  var existingResults = [
    {
      id: 'QR_101',
      submittedAt: '2026-09-06T15:30:22.000Z',
      studentId: 'STU1003',
      studentName: 'Mary Smith',
      studentEmail: 'mary.smith@cips.edu',
      moduleCode: 'L2M1',
      moduleTitle: 'Procurement and Supply Operations',
      examType: 'OR',
      score: 18,
      totalQuestions: 20,
      passed: true,
      durationSeconds: 1420,
      autoSubmitted: false
    },
    {
      id: 'QR_102',
      submittedAt: '2026-09-07T08:45:10.000Z',
      studentId: 'STU1003',
      studentName: 'Mary Smith',
      studentEmail: 'mary.smith@cips.edu',
      moduleCode: 'L2M2',
      moduleTitle: 'Procurement and Supply Functions',
      examType: 'OR',
      score: 16,
      totalQuestions: 20,
      passed: true,
      durationSeconds: 1180,
      autoSubmitted: false
    },
    {
      id: 'QR_103',
      submittedAt: '2026-09-07T10:30:00.000Z',
      studentId: 'STU1001',
      studentName: 'Alex Mercer',
      studentEmail: 'student@cips.edu',
      moduleCode: 'L4M1',
      moduleTitle: 'Scope and Influence of Procurement',
      examType: 'OR',
      score: 19,
      totalQuestions: 20,
      passed: true,
      durationSeconds: 1350,
      autoSubmitted: false
    }
  ];

  existingResults.forEach(function(res) {
    handleExamResult(ss, res);
  });
}

function verifyDatabaseSchema() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var tables = [
    SCHEMA.STUDENT_RECORDS.name,
    SCHEMA.ACCESS_CONTROL.name,
    SCHEMA.NEW_STUDENT_REGISTRATION.name,
    SCHEMA.EXAM_RESULTS.name,
    SCHEMA.LOGIN_SECURITY_AUDIT.name
  ];

  var existing = ss.getSheets().map(function(s) { return s.getName(); });
  var missing = tables.filter(function(t) { return existing.indexOf(t) === -1; });

  var message = missing.length === 0
    ? 'All 5 database tables are present and verified!\n\nSheets: ' + existing.join(', ')
    : 'Warning: Missing sheets: ' + missing.join(', ') + '. Running setupDatabase will create them.';
    
  SpreadsheetApp.getUi().alert('CIPS LMS Schema Verification', message, SpreadsheetApp.getUi().ButtonSet.OK);
}

// -------------------------------------------------------------
// WEB APP API ENDPOINTS (doPost & doGet)
// -------------------------------------------------------------

function doPost(e) {
  var lock = LockService.getScriptLock();
  // Acquire lock to guarantee atomic concurrency safe writes
  if (!lock.tryLock(30000)) {
    return createJsonResponse({
      status: 'error',
      message: 'Google Sheets Database is currently processing another write lock. Please retry.'
    });
  }

  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var payload = {};

    if (e.postData && e.postData.contents) {
      try {
        payload = JSON.parse(e.postData.contents);
      } catch (err) {
        payload = e.parameter || {};
      }
    } else {
      payload = e.parameter || {};
    }

    var action = (payload.action || payload.eventType || '').toUpperCase().trim();
    var data = payload.data || payload;

    // 1. Health Ping / Schema Check
    if (action === 'PING' || action === 'TEST') {
      setupDatabase();
      return createJsonResponse({
        status: 'success',
        message: 'CIPS Exam Portal Google Sheets Database is ONLINE and ready!',
        spreadsheetName: ss.getName(),
        sheets: ss.getSheets().map(function(s) { return s.getName(); })
      });
    }

    // 2. Full Bulk Sync / Migration
    if (action === 'BULK_SYNC' || action === 'BULK_MIGRATE') {
      handleBulkSync(ss, data);
      return createJsonResponse({
        status: 'success',
        action: action,
        message: 'Bulk migration of all student records and access data completed successfully!'
      });
    }

    // 3. Student Record CRUD: Add New Student
    if (action === 'STUDENT_CREATE' || action === 'STUDENT_REGISTER') {
      var createRes = handleStudentCreate(ss, data);
      return createJsonResponse(createRes);
    }

    // 4. Student Record CRUD: Edit / Update Existing Student Info
    if (action === 'STUDENT_UPDATE') {
      var updateRes = handleStudentUpdate(ss, data);
      return createJsonResponse(updateRes);
    }

    // 5. Universal Student Upsert (Auto-detects Insert vs Update)
    if (action === 'STUDENT_UPSERT') {
      var upsertRes = handleStudentUpsert(ss, data);
      return createJsonResponse(upsertRes);
    }

    // 6. Delete / Archive Student
    if (action === 'STUDENT_DELETE') {
      var deleteRes = handleStudentDelete(ss, data);
      return createJsonResponse(deleteRes);
    }

    // 7. Access Control State Updates
    if (action === 'ACCESS_UPDATE' || action === 'QUIZ_ACCESS_UPDATE') {
      var accessRes = handleAccessUpdate(ss, data);
      return createJsonResponse(accessRes);
    }

    // 8. New Student Registration (Signups from "NEW STUDENT" form)
    if (action === 'NEW_STUDENT_REGISTRATION' || action === 'INQUIRY' || action === 'STUDENT_INQUIRY') {
      var inqRes = handleNewStudentRegistration(ss, data);
      return createJsonResponse(inqRes);
    }

    // 9. Exam / Quiz Submission Results
    if (action === 'QUIZ_RESULT') {
      var examRes = handleExamResult(ss, data);
      return createJsonResponse(examRes);
    }

    // 10. Audit Logs & Security Alerts
    if (action === 'LOGIN' || action === 'SECURITY_ALERT') {
      var auditRes = handleAuditLog(ss, action, data);
      return createJsonResponse(auditRes);
    }

    // Generic Event fallback
    handleGenericLog(ss, action, data);
    return createJsonResponse({ status: 'success', action: action, message: 'Event logged successfully' });

  } catch (error) {
    Logger.log('Error in doPost: ' + error.toString());
    return createJsonResponse({ status: 'error', message: error.toString() });
  } finally {
    lock.releaseLock();
  }
}

function doGet(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return createJsonResponse({
    status: 'online',
    service: 'CIPS Exam Portal LMS Database Service',
    spreadsheetName: ss.getName(),
    sheets: ss.getSheets().map(function(s) { return s.getName(); }),
    timestamp: new Date().toISOString()
  });
}

// -------------------------------------------------------------
// STUDENT RECORDS & ACCESS CONTROL CRUD LOGIC
// -------------------------------------------------------------

/**
 * CREATE: Adds a new student record row and matching access control row
 */
function handleStudentCreate(ss, student) {
  var studentSheet = getOrCreateStyledSheet(ss, SCHEMA.STUDENT_RECORDS.name, SCHEMA.STUDENT_RECORDS.headers);
  var email = (student.email || '').toLowerCase().trim();
  var studentId = (student.studentId || '').toUpperCase().trim();

  // Check if student already exists by email
  var rowIndex = findRowIndexByEmail(studentSheet, email, 3);
  if (rowIndex > 0) {
    // If student exists, route to update instead of creating duplicate
    return handleStudentUpdate(ss, student);
  }

  var levelsStr = Array.isArray(student.approvedLevels) ? student.approvedLevels.join(', ') : (student.approvedLevels || '');
  var modulesStr = Array.isArray(student.approvedModules) ? student.approvedModules.join(', ') : (student.approvedModules || '');
  var deviceStatus = student.isDeviceBlocked ? 'BLOCKED' : (student.activeDeviceToken ? 'ACTIVE_LOCKED' : 'UNLOCKED');

  var newStudentRow = [
    studentId,
    student.name || studentId,
    email,
    student.password || 'CIPS2026',
    levelsStr,
    modulesStr,
    student.accessStatus || 'ENABLED',
    student.quizAccessStatus || 'ENABLED',
    deviceStatus,
    student.lastLogin || '',
    student.loginCount || 0,
    student.registeredAt || student.createdAt || new Date().toISOString()
  ];

  studentSheet.appendRow(newStudentRow);

  // Sync to Access Control Sheet
  syncAccessControlRow(ss, student);

  return {
    status: 'success',
    action: 'STUDENT_CREATE',
    studentId: studentId,
    email: email,
    message: 'New student added to Student Records & Access Control'
  };
}

/**
 * UPDATE: Edits existing student record and updates that EXACT same row
 */
function handleStudentUpdate(ss, student) {
  var studentSheet = getOrCreateStyledSheet(ss, SCHEMA.STUDENT_RECORDS.name, SCHEMA.STUDENT_RECORDS.headers);
  var email = (student.email || '').toLowerCase().trim();
  var studentId = (student.studentId || '').toUpperCase().trim();

  // Find existing row by email (Column 3) or studentId (Column 1)
  var rowIndex = findRowIndexByEmail(studentSheet, email, 3);
  if (rowIndex <= 0 && studentId) {
    rowIndex = findRowIndexByEmail(studentSheet, studentId, 1);
  }

  if (rowIndex <= 0) {
    // If not found, insert as new row
    return handleStudentCreate(ss, student);
  }

  // Read current row to preserve unsupplied fields
  var existingRow = studentSheet.getRange(rowIndex, 1, 1, SCHEMA.STUDENT_RECORDS.headers.length).getValues()[0];

  var levelsStr = student.approvedLevels !== undefined
    ? (Array.isArray(student.approvedLevels) ? student.approvedLevels.join(', ') : student.approvedLevels)
    : existingRow[4];

  var modulesStr = student.approvedModules !== undefined
    ? (Array.isArray(student.approvedModules) ? student.approvedModules.join(', ') : student.approvedModules)
    : existingRow[5];

  var deviceStatus = existingRow[8];
  if (student.resetDeviceLock) {
    deviceStatus = 'UNLOCKED';
  } else if (student.isDeviceBlocked) {
    deviceStatus = 'BLOCKED';
  } else if (student.activeDeviceToken) {
    deviceStatus = 'ACTIVE_LOCKED';
  }

  var updatedRow = [
    studentId || existingRow[0],
    student.name !== undefined ? student.name : existingRow[1],
    email || existingRow[2],
    student.password !== undefined ? student.password : existingRow[3],
    levelsStr,
    modulesStr,
    student.accessStatus !== undefined ? student.accessStatus : existingRow[6],
    student.quizAccessStatus !== undefined ? student.quizAccessStatus : existingRow[7],
    deviceStatus,
    student.lastLogin !== undefined ? student.lastLogin : existingRow[9],
    student.loginCount !== undefined ? student.loginCount : existingRow[10],
    existingRow[11] || student.registeredAt || new Date().toISOString()
  ];

  // Update EXACT matching row in place
  studentSheet.getRange(rowIndex, 1, 1, updatedRow.length).setValues([updatedRow]);

  // Also update corresponding row in Access Control sheet
  syncAccessControlRow(ss, student);

  return {
    status: 'success',
    action: 'STUDENT_UPDATE',
    rowIndex: rowIndex,
    studentId: studentId || existingRow[0],
    email: email,
    message: 'Existing student info successfully updated in row ' + rowIndex
  };
}

/**
 * UPSERT: Smart router that updates existing row or creates a new row
 */
function handleStudentUpsert(ss, student) {
  var studentSheet = getOrCreateStyledSheet(ss, SCHEMA.STUDENT_RECORDS.name, SCHEMA.STUDENT_RECORDS.headers);
  var email = (student.email || '').toLowerCase().trim();
  var rowIndex = findRowIndexByEmail(studentSheet, email, 3);

  if (rowIndex > 0) {
    return handleStudentUpdate(ss, student);
  } else {
    return handleStudentCreate(ss, student);
  }
}

/**
 * Access Control Row Synchronizer
 * Keeps the "Access Control" sheet aligned with student permissions & limits
 */
function syncAccessControlRow(ss, student) {
  var accessSheet = getOrCreateStyledSheet(ss, SCHEMA.ACCESS_CONTROL.name, SCHEMA.ACCESS_CONTROL.headers);
  var email = (student.email || student.studentEmail || '').toLowerCase().trim();
  var studentId = (student.studentId || '').toUpperCase().trim();

  var rowIndex = findRowIndexByEmail(accessSheet, email, 2);
  if (rowIndex <= 0 && studentId) {
    rowIndex = findRowIndexByEmail(accessSheet, studentId, 1);
  }

  var modulesStr = student.approvedModules !== undefined
    ? (Array.isArray(student.approvedModules) ? student.approvedModules.join(', ') : student.approvedModules)
    : (student.allowedModules || '');

  var portalStatus = student.accessStatus || student.portalAccessStatus || 'ENABLED';
  var quizStatus = student.quizAccessStatus || 'ENABLED';
  var maxAttempts = student.maxAttempts !== undefined ? student.maxAttempts : 3;
  var attemptsUsed = student.attemptsUsed !== undefined ? student.attemptsUsed : 0;
  var deviceLockActive = student.resetDeviceLock ? 'NO' : (student.activeDeviceToken ? 'YES' : 'NO');
  var deviceInfo = student.resetDeviceLock ? 'None' : (student.activeDeviceInfo || 'None');
  var secFlags = student.isDeviceBlocked ? 'DEVICE_BLOCKED' : 'NONE';
  var lastUpdated = student.lastLogin || new Date().toISOString();

  var rowData = [
    studentId,
    email,
    student.name || student.candidateName || studentId,
    portalStatus,
    quizStatus,
    modulesStr,
    maxAttempts,
    attemptsUsed,
    deviceLockActive,
    deviceInfo,
    secFlags,
    lastUpdated
  ];

  if (rowIndex > 0) {
    accessSheet.getRange(rowIndex, 1, 1, rowData.length).setValues([rowData]);
  } else {
    accessSheet.appendRow(rowData);
  }
}

/**
 * ACCESS UPDATE: Toggles portal login or quiz engine access
 */
function handleAccessUpdate(ss, data) {
  var studentSheet = getOrCreateStyledSheet(ss, SCHEMA.STUDENT_RECORDS.name, SCHEMA.STUDENT_RECORDS.headers);
  var accessSheet = getOrCreateStyledSheet(ss, SCHEMA.ACCESS_CONTROL.name, SCHEMA.ACCESS_CONTROL.headers);
  var email = (data.email || data.studentEmail || '').toLowerCase().trim();

  // Update in Student Records
  var sRow = findRowIndexByEmail(studentSheet, email, 3);
  if (sRow > 0) {
    if (data.accessStatus) {
      studentSheet.getRange(sRow, 7).setValue(data.accessStatus);
    }
    if (data.quizAccessStatus) {
      studentSheet.getRange(sRow, 8).setValue(data.quizAccessStatus);
    }
  }

  // Update in Access Control
  var aRow = findRowIndexByEmail(accessSheet, email, 2);
  if (aRow > 0) {
    if (data.accessStatus) {
      accessSheet.getRange(aRow, 4).setValue(data.accessStatus);
    }
    if (data.quizAccessStatus) {
      accessSheet.getRange(aRow, 5).setValue(data.quizAccessStatus);
    }
    accessSheet.getRange(aRow, 12).setValue(new Date().toISOString());
  }

  return {
    status: 'success',
    action: 'ACCESS_UPDATE',
    email: email,
    message: 'Access permissions updated in Student Records & Access Control'
  };
}

/**
 * DELETE: Archives student in Student Records and revokes Access Control
 */
function handleStudentDelete(ss, data) {
  var studentSheet = getOrCreateStyledSheet(ss, SCHEMA.STUDENT_RECORDS.name, SCHEMA.STUDENT_RECORDS.headers);
  var accessSheet = getOrCreateStyledSheet(ss, SCHEMA.ACCESS_CONTROL.name, SCHEMA.ACCESS_CONTROL.headers);
  var email = (data.email || '').toLowerCase().trim();

  var sRow = findRowIndexByEmail(studentSheet, email, 3);
  if (sRow > 0) {
    studentSheet.getRange(sRow, 7).setValue('REVOKED / DELETED');
  }

  var aRow = findRowIndexByEmail(accessSheet, email, 2);
  if (aRow > 0) {
    accessSheet.getRange(aRow, 4).setValue('REVOKED');
    accessSheet.getRange(aRow, 5).setValue('LOCKED');
    accessSheet.getRange(aRow, 12).setValue(new Date().toISOString());
  }

  return { status: 'success', action: 'STUDENT_DELETE', email: email };
}

// -------------------------------------------------------------
// NEW STUDENT REGISTRATION HANDLER
// -------------------------------------------------------------

/**
 * Captures signups from the "NEW STUDENT" registration flow
 * Columns: Name, Email, Phone Number, Registration Timestamp, Country Code, Target CIPS Level, Notes, Follow-up Status
 */
function handleNewStudentRegistration(ss, inq) {
  var sheet = getOrCreateStyledSheet(ss, SCHEMA.NEW_STUDENT_REGISTRATION.name, SCHEMA.NEW_STUDENT_REGISTRATION.headers);

  var row = [
    inq.name || '',
    (inq.email || '').toLowerCase().trim(),
    inq.phone || inq.phoneNumber || '',
    inq.submittedAt || inq.registrationTimestamp || new Date().toISOString(),
    inq.countryCode || '',
    inq.level || inq.targetLevel || 'Level 4 Diploma',
    inq.notes || '',
    inq.status || 'PENDING_CONTACT'
  ];

  sheet.appendRow(row);

  return {
    status: 'success',
    action: 'NEW_STUDENT_REGISTRATION',
    name: inq.name,
    email: inq.email,
    message: 'New Student Registration captured successfully'
  };
}

// -------------------------------------------------------------
// EXAM RESULTS & AUDIT LOG HANDLERS
// -------------------------------------------------------------

function handleExamResult(ss, res) {
  var sheet = getOrCreateStyledSheet(ss, SCHEMA.EXAM_RESULTS.name, SCHEMA.EXAM_RESULTS.headers);

  var total = res.totalQuestions || 20;
  var score = typeof res.score === 'number' ? res.score : 0;
  var pct = total > 0 ? Math.round((score / total) * 100) : 0;
  var isPass = res.passed === true || pct >= 70;

  var status = (res.examType && res.examType.indexOf('CR') !== -1)
    ? 'CASE STUDY SUBMITTED'
    : (isPass ? 'PASS' : 'FAIL');

  var row = [
    res.id || ('RES_' + Date.now()),
    res.submittedAt || res.timestamp || new Date().toISOString(),
    res.studentId || 'STU1001',
    res.studentName || 'Candidate',
    res.studentEmail || '',
    res.moduleCode || '',
    res.moduleTitle || '',
    res.examType || 'OR',
    score,
    total,
    pct + '%',
    status,
    res.durationSeconds || 0,
    res.autoSubmitted ? 'YES' : 'NO'
  ];

  sheet.appendRow(row);
  return { status: 'success', action: 'QUIZ_RESULT', receiptId: row[0] };
}

function handleAuditLog(ss, action, log) {
  var sheet = getOrCreateStyledSheet(ss, SCHEMA.LOGIN_SECURITY_AUDIT.name, SCHEMA.LOGIN_SECURITY_AUDIT.headers);

  var row = [
    log.timestamp || new Date().toISOString(),
    log.studentEmail || log.email || '',
    log.studentId || '',
    action === 'LOGIN' ? 'STUDENT_LOGIN' : (log.type || 'SECURITY_ALERT'),
    log.userAgent || log.browser || log.device || 'Web Client',
    log.deviceToken || 'N/A',
    log.status || 'SUCCESS',
    log.details || log.incidentDetails || ''
  ];

  sheet.appendRow(row);
  return { status: 'success', action: 'AUDIT_LOG' };
}

function handleGenericLog(ss, eventName, data) {
  var sheet = getOrCreateStyledSheet(ss, 'Activity Log', ['Timestamp', 'Event Type', 'Payload']);
  sheet.appendRow([new Date().toISOString(), eventName, JSON.stringify(data)]);
}

function handleBulkSync(ss, allData) {
  if (allData.students && Array.isArray(allData.students)) {
    allData.students.forEach(function(s) { handleStudentUpsert(ss, s); });
  }
  if (allData.accessControl && Array.isArray(allData.accessControl)) {
    allData.accessControl.forEach(function(ac) { syncAccessControlRow(ss, ac); });
  }
  if (allData.newStudentRegistrations && Array.isArray(allData.newStudentRegistrations)) {
    allData.newStudentRegistrations.forEach(function(inq) { handleNewStudentRegistration(ss, inq); });
  } else if (allData.inquiries && Array.isArray(allData.inquiries)) {
    allData.inquiries.forEach(function(inq) { handleNewStudentRegistration(ss, inq); });
  }
  if (allData.examResults && Array.isArray(allData.examResults)) {
    allData.examResults.forEach(function(res) { handleExamResult(ss, res); });
  } else if (allData.quizResults && Array.isArray(allData.quizResults)) {
    allData.quizResults.forEach(function(res) { handleExamResult(ss, res); });
  }
  if (allData.auditLogs && Array.isArray(allData.auditLogs)) {
    allData.auditLogs.forEach(function(l) { handleAuditLog(ss, l.action || 'LOGIN', l); });
  }
}

// -------------------------------------------------------------
// SPREADSHEET UTILITIES & ROW SEARCH HELPERS
// -------------------------------------------------------------

/**
 * Creates sheet tab if absent; applies high-contrast styling and freezes header
 */
function getOrCreateStyledSheet(ss, sheetName, headers) {
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
  }

  // If first time or empty, add styled header row
  if (sheet.getLastRow() === 0 && headers && headers.length > 0) {
    sheet.appendRow(headers);
    var range = sheet.getRange(1, 1, 1, headers.length);
    range.setBackground('#0f172a');       // Deep CIPS Navy
    range.setFontColor('#ffffff');        // High-contrast pure white
    range.setFontWeight('bold');
    range.setFontSize(10);
    range.setWrap(true);
    range.setVerticalAlignment('middle');
    sheet.setRowHeight(1, 36);
    sheet.setFrozenRows(1);
    
    // Auto-fit column widths with minimum readability padding
    for (var col = 1; col <= headers.length; col++) {
      sheet.autoResizeColumn(col);
      var width = sheet.getColumnWidth(col);
      if (width < 120) sheet.setColumnWidth(col, 130);
    }
  }

  return sheet;
}

/**
 * Finds 1-based row index by comparing value in target column (case-insensitive)
 */
function findRowIndexByEmail(sheet, queryValue, colIndex) {
  if (!queryValue) return -1;
  var cleanQuery = queryValue.toString().toLowerCase().trim();
  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return -1;

  var rangeValues = sheet.getRange(2, colIndex, lastRow - 1, 1).getValues();
  for (var i = 0; i < rangeValues.length; i++) {
    var cellValue = (rangeValues[i][0] || '').toString().toLowerCase().trim();
    if (cellValue === cleanQuery) {
      return i + 2; // +2 for 1-based index including header
    }
  }
  return -1;
}

function createJsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
