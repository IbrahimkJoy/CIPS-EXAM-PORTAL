/**
 * CIPS Exam Engine - OR (Objective Response) & CR (Constructive Response)
 */

import { apiConfig } from './api-config.js';
import { downloadExamPaperResultPdf } from './exam-result-pdf.js';

let lastCompletedResult = null;

document.addEventListener('DOMContentLoaded', async () => {
  const activeStudent = apiConfig.getStoredStudent();
  const urlParams = new URLSearchParams(window.location.search);
  const moduleCode = urlParams.get('module') || 'L4M1';

  if (!activeStudent) {
    window.location.href = 'student-login.html';
    return;
  }

  // Check quiz authorization token
  const quizAuthRaw = sessionStorage.getItem('cips_quiz_authorized');
  if (!quizAuthRaw) {
    window.location.href = `quiz-login.html?module=${encodeURIComponent(moduleCode)}`;
    return;
  }

  const quizAuth = JSON.parse(quizAuthRaw);
  if (quizAuth.moduleCode !== moduleCode && quizAuth.moduleCode !== 'ALL') {
    window.location.href = `quiz-login.html?module=${encodeURIComponent(moduleCode)}`;
    return;
  }

  // Update header labels
  document.getElementById('exam-student-email').textContent = `Student: ${activeStudent.email}`;
  document.getElementById('exam-module-code').textContent = `Module ${moduleCode} Assessment`;

  // Fetch module metadata
  let moduleMeta = null;
  try {
    const modulesData = await apiConfig.getModulesData();
    for (const levelKey in modulesData) {
      const levelObj = modulesData[levelKey];
      if (levelObj.modules) {
        const found = levelObj.modules.find(m => m.code === moduleCode);
        if (found) {
          moduleMeta = found;
          break;
        }
      }
    }
  } catch (err) {
    console.error('Failed to load module metadata:', err);
  }

  if (!moduleMeta) {
    // Default fallback
    moduleMeta = {
      code: moduleCode,
      name: 'Procurement Assessment',
      examType: 'OR',
      duration: '1.5 Hours',
      questionCount: 60
    };
  }

  const isCR = moduleMeta.examType.includes('CR') || moduleMeta.examType.includes('Case');
  document.getElementById('exam-type-tag').textContent = isCR ? 'Case Study CR (Constructive Response)' : 'Objective Response (OR - 60 MCQs)';

  // Populate Instruction View details
  const instrModuleTitle = document.getElementById('instruction-module-title');
  if (instrModuleTitle) instrModuleTitle.textContent = `${moduleCode}: ${moduleMeta.name}`;
  const instrDuration = document.getElementById('instruction-duration');
  if (instrDuration) instrDuration.textContent = isCR ? (moduleCode === 'L6M4' ? '2.0 Hours (120 Mins)' : '3.0 Hours (180 Mins)') : '1.5 Hours (90 Mins)';

  // Timer Setup (Seconds)
  let totalDurationSeconds = 5400; // default 90 mins for OR
  if (isCR) {
    if (moduleCode === 'L6M4') {
      totalDurationSeconds = 7200; // 2 hours
    } else {
      totalDurationSeconds = 10800; // 3 hours
    }
  }

  let remainingSeconds = totalDurationSeconds;
  let timerInterval = null;
  let examStarted = false;

  // Handle Start Exam Instruction Button Click
  const startExamBtn = document.getElementById('btn-start-exam-now');
  if (startExamBtn) {
    startExamBtn.onclick = () => {
      document.getElementById('instruction-view').style.display = 'none';
      document.getElementById('exam-active-panel').style.display = 'block';
      if (!isCR) {
        document.getElementById('or-sidebar-panel').style.display = 'block';
      }
      examStarted = true;
      startTimer();
    };
  }

  function startTimer() {
    updateTimerDisplay();
    timerInterval = setInterval(() => {
      remainingSeconds--;
      updateTimerDisplay();

      if (remainingSeconds <= 0) {
        clearInterval(timerInterval);
        alert('⌛ Exam time has expired! Auto-submitting your assessment now...');
        submitExam(true);
      }
    }, 1000);
  }

  function updateTimerDisplay() {
    const display = document.getElementById('countdown-timer-display');
    if (!display) return;

    const hrs = Math.floor(remainingSeconds / 3600);
    const mins = Math.floor((remainingSeconds % 3600) / 60);
    const secs = remainingSeconds % 60;

    const format = (n) => n.toString().padStart(2, '0');
    display.textContent = `${format(hrs)}:${format(mins)}:${format(secs)}`;

    // Warning color when < 10 mins remaining
    if (remainingSeconds < 600) {
      display.style.color = '#ef4444';
    }
  }

  // --- MODE A: OBJECTIVE RESPONSE (OR - MCQs) ---
  if (!isCR) {
    document.getElementById('or-exam-view').style.display = 'block';
    document.getElementById('or-sidebar-panel').style.display = 'block';
    document.getElementById('cr-exam-view').style.display = 'none';

    let questions = [];

    // Fetch custom questions from quiz bank with student-specific non-repeating shuffle filter
    try {
      const bankUrl = `${apiConfig.baseUrl}/api/quiz-bank/${encodeURIComponent(moduleCode)}?studentEmail=${encodeURIComponent(activeStudent.email)}`;
      const bankRes = await fetch(bankUrl);
      if (bankRes.ok) {
        const bankData = await bankRes.json();
        if (bankData && Array.isArray(bankData.questions) && bankData.questions.length > 0) {
          questions = bankData.questions.map((bq, idx) => {
            const rawOpts = Array.isArray(bq.options) ? bq.options : [bq.optionA, bq.optionB, bq.optionC, bq.optionD, bq.optionE, bq.optionF].filter(Boolean);
            const correctLetter = (bq.correctAnswer || 'A').toString().trim().toUpperCase();
            const correctIndex = 'ABCDEF'.indexOf(correctLetter) !== -1 ? 'ABCDEF'.indexOf(correctLetter) : 0;
            return {
              id: bq.id || `Q_${idx + 1}`,
              prompt: bq.question || `Question ${idx + 1}`,
              options: rawOpts.length >= 2 ? rawOpts : ['Option A', 'Option B', 'Option C', 'Option D'],
              correctIndex: correctIndex < rawOpts.length ? correctIndex : 0,
              correctAnswer: correctLetter,
              explanation: bq.explanation || ''
            };
          });
        }
      }
    } catch (e) {
      console.warn('Quiz bank fetch fallback:', e);
    }

    if (questions.length === 0) {
      questions = generate60ORQuestions(moduleCode, moduleMeta.name);
    }

    const totalQuestionsCount = questions.length;
    let currentQIndex = 0;
    const userAnswers = {}; // { qIndex: selectedOptionIndex }
    const flaggedQuestions = new Set();

    renderGrid();
    loadQuestion(currentQIndex);

    function loadQuestion(index) {
      currentQIndex = index;
      const q = questions[index];

      document.getElementById('or-question-number-badge').textContent = `Question ${index + 1} of ${totalQuestionsCount}`;
      document.getElementById('or-question-text').textContent = q.prompt;
      document.getElementById('or-progress-counter').textContent = `${index + 1} / ${totalQuestionsCount}`;

      // Flag button
      const flagBtn = document.getElementById('btn-flag-question');
      if (flaggedQuestions.has(index)) {
        flagBtn.classList.add('flagged');
        flagBtn.textContent = '🚩 Flagged';
      } else {
        flagBtn.classList.remove('flagged');
        flagBtn.textContent = '🚩 Flag for Review';
      }

      flagBtn.onclick = () => {
        if (flaggedQuestions.has(index)) {
          flaggedQuestions.delete(index);
          flagBtn.classList.remove('flagged');
          flagBtn.textContent = '🚩 Flag for Review';
        } else {
          flaggedQuestions.add(index);
          flagBtn.classList.add('flagged');
          flagBtn.textContent = '🚩 Flagged';
        }
        renderGrid();
      };

      // Options
      const optionsContainer = document.getElementById('or-options-container');
      optionsContainer.innerHTML = '';

      q.options.forEach((optText, optIdx) => {
        const item = document.createElement('div');
        const isSelected = userAnswers[index] === optIdx;
        item.className = `option-item ${isSelected ? 'selected' : ''}`;

        item.innerHTML = `
          <div class="option-indicator-wrap">
            <span class="option-letter-badge">${String.fromCharCode(65 + optIdx)}</span>
          </div>
          <div class="option-text-wrap">
            <span class="option-text">${optText}</span>
          </div>
          <input 
            type="radio" 
            name="or-option" 
            class="option-radio" 
            ${isSelected ? 'checked' : ''} 
            tabindex="-1"
            aria-hidden="true"
          />
        `;

        item.onclick = () => {
          userAnswers[index] = optIdx;
          loadQuestion(index);
          renderGrid();
        };

        optionsContainer.appendChild(item);
      });

      // Nav buttons state
      document.getElementById('btn-prev-q').disabled = index === 0;
      document.getElementById('btn-next-q').disabled = index === totalQuestionsCount - 1;
    }

    document.getElementById('btn-prev-q').onclick = () => {
      if (currentQIndex > 0) loadQuestion(currentQIndex - 1);
    };

    document.getElementById('btn-next-q').onclick = () => {
      if (currentQIndex < totalQuestionsCount - 1) loadQuestion(currentQIndex + 1);
    };

    function renderGrid() {
      const gridContainer = document.getElementById('or-questions-grid');
      if (!gridContainer) return;
      gridContainer.innerHTML = '';

      for (let i = 0; i < totalQuestionsCount; i++) {
        const btn = document.createElement('button');
        const isAnswered = userAnswers.hasOwnProperty(i);
        const isFlagged = flaggedQuestions.has(i);
        const isCurrent = i === currentQIndex;

        let cls = 'q-grid-btn';
        if (isCurrent) cls += ' current';
        if (isAnswered) cls += ' answered';
        if (isFlagged) cls += ' flagged';

        btn.className = cls;
        btn.textContent = i + 1;
        btn.onclick = () => loadQuestion(i);

        gridContainer.appendChild(btn);
      }
    }

    // Submit listener for OR
    document.getElementById('btn-submit-exam-now').onclick = () => {
      const answeredCount = Object.keys(userAnswers).length;
      const modal = document.getElementById('confirm-submission-modal');
      const modalBody = document.getElementById('confirm-modal-body');
      if (modalBody) {
        modalBody.textContent = `You have answered ${answeredCount} of ${totalQuestionsCount} questions. Are you sure you want to finalize and submit your assessment?`;
      }
      if (modal) modal.classList.add('active');
    };

    const confirmYes = document.getElementById('btn-confirm-yes');
    const confirmNo = document.getElementById('btn-confirm-no');
    const confirmModal = document.getElementById('confirm-submission-modal');

    if (confirmYes) {
      confirmYes.onclick = () => {
        if (confirmModal) confirmModal.classList.remove('active');
        submitExam(false);
      };
    }

    if (confirmNo) {
      confirmNo.onclick = () => {
        if (confirmModal) confirmModal.classList.remove('active');
      };
    }

    async function submitExam(autoSubmitted) {
      clearInterval(timerInterval);

      let score = 0;
      questions.forEach((q, idx) => {
        if (userAnswers[idx] === q.correctIndex) {
          score++;
        }
      });

      const timeSpent = totalDurationSeconds - remainingSeconds;
      const isPass = score >= 42; // Passing threshold: 70% (42/60 marks for OR exam)

      const questionsSnapshot = questions.map((q, idx) => {
        const studentAnsIdx = userAnswers.hasOwnProperty(idx) ? userAnswers[idx] : null;
        const isCorrect = studentAnsIdx === q.correctIndex;
        return {
          id: q.id,
          questionNumber: idx + 1,
          question: q.prompt,
          options: q.options,
          correctIndex: q.correctIndex,
          correctAnswer: ['A', 'B', 'C', 'D', 'E', 'F'][q.correctIndex] || 'A',
          correctOptionText: q.options[q.correctIndex] || '',
          studentAnswerIndex: studentAnsIdx,
          studentAnswerLetter: studentAnsIdx !== null ? (['A', 'B', 'C', 'D', 'E', 'F'][studentAnsIdx] || 'A') : 'Unanswered',
          studentOptionText: studentAnsIdx !== null ? (q.options[studentAnsIdx] || '') : 'Not attempted',
          isCorrect,
          mark: isCorrect ? 1 : 0,
          explanation: q.explanation || 'Refer to CIPS syllabus learning outcomes for this module.'
        };
      });

      const payload = {
        studentEmail: activeStudent.email,
        moduleCode,
        examType: 'OR',
        score,
        totalQuestions: totalQuestionsCount,
        passed: isPass,
        answers: userAnswers,
        questionsSnapshot,
        durationSeconds: timeSpent,
        autoSubmitted
      };

      try {
        const res = await apiConfig.submitQuizAnswers(payload);
        const receiptId = res.resultId || ('RES_' + Date.now());

        lastCompletedResult = {
          id: receiptId,
          studentEmail: activeStudent.email,
          studentName: activeStudent.name || activeStudent.studentId || 'Registered Candidate',
          studentId: activeStudent.studentId || 'STU1001',
          moduleCode,
          moduleTitle: moduleMeta.name,
          examType: 'OR',
          score,
          totalQuestions: totalQuestionsCount,
          passed: isPass,
          durationSeconds: timeSpent,
          submittedAt: new Date().toISOString(),
          questionsSnapshot,
          answers: userAnswers
        };

        showResultsModal(score, totalQuestionsCount, timeSpent, receiptId, 'OR', lastCompletedResult);
      } catch (err) {
        alert(err.message || 'Error submitting exam results.');
      }
    }
  }

  // --- MODE B: CONSTRUCTIVE RESPONSE (CR - Case Study) ---
  else {
    document.getElementById('or-exam-view').style.display = 'none';
    document.getElementById('or-sidebar-panel').style.display = 'none';
    document.getElementById('cr-exam-view').style.display = 'block';

    const crData = getCRCaseStudyData(moduleCode, moduleMeta.name);

    document.getElementById('cr-case-text').innerHTML = crData.caseNarrative;

    const essayContainer = document.getElementById('cr-questions-container');
    essayContainer.innerHTML = '';

    const crAnswers = {};

    crData.questions.forEach((q, idx) => {
      const card = document.createElement('div');
      card.className = 'cr-essay-card';
      card.innerHTML = `
        <div class="cr-essay-header">
          <div class="cr-essay-title">Question ${idx + 1}: ${q.title}</div>
          <span class="cr-marks-badge">${q.marks} Marks</span>
        </div>
        <p style="font-size: 0.95rem; color: #334155; margin-bottom: 1rem;">${q.prompt}</p>
        <textarea 
          id="cr-answer-${idx}" 
          class="cr-textarea" 
          placeholder="Type your structured analytical response here (include definitions, frameworks, and application to scenario)..."
        ></textarea>
        <div style="text-align: right; font-size: 0.8rem; color: var(--text-muted); margin-top: 0.4rem;" id="word-count-${idx}">
          Word count: 0
        </div>
      `;

      essayContainer.appendChild(card);

      const textarea = card.querySelector(`#cr-answer-${idx}`);
      const wordCountDisplay = card.querySelector(`#word-count-${idx}`);

      textarea.oninput = (e) => {
        crAnswers[idx] = e.target.value;
        const words = e.target.value.trim().split(/\s+/).filter(w => w.length > 0).length;
        wordCountDisplay.textContent = `Word count: ${words}`;
      };
    });

    document.getElementById('btn-submit-exam-now').onclick = () => {
      if (confirm('Submit your written Case Study answers for examiner grading?')) {
        submitCRExam(false);
      }
    };

    async function submitCRExam(autoSubmitted) {
      clearInterval(timerInterval);

      const timeSpent = totalDurationSeconds - remainingSeconds;

      const questionsSnapshot = crData.questions.map((q, idx) => ({
        id: idx + 1,
        questionNumber: idx + 1,
        title: q.title,
        marks: q.marks,
        prompt: q.prompt,
        studentAnswer: crAnswers[idx] || 'No response recorded',
        wordCount: (crAnswers[idx] || '').trim().split(/\s+/).filter(w => w.length > 0).length
      }));

      const payload = {
        studentEmail: activeStudent.email,
        moduleCode,
        examType: 'Case Study CR',
        score: null, // Pending examiner manual marking
        totalQuestions: crData.questions.length,
        answers: crAnswers,
        questionsSnapshot,
        durationSeconds: timeSpent,
        autoSubmitted
      };

      try {
        const res = await apiConfig.submitQuizAnswers(payload);
        const receiptId = res.resultId || ('RES_' + Date.now());

        lastCompletedResult = {
          id: receiptId,
          studentEmail: activeStudent.email,
          studentName: activeStudent.name || activeStudent.studentId || 'Registered Candidate',
          studentId: activeStudent.studentId || 'STU1001',
          moduleCode,
          moduleTitle: moduleMeta.name,
          examType: 'Case Study CR',
          score: null,
          totalQuestions: crData.questions.length,
          passed: false,
          durationSeconds: timeSpent,
          submittedAt: new Date().toISOString(),
          questionsSnapshot,
          answers: crAnswers
        };

        showResultsModal(null, crData.questions.length, timeSpent, receiptId, 'CR', lastCompletedResult);
      } catch (err) {
        alert(err.message || 'Error submitting case study answers.');
      }
    }
  }

  function showResultsModal(score, total, timeSpent, receiptId, type, resultObj) {
    const modal = document.getElementById('exam-results-modal');
    const body = document.getElementById('results-modal-body');

    const mins = Math.floor(timeSpent / 60);
    const secs = timeSpent % 60;

    let html = '';
    if (type === 'OR') {
      const percentage = Math.round((score / total) * 100);
      const isPass = score >= 42 || percentage >= 70;

      html = `
        <div class="results-summary-card">
          <p class="results-status-title">Result: ${isPass ? 'PASS' : 'FAIL (Requires Revision)'}</p>
          <p class="results-score-display" style="color: ${isPass ? '#059669' : '#dc2626'};">
            ${score} / ${total} (${percentage}%)
          </p>
        </div>
        <div style="background: var(--bg-subtle, #f8fafc); border: 1px solid var(--border-light, #e2e8f0); border-radius: 8px; padding: 0.75rem; margin-bottom: 0.75rem; font-size: 0.85rem;">
          <div><strong>Passing Criteria:</strong> 70% (42 out of 60 correct required to pass)</div>
          <div style="color: ${isPass ? '#047857' : '#b91c1c'}; font-weight: 700; margin-top: 0.25rem;">
            ${isPass ? '✓ Congratulations! You have successfully passed this OR exam.' : '✕ You did not reach the 42 mark threshold required to pass.'}
          </div>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 0.75rem; font-size: 0.85rem;">
          <div><strong>Receipt ID:</strong> <code style="font-size: 0.8rem; background: #e2e8f0; padding: 2px 4px; border-radius: 4px;">${receiptId}</code></div>
          <div><strong>Module:</strong> ${moduleCode}</div>
          <div><strong>Time Taken:</strong> ${mins}m ${secs}s</div>
          <div><strong>Status:</strong> ${isPass ? '<span style="color: #059669; font-weight: 700;">Accredited</span>' : '<span style="color: #dc2626; font-weight: 700;">Needs Revision</span>'}</div>
        </div>
        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 0.75rem; margin-top: 0.75rem;">
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
            <div>
              <strong style="color: #166534; font-size: 0.88rem;">📄 Official Exam Paper Result Ready</strong>
              <div style="font-size: 0.78rem; color: #15803d;">Complete transcript with official CIPS validation stamp and itemized question breakdown.</div>
            </div>
            <button id="btn-quick-download-result" style="background: #059669; color: white; border: none; padding: 6px 12px; border-radius: 6px; font-weight: 700; font-size: 0.82rem; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;">
              <span>⬇️</span> Download PDF
            </button>
          </div>
        </div>
      `;
    } else {
      html = `
        <div class="results-summary-card">
          <p class="results-status-title">Constructive Response Submitted</p>
          <p style="font-size: 0.95rem; line-height: 1.5; color: #0284c7; margin: 0.25rem 0 0 0;">
            Your written answers have been securely transmitted for CIPS Examiner evaluation.
          </p>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 0.75rem; font-size: 0.85rem;">
          <div><strong>Receipt ID:</strong> <code style="font-size: 0.8rem; background: #e2e8f0; padding: 2px 4px; border-radius: 4px;">${receiptId}</code></div>
          <div><strong>Module:</strong> ${moduleCode}</div>
          <div><strong>Essay Questions:</strong> ${total} Submitted</div>
          <div><strong>Time Taken:</strong> ${mins}m ${secs}s</div>
        </div>
        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 0.75rem; margin-top: 0.75rem;">
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
            <div>
              <strong style="color: #166534; font-size: 0.88rem;">📄 Submission Document Ready</strong>
              <div style="font-size: 0.78rem; color: #15803d;">Download your timestamped examination transcript and submitted essay responses.</div>
            </div>
            <button id="btn-quick-download-result" style="background: #059669; color: white; border: none; padding: 6px 12px; border-radius: 6px; font-weight: 700; font-size: 0.82rem; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;">
              <span>⬇️</span> Download PDF
            </button>
          </div>
        </div>
      `;
    }

    body.innerHTML = html;
    modal.classList.add('active');

    // Connect Download Exam Paper Result button
    const targetResult = resultObj || lastCompletedResult;
    const btnDownload = document.getElementById('btn-download-exam-result');
    if (btnDownload) {
      btnDownload.onclick = () => {
        downloadExamPaperResultPdf(targetResult);
      };
    }

    const btnQuickDownload = document.getElementById('btn-quick-download-result');
    if (btnQuickDownload) {
      btnQuickDownload.onclick = () => {
        downloadExamPaperResultPdf(targetResult);
      };
    }

    const btnViewHistory = document.getElementById('btn-view-result-history');
    if (btnViewHistory) {
      btnViewHistory.onclick = () => {
        window.location.href = 'dashboard.html?tab=results';
      };
    }

    document.getElementById('btn-finish-return').onclick = () => {
      window.location.href = 'dashboard.html';
    };
  }

  // 60 Question Generator for OR Mode
  function generate60ORQuestions(code, title) {
    const questions = [];
    const topics = [
      "Kraljic Portfolio Matrix classification",
      "Total Cost of Ownership (TCO) components",
      "Incoterms 2020 transfer of risk",
      "E-Procurement reverse auctions",
      "SLA key performance indicators",
      "Supplier Relationship Management (SRM)",
      "CIPS Code of Conduct ethical standards",
      "BATNA and concession strategies in negotiation",
      "Contractual indemnities vs liquidated damages",
      "Scope 3 greenhouse gas emission accounting",
      "Public sector procurement regulations",
      "Inventory valuation (FIFO vs LIFO vs Weighted Average)"
    ];

    for (let i = 1; i <= 60; i++) {
      const topic = topics[i % topics.length];
      questions.push({
        id: i,
        prompt: `Question ${i}: Under CIPS guidelines for ${code} (${title}), which option best characterizes ${topic}?`,
        options: [
          `Primary strategic emphasis on minimizing operational risk while optimizing whole-life value creation.`,
          `Exclusive reliance on lowest spot-market purchase price without lifecycle evaluation.`,
          `Unilateral amendment of commercial terms without supplier negotiation.`,
          `Delegation of regulatory compliance to unvetted tier-3 subcontractors.`
        ],
        correctIndex: 0
      });
    }

    return questions;
  }

  // CR Case Study Generator
  function getCRCaseStudyData(code, name) {
    return {
      caseNarrative: `
        <strong>GlobalTech Logistics PLC Case Scenario:</strong><br>
        GlobalTech PLC is a FTSE-100 multinational manufacturer facing volatile commodity pricing, geopolitical supply chain disruptions, and heightened ESG reporting regulations across Europe and Asia. The Board of Directors has tasked the Chief Procurement Officer (CPO) with reforming commercial contracting, mitigating tier-1 and tier-2 supplier risks, and implementing ethical sourcing policies across all operating units for module <strong>${code} - ${name}</strong>.
      `,
      questions: [
        {
          title: "Strategic Procurement Analysis",
          marks: 25,
          prompt: "Critically appraise the procurement governance strategy required to mitigate supply chain disruptions while maintaining cost competitiveness in GlobalTech PLC."
        },
        {
          title: "Contractual & Risk Governance",
          marks: 25,
          prompt: "Analyze key contract clauses and risk mitigation frameworks (e.g. indemnities, force majeure, BCP) necessary to protect GlobalTech's commercial position."
        },
        {
          title: "Ethical & Responsible Sourcing",
          marks: 25,
          prompt: "Evaluate how GlobalTech PLC can integrate the CIPS Code of Conduct and Scope 3 ESG auditing across its global supplier network."
        },
        {
          title: "Stakeholder Leadership & Negotiation",
          marks: 25,
          prompt: "Propose a structured stakeholder communication plan and BATNA negotiation strategy for managing senior executive expectations during this transformation."
        }
      ]
    };
  }
});
