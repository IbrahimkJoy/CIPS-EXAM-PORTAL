import { apiConfig } from './api-config.js';

export async function loadQuizResultsHistory(tbodyId, studentEmailFilter = '') {
  const tbody = document.getElementById(tbodyId);
  if (!tbody) return;

  try {
    const data = await apiConfig.getAdminQuizResults(studentEmailFilter);
    const results = data.results || [];

    if (results.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">No quiz submission results found.</td></tr>`;
      return;
    }

    tbody.innerHTML = results.map(r => {
      const pct = r.totalQuestions ? Math.round((r.score / r.totalQuestions) * 100) : 0;
      const passStatus = pct >= 70
        ? `<span class="badge-status badge-unlocked">PASS (${pct}%)</span>`
        : `<span class="badge-status badge-blocked">FAIL (${pct}%)</span>`;

      return `
        <tr>
          <td>
            <div style="font-weight: 800; color: var(--cips-navy);">${r.studentEmail}</div>
            <div style="font-size: 11px; color: var(--text-subtle);">Result ID: ${r.id}</div>
          </td>
          <td><strong style="color: var(--cips-accent);">${r.moduleCode}</strong></td>
          <td><span style="font-weight: 700;">${r.score} / ${r.totalQuestions || 0}</span></td>
          <td>${passStatus}</td>
          <td>${r.examType || 'Objective Response'}</td>
          <td style="font-size: 0.8rem; color: var(--text-muted);">${new Date(r.submittedAt).toLocaleString()}</td>
          <td>
            <a href="${apiConfig.getExportResultsUrl(r.studentEmail)}" class="btn btn-secondary btn-action-sm" style="text-decoration: none;">
              📥 Export Student
            </a>
          </td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" style="color: var(--cips-red);">Failed to load quiz results: ${err.message}</td></tr>`;
  }
}

export function bindExportButtons(btnAllId, filterSelectId) {
  const btnAll = document.getElementById(btnAllId);
  if (btnAll) {
    btnAll.addEventListener('click', () => {
      window.location.href = apiConfig.getExportResultsUrl('');
    });
  }

  const filterSelect = document.getElementById(filterSelectId);
  if (filterSelect) {
    filterSelect.addEventListener('change', (e) => {
      const filterEmail = e.target.value;
      loadQuizResultsHistory('quiz-results-tbody', filterEmail);
    });
  }
}
