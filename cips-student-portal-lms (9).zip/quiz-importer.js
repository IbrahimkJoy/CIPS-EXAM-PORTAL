import { apiConfig } from './api-config.js';

document.addEventListener('DOMContentLoaded', async () => {
  const adminSession = apiConfig.getStoredAdmin();
  if (!adminSession) {
    window.location.href = 'admin-login.html';
    return;
  }

  const adminLabel = document.getElementById('admin-user-label');
  if (adminLabel) adminLabel.textContent = adminSession.username;

  const btnLogout = document.getElementById('btn-admin-logout');
  if (btnLogout) {
    btnLogout.addEventListener('click', () => {
      apiConfig.clearStoredAdmin();
      window.location.href = 'admin-login.html';
    });
  }

  const selectModule = document.getElementById('select-module-code');
  const contentWorkspace = document.getElementById('content-workspace');

  const booksContainer = document.getElementById('books-list-container');
  const recordingsContainer = document.getElementById('recordings-list-container');
  const examsContainer = document.getElementById('exams-list-container');
  const notesContainer = document.getElementById('notes-list-container');

  const btnSaveAll = document.getElementById('btn-save-all-content');
  const btnLoadDrive = document.getElementById('btn-load-drive-picker');

  const driveModal = document.getElementById('drive-picker-modal');
  const driveContainer = document.getElementById('drive-files-container');
  const btnCloseDrive = document.getElementById('btn-close-drive-modal');

  // CSV Importer Elements
  const csvForm = document.getElementById('csv-upload-form');
  const csvFileInput = document.getElementById('csv-file-input');
  const csvPreviewContainer = document.getElementById('csv-preview-container');
  const csvPreviewTbody = document.getElementById('csv-preview-tbody');
  const csvCountBadge = document.getElementById('csv-count-badge');
  const btnConfirmCsv = document.getElementById('btn-confirm-csv-import');

  let activeModuleCode = '';
  let activeModuleContent = { books: [], recordings: [], previousExams: [], notes: [] };
  let parsedQuestions = [];
  let convertedCsvCache = '';
  let lastUploadedFileName = 'CIPS_Quiz_Questions.csv';

  // Populate module dropdown
  try {
    const modulesData = await apiConfig.getModulesData();
    populateModuleDropdown(modulesData);
  } catch (e) {
    console.error('Error loading modules dataset:', e);
  }

  if (selectModule) {
    selectModule.addEventListener('change', async (e) => {
      activeModuleCode = e.target.value;
      if (!activeModuleCode) {
        contentWorkspace.style.display = 'none';
        return;
      }
      contentWorkspace.style.display = 'grid';
      await loadModuleContent(activeModuleCode);
    });
  }

  // Material Add Buttons
  document.getElementById('btn-add-book')?.addEventListener('click', () => {
    activeModuleContent.books.push({
      title: `${activeModuleCode} New Study Guide`,
      embedUrl: 'https://docs.google.com/viewer?url=https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf&embedded=true',
      fileType: 'PDF Document',
      pages: 100
    });
    renderBooks();
  });

  document.getElementById('btn-add-recording')?.addEventListener('click', () => {
    activeModuleContent.recordings.push({
      id: 'REC_' + Date.now().toString(36),
      title: `${activeModuleCode} Lecture Recording`,
      duration: '1h 30m',
      videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
      presenter: 'CIPS Master Lecturer'
    });
    renderRecordings();
  });

  document.getElementById('btn-add-exam')?.addEventListener('click', () => {
    activeModuleContent.previousExams.push({
      year: '2025 Session',
      title: `${activeModuleCode} Past Examination Paper`,
      embedUrl: 'https://docs.google.com/viewer?url=https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf&embedded=true'
    });
    renderExams();
  });

  document.getElementById('btn-add-note')?.addEventListener('click', () => {
    activeModuleContent.notes.push({
      title: `${activeModuleCode} Chapter Revision Notes`,
      content: 'Key concepts, definitions, and frameworks for revision.'
    });
    renderNotes();
  });

  if (btnSaveAll) {
    btnSaveAll.addEventListener('click', async () => {
      if (!activeModuleCode) return;
      try {
        await apiConfig.saveAdminModuleContent(activeModuleCode, activeModuleContent);
        alert(`Module content for ${activeModuleCode} saved successfully!`);
      } catch (err) {
        alert('Failed to save module content: ' + err.message);
      }
    });
  }

  // Google Drive Recording Selector
  if (btnLoadDrive) {
    btnLoadDrive.addEventListener('click', async () => {
      driveModal.classList.add('active');
      driveContainer.innerHTML = '<p style="color: var(--text-muted);">Loading Google Drive files...</p>';
      try {
        const driveData = await apiConfig.getAdminDriveFiles();
        if (!driveData.files || driveData.files.length === 0) {
          driveContainer.innerHTML = '<p style="color: var(--text-muted);">No video files found in Google Drive folder.</p>';
          return;
        }

        driveContainer.innerHTML = driveData.files.map(f => `
          <div style="padding: 0.75rem; border: 1px solid var(--border-light); border-radius: var(--radius-sm); margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="font-weight: 700; color: var(--cips-navy); font-size: 0.85rem;">🎥 ${f.name}</div>
              <div style="font-size: 11px; color: var(--text-subtle);">${f.mimeType}</div>
            </div>
            <button class="btn btn-secondary btn-action-sm btn-pick-recording" data-url="${f.embedUrl}" data-name="${f.name}">
              Select
            </button>
          </div>
        `).join('');

        document.querySelectorAll('.btn-pick-recording').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const url = e.currentTarget.getAttribute('data-url');
            const name = e.currentTarget.getAttribute('data-name');
            activeModuleContent.recordings.push({
              id: 'REC_' + Date.now().toString(36),
              title: name,
              duration: 'Google Drive Stream',
              videoUrl: url,
              presenter: 'Drive Master Class'
            });
            renderRecordings();
            driveModal.classList.remove('active');
            alert(`Added "${name}" to recordings list.`);
          });
        });
      } catch (err) {
        driveContainer.innerHTML = `<p style="color: var(--cips-red);">Drive fetch failed: ${err.message}</p>`;
      }
    });
  }

  if (btnCloseDrive) {
    btnCloseDrive.addEventListener('click', () => driveModal.classList.remove('active'));
  }

  // ==========================================
  // CIPS QUIZ CONVERTER & LMS EXPORT SUITE
  // ==========================================
  const excelModal = document.getElementById('fullscreen-csv-editor-modal');
  const excelTbody = document.getElementById('excel-editor-tbody');
  const btnAddExcelRow = document.getElementById('btn-add-excel-row');
  const btnSaveExcelImport = document.getElementById('btn-save-excel-import');
  const btnCloseExcelModal = document.getElementById('btn-close-excel-modal');

  // Converter Navigation & Input Elements
  const tabBtnFileUpload = document.getElementById('tab-btn-file-upload');
  const tabBtnTextPaste = document.getElementById('tab-btn-text-paste');
  const tabPaneFile = document.getElementById('converter-tab-file-pane');
  const tabPanePaste = document.getElementById('converter-tab-paste-pane');
  const converterDropzone = document.getElementById('converter-dropzone');
  const dropzoneSelectedName = document.getElementById('dropzone-selected-name');
  const pasteTextarea = document.getElementById('converter-paste-textarea');
  const btnInsertSampleQuiz = document.getElementById('btn-insert-sample-quiz');

  // Toolbar & Trigger Buttons
  const btnParseCsv = document.getElementById('btn-parse-csv');
  const btnOpenSpreadsheetModal = document.getElementById('btn-open-spreadsheet-modal');
  const btnQuickSyncLms = document.getElementById('btn-quick-sync-lms');
  const btnPreviewSyncLms = document.getElementById('btn-preview-sync-lms');
  const btnPanelExportCsv = document.getElementById('btn-panel-export-csv');
  const btnPanelExportExcel = document.getElementById('btn-panel-export-excel');
  const btnOpenLmsSettings = document.getElementById('btn-open-lms-settings');

  // Spreadsheet Toolbar Buttons
  const btnExcelExportCsv = document.getElementById('btn-excel-export-csv');
  const btnExcelExportExcel = document.getElementById('btn-excel-export-excel');
  const btnExcelSyncLms = document.getElementById('btn-excel-sync-lms');
  const btnExcelOpenLmsSettings = document.getElementById('btn-excel-open-lms-settings');

  // LMS Connection Modal Elements
  const lmsModal = document.getElementById('lms-connection-modal');
  const lmsSettingsForm = document.getElementById('lms-settings-form');
  const btnCloseLmsModalX = document.getElementById('btn-close-lms-modal-x');
  const btnCloseLmsModal = document.getElementById('btn-close-lms-modal');
  const btnTestLmsConnection = document.getElementById('btn-test-lms-connection');
  const lmsTestResultBox = document.getElementById('lms-test-result-box');
  const lmsPlatformSelect = document.getElementById('lms-platform-select');
  const lmsAuthMethodSelect = document.getElementById('lms-auth-method-select');
  const lmsBaseUrlInput = document.getElementById('lms-base-url-input');
  const lmsTokenInput = document.getElementById('lms-token-input');
  const lmsUsernameInput = document.getElementById('lms-username-input');
  const lmsPasswordInput = document.getElementById('lms-password-input');
  const lmsCourseIdInput = document.getElementById('lms-course-id-input');
  const lmsQuizIdInput = document.getElementById('lms-quiz-id-input');
  const lmsBatchSizeInput = document.getElementById('lms-batch-size-input');
  const lmsCategoryInput = document.getElementById('lms-category-input');
  const groupLmsToken = document.getElementById('group-lms-token');
  const groupLmsBasicAuth = document.getElementById('group-lms-basic-auth');
  const btnToggleLmsToken = document.getElementById('btn-toggle-lms-token');
  const lmsActivePlatformBadge = document.getElementById('lms-active-platform-badge');
  const excelModalLmsBadge = document.getElementById('excel-modal-lms-badge');
  const previewLmsTargetHint = document.getElementById('preview-lms-target-hint');

  // LMS Live Progress Modal Elements
  const progressModal = document.getElementById('lms-upload-progress-modal');
  const lmsProgressTitle = document.getElementById('lms-progress-title');
  const lmsProgressBadge = document.getElementById('lms-progress-badge');
  const lmsProgressFill = document.getElementById('lms-progress-fill');
  const lmsProgressStatusText = document.getElementById('lms-progress-status-text');
  const lmsProgressPercent = document.getElementById('lms-progress-percent');
  const lmsProgressTerminal = document.getElementById('lms-progress-terminal');
  const lmsUploadSuccessCard = document.getElementById('lms-upload-success-card');
  const lmsSuccessSummaryText = document.getElementById('lms-success-summary-text');
  const lmsDirectQuizLink = document.getElementById('lms-direct-quiz-link');
  const btnCopyLmsLink = document.getElementById('btn-copy-lms-link');
  const btnCloseLmsProgress = document.getElementById('btn-close-lms-progress');

  let activeLmsConfig = {
    platform: 'Canvas',
    baseUrl: 'https://cips-lms.instructure.com',
    authMethod: 'Bearer Token',
    apiToken: '',
    username: '',
    password: '',
    targetCourseId: '42',
    targetQuizId: '101',
    targetCategory: 'Module Exam Questions',
    batchSize: 10
  };

  // Initialize LMS Configuration
  async function initLmsSettings() {
    try {
      const data = await apiConfig.getLmsConfig();
      if (data && data.config) {
        activeLmsConfig = { ...activeLmsConfig, ...data.config };
      }
    } catch (err) {
      console.warn('Using default LMS config profile:', err);
    }
    updateLmsUiBadges();
    populateLmsFormFields();
  }

  function updateLmsUiBadges() {
    const text = `${activeLmsConfig.platform || 'Canvas'} LMS Ready`;
    if (lmsActivePlatformBadge) lmsActivePlatformBadge.textContent = text;
    if (excelModalLmsBadge) excelModalLmsBadge.textContent = `${activeLmsConfig.platform || 'Canvas'} LMS`;
    if (previewLmsTargetHint) {
      previewLmsTargetHint.textContent = `Target: ${activeLmsConfig.platform} | Course ${activeLmsConfig.targetCourseId || '42'}`;
    }
  }

  function populateLmsFormFields() {
    if (lmsPlatformSelect) lmsPlatformSelect.value = activeLmsConfig.platform || 'Canvas';
    if (lmsAuthMethodSelect) lmsAuthMethodSelect.value = activeLmsConfig.authMethod || 'Bearer Token';
    if (lmsBaseUrlInput) lmsBaseUrlInput.value = activeLmsConfig.baseUrl || '';
    if (lmsTokenInput) lmsTokenInput.value = activeLmsConfig.apiToken || '';
    if (lmsUsernameInput) lmsUsernameInput.value = activeLmsConfig.username || '';
    if (lmsPasswordInput) lmsPasswordInput.value = activeLmsConfig.password || '';
    if (lmsCourseIdInput) lmsCourseIdInput.value = activeLmsConfig.targetCourseId || '42';
    if (lmsQuizIdInput) lmsQuizIdInput.value = activeLmsConfig.targetQuizId || '101';
    if (lmsBatchSizeInput) lmsBatchSizeInput.value = activeLmsConfig.batchSize || 10;
    if (lmsCategoryInput) lmsCategoryInput.value = activeLmsConfig.targetCategory || 'Module Exam Questions';

    handleAuthMethodVisibility();
  }

  function handleAuthMethodVisibility() {
    const method = lmsAuthMethodSelect ? lmsAuthMethodSelect.value : 'Bearer Token';
    if (method === 'Basic Auth') {
      if (groupLmsToken) groupLmsToken.style.display = 'none';
      if (groupLmsBasicAuth) groupLmsBasicAuth.style.display = 'grid';
    } else {
      if (groupLmsToken) groupLmsToken.style.display = 'block';
      if (groupLmsBasicAuth) groupLmsBasicAuth.style.display = 'none';
    }
  }

  if (lmsAuthMethodSelect) {
    lmsAuthMethodSelect.addEventListener('change', handleAuthMethodVisibility);
  }

  if (btnToggleLmsToken && lmsTokenInput) {
    btnToggleLmsToken.addEventListener('click', () => {
      lmsTokenInput.type = lmsTokenInput.type === 'password' ? 'text' : 'password';
      btnToggleLmsToken.textContent = lmsTokenInput.type === 'password' ? '👁️' : '🙈';
    });
  }

  // Open & Close LMS Settings Modal
  function openLmsSettingsModal() {
    populateLmsFormFields();
    if (lmsTestResultBox) lmsTestResultBox.style.display = 'none';
    if (lmsModal) lmsModal.classList.add('active');
  }

  function closeLmsSettingsModal() {
    if (lmsModal) lmsModal.classList.remove('active');
  }

  if (btnOpenLmsSettings) btnOpenLmsSettings.addEventListener('click', openLmsSettingsModal);
  if (btnExcelOpenLmsSettings) btnExcelOpenLmsSettings.addEventListener('click', openLmsSettingsModal);
  if (btnCloseLmsModalX) btnCloseLmsModalX.addEventListener('click', closeLmsSettingsModal);
  if (btnCloseLmsModal) btnCloseLmsModal.addEventListener('click', closeLmsSettingsModal);

  // Test LMS Connection
  if (btnTestLmsConnection) {
    btnTestLmsConnection.addEventListener('click', async () => {
      const cfg = harvestLmsFormData();
      if (!cfg.baseUrl) {
        alert('Please enter an LMS Base URL before testing connection.');
        return;
      }

      btnTestLmsConnection.disabled = true;
      btnTestLmsConnection.textContent = '⏳ Testing...';
      if (lmsTestResultBox) {
        lmsTestResultBox.style.display = 'block';
        lmsTestResultBox.style.background = '#f8fafc';
        lmsTestResultBox.style.color = 'var(--text-main)';
        lmsTestResultBox.style.border = '1px solid var(--border-light)';
        lmsTestResultBox.innerHTML = `<strong>Testing API connection to ${cfg.platform}...</strong><br><span style="font-size:0.75rem; color:var(--text-muted);">Contacting ${cfg.baseUrl}...</span>`;
      }

      try {
        const result = await apiConfig.testLmsConnection(cfg);
        btnTestLmsConnection.disabled = false;
        btnTestLmsConnection.textContent = '🔌 Test Connection';

        if (result.success) {
          lmsTestResultBox.style.background = '#ecfdf5';
          lmsTestResultBox.style.color = '#065f46';
          lmsTestResultBox.style.border = '1px solid #a7f3d0';
          lmsTestResultBox.innerHTML = `
            <strong>✅ Connection Established!</strong><br>
            <span>${result.message}</span>
            ${result.endpointTested ? `<br><span style="font-size:0.725rem; opacity:0.85;">Tested Route: ${result.endpointTested}</span>` : ''}
          `;
        } else {
          lmsTestResultBox.style.background = '#fffbeb';
          lmsTestResultBox.style.color = '#92400e';
          lmsTestResultBox.style.border = '1px solid #fde68a';
          lmsTestResultBox.innerHTML = `
            <strong>⚠️ Authentication Notice (Status ${result.statusCode || 'Notice'})</strong><br>
            <span>${result.message}</span>
          `;
        }
      } catch (err) {
        btnTestLmsConnection.disabled = false;
        btnTestLmsConnection.textContent = '🔌 Test Connection';
        lmsTestResultBox.style.background = '#fef2f2';
        lmsTestResultBox.style.color = '#991b1b';
        lmsTestResultBox.style.border = '1px solid #fecaca';
        lmsTestResultBox.innerHTML = `
          <strong>❌ Connection Failed</strong><br>
          <span>${err.message || 'Unable to connect to specified host.'}</span>
        `;
      }
    });
  }

  // Save LMS Settings Form
  if (lmsSettingsForm) {
    lmsSettingsForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const cfg = harvestLmsFormData();
      try {
        const res = await apiConfig.saveLmsConfig(cfg);
        activeLmsConfig = res.config || cfg;
        updateLmsUiBadges();
        alert('LMS connection settings saved successfully!');
        closeLmsSettingsModal();
      } catch (err) {
        alert('Failed to save LMS configuration: ' + err.message);
      }
    });
  }

  function harvestLmsFormData() {
    return {
      platform: lmsPlatformSelect ? lmsPlatformSelect.value : 'Canvas',
      authMethod: lmsAuthMethodSelect ? lmsAuthMethodSelect.value : 'Bearer Token',
      baseUrl: lmsBaseUrlInput ? lmsBaseUrlInput.value.trim() : '',
      apiToken: lmsTokenInput ? lmsTokenInput.value.trim() : '',
      username: lmsUsernameInput ? lmsUsernameInput.value.trim() : '',
      password: lmsPasswordInput ? lmsPasswordInput.value.trim() : '',
      targetCourseId: lmsCourseIdInput ? lmsCourseIdInput.value.trim() : '42',
      targetQuizId: lmsQuizIdInput ? lmsQuizIdInput.value.trim() : '101',
      batchSize: Number(lmsBatchSizeInput ? lmsBatchSizeInput.value : 10) || 10,
      targetCategory: lmsCategoryInput ? lmsCategoryInput.value.trim() : 'Module Exam Questions'
    };
  }

  // Tab Switcher Logic
  if (tabBtnFileUpload && tabBtnTextPaste) {
    tabBtnFileUpload.addEventListener('click', () => {
      tabBtnFileUpload.classList.add('active');
      tabBtnTextPaste.classList.remove('active');
      if (tabPaneFile) tabPaneFile.style.display = 'block';
      if (tabPanePaste) tabPanePaste.style.display = 'none';
    });

    tabBtnTextPaste.addEventListener('click', () => {
      tabBtnTextPaste.classList.add('active');
      tabBtnFileUpload.classList.remove('active');
      if (tabPanePaste) tabPanePaste.style.display = 'block';
      if (tabPaneFile) tabPaneFile.style.display = 'none';
    });
  }

  // Dropzone Interaction
  if (converterDropzone && csvFileInput) {
    ['dragenter', 'dragover'].forEach(eventName => {
      converterDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        converterDropzone.classList.add('dragover');
      }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      converterDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        converterDropzone.classList.remove('dragover');
      }, false);
    });

    converterDropzone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files && files.length > 0) {
        csvFileInput.files = files;
        showSelectedFileName(files[0].name);
        parseInputSourceAndRender();
      }
    });

    csvFileInput.addEventListener('change', () => {
      if (csvFileInput.files && csvFileInput.files[0]) {
        showSelectedFileName(csvFileInput.files[0].name);
        parseInputSourceAndRender();
      }
    });
  }

  function showSelectedFileName(name) {
    if (!dropzoneSelectedName) return;
    dropzoneSelectedName.textContent = `Selected: ${name}`;
    dropzoneSelectedName.style.display = 'inline-block';
  }

  // Download Sample CSV Template Helper
  const btnDownloadSampleTemplate = document.getElementById('btn-download-sample-template');
  if (btnDownloadSampleTemplate) {
    btnDownloadSampleTemplate.addEventListener('click', () => {
      const sampleCsv = `Question,Option A,Option B,Option C,Option D,Option E,Option F,Correct Answer,Explanation
What is the primary objective of CIPS Code of Conduct?,Ensure ethical procurement standards,Promote supplier kickbacks,Increase tariff costs,Eliminate audit trails,Favor single-source monopolies,Circumvent ESG targets,A,The CIPS code mandates integrity, fairness and transparency in global procurement.
Under the Kraljic Matrix which quadrant defines high financial risk and high supply risk?,Bottleneck Items,Non-Critical Items,Leverage Items,Strategic Items,Routine Items,Commodity Spot Items,D,Strategic items present high profit impact/financial risk coupled with high supply market complexity and risk.
Which ISO standard establishes international specifications for sustainable procurement?,ISO 9001,ISO 20400,ISO 14001,ISO 45001,ISO 27001,ISO 31000,B,ISO 20400 provides high-level guidance for organizations aiming to integrate environmental and social sustainability across procurement.`;
      downloadFile(sampleCsv, 'CIPS_Quiz_Questions_Template.csv', 'text/csv;charset=utf-8;');
    });
  }

  // Insert Sample Question Helper (Options A through F)
  if (btnInsertSampleQuiz && pasteTextarea) {
    btnInsertSampleQuiz.addEventListener('click', () => {
      pasteTextarea.value = `Question,Option A,Option B,Option C,Option D,Option E,Option F,Correct Answer,Explanation
What is the primary purpose of supplier pre-qualification in public procurement?,Establish baseline capability & compliance,Maximize tender response time,Eliminate audit documentation,Guarantee lowest initial purchase price,Bypass anti-bribery background checks,Award exclusively to incumbent contractors,A,Pre-qualification ensures suppliers possess the mandatory technical, financial, and ethical capability prior to tender evaluation.
Under the Kraljic Matrix which quadrant defines high financial risk and high supply risk?,Bottleneck Items,Non-Critical Items,Leverage Items,Strategic Items,Routine Items,Commodity Spot Items,D,Strategic items present high profit impact/financial risk coupled with high supply market complexity and risk.
Which ISO standard establishes international specifications for sustainable procurement?,ISO 9001,ISO 20400,ISO 14001,ISO 45001,ISO 27001,ISO 31000,B,ISO 20400 provides high-level guidance for organizations aiming to integrate environmental, social and economic sustainability across procurement.`;
      tabBtnTextPaste?.click();
    });
  }

  // Primary Parse & Validate Button
  if (btnParseCsv) {
    btnParseCsv.addEventListener('click', () => {
      parseInputSourceAndRender();
    });
  }

  function showConvertingIndicator(show, text) {
    const spinner = document.getElementById('converter-loading-spinner');
    const spinnerText = document.getElementById('converter-spinner-text');
    if (!spinner) return;
    if (show) {
      if (spinnerText && text) spinnerText.textContent = text;
      spinner.style.display = 'block';
    } else {
      spinner.style.display = 'none';
    }
  }

  async function parseInputSourceAndRender(openModalAfter = false) {
    const isPasteTab = tabBtnTextPaste && tabBtnTextPaste.classList.contains('active');
    
    if (isPasteTab) {
      const text = pasteTextarea ? pasteTextarea.value.trim() : '';
      if (!text) {
        alert('Please paste CSV or Aiken formatted question text in the text area.');
        return;
      }
      parsedQuestions = parseAnyQuestionFormat(text);
      convertedCsvCache = text;
      onQuestionsParsed(openModalAfter);
    } else {
      const file = csvFileInput ? csvFileInput.files[0] : null;
      if (!file) {
        alert('Please select or drop a PDF, Word (DOCX/DOC), Excel, or CSV file first, or switch to the "Paste Text" tab.');
        return;
      }

      const fileName = file.name || 'document.pdf';
      lastUploadedFileName = fileName;
      const ext = fileName.split('.').pop().toLowerCase();
      const isDocument = ['pdf', 'docx', 'doc', 'xlsx', 'xls'].includes(ext);

      showConvertingIndicator(true, `Processing & converting "${fileName}" into CSV format... Please wait`);

      try {
        if (isDocument) {
          // Send PDF, DOCX, or Excel file to backend converter
          const formData = new FormData();
          formData.append('file', file);
          const targetModule = activeModuleCode || (selectModule ? selectModule.value : 'L4M1');
          formData.append('moduleCode', targetModule);
          const forceAI = document.getElementById('chk-force-ai')?.checked;
          if (forceAI) formData.append('forceAI', 'true');

          const result = await apiConfig.convertDocumentToQuiz(formData);
          showConvertingIndicator(false);

          if (result && Array.isArray(result.questions) && result.questions.length > 0) {
            parsedQuestions = result.questions;
            convertedCsvCache = result.csvText || '';
            onQuestionsParsed(openModalAfter);
          } else {
            throw new Error(result?.error || 'No questions could be extracted from this document.');
          }
        } else {
          // Standard CSV / TXT reader
          const reader = new FileReader();
          reader.onload = (event) => {
            const text = event.target.result;
            parsedQuestions = parseAnyQuestionFormat(text);
            convertedCsvCache = text;
            showConvertingIndicator(false);
            onQuestionsParsed(openModalAfter);
          };
          reader.onerror = () => {
            showConvertingIndicator(false);
            alert('Failed to read text file.');
          };
          reader.readAsText(file);
        }
      } catch (err) {
        showConvertingIndicator(false);
        const errorMsg = err.message || 'Could not parse document';
        alert(`Document Conversion Notice: ${errorMsg}\n\nTip: You can enable "✨ AI Deep Parsing" to let Gemini process complex layouts or scanned exam PDFs.`);
      }
    }
  }

  function onQuestionsParsed(openModalAfter) {
    if (parsedQuestions.length === 0) {
      alert('Could not detect any valid questions. Please ensure the document contains numbered questions and options (e.g. A, B, C, D).');
      return;
    }

    renderCsvPreview();
    renderExcelEditor();

    if (openModalAfter && excelModal) {
      excelModal.classList.add('active');
    }
  }

  // Open Fullscreen Spreadsheet Editor
  if (btnOpenSpreadsheetModal) {
    btnOpenSpreadsheetModal.addEventListener('click', () => {
      if (parsedQuestions.length === 0) {
        // Try parsing current input or initialize with a template row
        const text = pasteTextarea ? pasteTextarea.value.trim() : '';
        const file = csvFileInput ? csvFileInput.files[0] : null;
        if (text || file) {
          parseInputSourceAndRender(true);
          return;
        }
        // Initialize with default sample row if empty
        parsedQuestions = [{
          id: 'Q_MANUAL_' + Date.now().toString(36),
          question: 'Sample CIPS Exam Question',
          options: ['Option A text', 'Option B text', 'Option C text', 'Option D text', 'Option E text', 'Option F text'],
          correctAnswer: 'A',
          explanation: 'Explanation for answer choice',
          isCR: false
        }];
      }
      renderExcelEditor();
      if (excelModal) excelModal.classList.add('active');
    });
  }

  // ==========================================
  // EXCEL / SPREADSHEET LIVE EDITOR RENDERING
  // ==========================================
  function renderExcelEditor() {
    if (!excelTbody) return;
    if (parsedQuestions.length === 0) {
      excelTbody.innerHTML = '<tr><td colspan="11" style="text-align: center; padding: 2rem; color: var(--text-muted);">No questions loaded yet. Click "+ Add Row" or parse from the main panel.</td></tr>';
      return;
    }

    excelTbody.innerHTML = parsedQuestions.map((q, idx) => {
      const opts = Array.isArray(q.options) ? q.options : [];
      const optA = opts[0] || '';
      const optB = opts[1] || '';
      const optC = opts[2] || '';
      const optD = opts[3] || '';
      const optE = opts[4] || '';
      const optF = opts[5] || '';
      const corr = (q.correctAnswer || 'A').toUpperCase();

      return `
        <tr>
          <td style="font-weight: 700; color: var(--cips-navy); text-align: center;">${idx + 1}</td>
          <td><input type="text" class="form-input excel-q-txt" value="${escapeHtml(q.question)}" style="font-size: 0.8rem; padding: 4px;" /></td>
          <td><input type="text" class="form-input excel-opt-a" value="${escapeHtml(optA)}" placeholder="Option A" style="font-size: 0.8rem; padding: 4px;" /></td>
          <td><input type="text" class="form-input excel-opt-b" value="${escapeHtml(optB)}" placeholder="Option B" style="font-size: 0.8rem; padding: 4px;" /></td>
          <td><input type="text" class="form-input excel-opt-c" value="${escapeHtml(optC)}" placeholder="Option C" style="font-size: 0.8rem; padding: 4px;" /></td>
          <td><input type="text" class="form-input excel-opt-d" value="${escapeHtml(optD)}" placeholder="Option D" style="font-size: 0.8rem; padding: 4px;" /></td>
          <td><input type="text" class="form-input excel-opt-e" value="${escapeHtml(optE)}" placeholder="Option E" style="font-size: 0.8rem; padding: 4px;" /></td>
          <td><input type="text" class="form-input excel-opt-f" value="${escapeHtml(optF)}" placeholder="Option F" style="font-size: 0.8rem; padding: 4px;" /></td>
          <td>
            <select class="form-select excel-correct-ans" style="font-size: 0.8rem; padding: 4px; font-weight: 700;">
              <option value="A" ${corr === 'A' ? 'selected' : ''}>Key A</option>
              <option value="B" ${corr === 'B' ? 'selected' : ''}>Key B</option>
              <option value="C" ${corr === 'C' ? 'selected' : ''}>Key C</option>
              <option value="D" ${corr === 'D' ? 'selected' : ''}>Key D</option>
              <option value="E" ${corr === 'E' ? 'selected' : ''}>Key E</option>
              <option value="F" ${corr === 'F' ? 'selected' : ''}>Key F</option>
            </select>
          </td>
          <td><input type="text" class="form-input excel-exp" value="${escapeHtml(q.explanation || '')}" placeholder="Rationale / feedback" style="font-size: 0.8rem; padding: 4px;" /></td>
          <td style="text-align: center;">
            <button type="button" class="btn btn-secondary btn-action-sm btn-delete-excel-row" data-idx="${idx}" style="color: var(--cips-red); padding: 2px 6px;">❌</button>
          </td>
        </tr>
      `;
    }).join('');

    document.querySelectorAll('.btn-delete-excel-row').forEach(btn => {
      btn.addEventListener('click', (e) => {
        harvestExcelModalRows();
        const idx = parseInt(e.currentTarget.getAttribute('data-idx'));
        parsedQuestions.splice(idx, 1);
        renderExcelEditor();
        renderCsvPreview();
      });
    });
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function harvestExcelModalRows() {
    if (!excelTbody) return [];
    const rows = excelTbody.querySelectorAll('tr');
    const updated = [];

    rows.forEach((row, idx) => {
      const qTxtInput = row.querySelector('.excel-q-txt');
      if (!qTxtInput) return;

      const qTxt = qTxtInput.value.trim();
      const optA = row.querySelector('.excel-opt-a')?.value.trim() || '';
      const optB = row.querySelector('.excel-opt-b')?.value.trim() || '';
      const optC = row.querySelector('.excel-opt-c')?.value.trim() || '';
      const optD = row.querySelector('.excel-opt-d')?.value.trim() || '';
      const optE = row.querySelector('.excel-opt-e')?.value.trim() || '';
      const optF = row.querySelector('.excel-opt-f')?.value.trim() || '';
      const corr = row.querySelector('.excel-correct-ans')?.value || 'A';
      const exp = row.querySelector('.excel-exp')?.value.trim() || '';

      const options = [optA, optB, optC, optD, optE, optF].filter(o => o.length > 0);
      const isCR = options.length === 0;

      if (qTxt) {
        updated.push({
          id: `Q_${idx}_` + Date.now().toString(36),
          question: qTxt,
          options: isCR ? ['Constructed Written Response Required'] : options,
          correctAnswer: isCR ? 'Constructed Response' : corr,
          explanation: exp,
          isCR
        });
      }
    });

    parsedQuestions = updated;
    return updated;
  }

  if (btnAddExcelRow) {
    btnAddExcelRow.addEventListener('click', () => {
      harvestExcelModalRows();
      parsedQuestions.push({
        id: 'Q_MANUAL_' + Date.now().toString(36),
        question: 'New CIPS Exam Question',
        options: ['Option A text', 'Option B text', 'Option C text', 'Option D text'],
        correctAnswer: 'A',
        explanation: 'Explanation for correct answer',
        isCR: false
      });
      renderExcelEditor();
      renderCsvPreview();
    });
  }

  if (btnCloseExcelModal) {
    btnCloseExcelModal.addEventListener('click', () => {
      harvestExcelModalRows();
      renderCsvPreview();
      if (excelModal) excelModal.classList.remove('active');
    });
  }

  if (btnSaveExcelImport) {
    btnSaveExcelImport.addEventListener('click', async () => {
      harvestExcelModalRows();
      await saveQuestionsToCipsBank();
    });
  }

  if (btnConfirmCsv) {
    btnConfirmCsv.addEventListener('click', async () => {
      await saveQuestionsToCipsBank();
    });
  }

  const btnDownloadConvertedCsv = document.getElementById('btn-download-converted-csv');
  if (btnDownloadConvertedCsv) {
    btnDownloadConvertedCsv.addEventListener('click', () => {
      if (convertedCsvCache) {
        const safeBaseName = (lastUploadedFileName || 'CIPS_Quiz_Questions').replace(/\.[^/.]+$/, '');
        downloadFile(convertedCsvCache, `${safeBaseName}_converted.csv`, 'text/csv;charset=utf-8;');
      } else {
        exportQuestionsToCSV();
      }
    });
  }

  const btnPreviewOpenEditor = document.getElementById('btn-preview-open-editor');
  if (btnPreviewOpenEditor) {
    btnPreviewOpenEditor.addEventListener('click', () => {
      renderExcelEditor();
      if (excelModal) excelModal.classList.add('active');
    });
  }

  async function saveQuestionsToCipsBank() {
    const targetModule = activeModuleCode || (selectModule && selectModule.value ? selectModule.value : 'L4M1');
    if (!targetModule) {
      alert('Please select a CIPS Module Code (e.g. L4M1) before saving.');
      return;
    }

    if (parsedQuestions.length === 0) {
      alert('No questions loaded to save. Please convert a PDF/DOC document or paste questions first.');
      return;
    }

    try {
      const res = await apiConfig.importQuizCSV(targetModule, parsedQuestions);
      alert(`✅ ${res.message || `Successfully saved ${parsedQuestions.length} questions into ${targetModule} quiz bank!`}\n\nThose questions are now active and will arise in the student QUIZ Test for module ${targetModule}.`);
      if (excelModal) excelModal.classList.remove('active');
      renderCsvPreview();
    } catch (err) {
      alert('Save error: ' + err.message);
    }
  }

  // ==========================================
  // PARSER ENGINE: CSV (A-F) & AIKEN FORMATS
  // ==========================================
  function parseAnyQuestionFormat(text) {
    if (!text || typeof text !== 'string') return [];
    const trimmed = text.trim();

    // 1. Try CSV Parser first
    const csvResult = parseCSVQuestions(trimmed);
    if (csvResult.length > 0) return csvResult;

    // 2. Fallback: Aiken format (e.g. "ANSWER: B")
    if (/ANSWER:\s*[A-F]/i.test(trimmed)) {
      const aikenResult = parseAikenQuestions(trimmed);
      if (aikenResult.length > 0) return aikenResult;
    }

    return [];
  }

  // RFC 4180 compliant CSV / TSV / Semicolon tokenizer that handles multiline quotes & escaped quotes
  function splitCsvRows(text) {
    const rows = [];
    let row = [];
    let field = '';
    let inQuotes = false;
    let i = 0;
    const len = text.length;

    // Auto-detect delimiter from sample
    const sample = text.substring(0, 1000);
    const tabCount = (sample.match(/\t/g) || []).length;
    const semiCount = (sample.match(/;/g) || []).length;
    const commaCount = (sample.match(/,/g) || []).length;
    let delimiter = ',';
    if (tabCount > commaCount && tabCount > semiCount) delimiter = '\t';
    else if (semiCount > commaCount && semiCount > tabCount) delimiter = ';';

    while (i < len) {
      const char = text[i];
      const next = text[i + 1];

      if (char === '"') {
        if (inQuotes && next === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = !inQuotes;
        i++;
        continue;
      }

      if (char === delimiter && !inQuotes) {
        row.push(field.trim());
        field = '';
        i++;
        continue;
      }

      if ((char === '\r' || char === '\n') && !inQuotes) {
        row.push(field.trim());
        field = '';
        if (char === '\r' && next === '\n') {
          i += 2;
        } else {
          i++;
        }
        if (row.some(c => c.length > 0)) {
          rows.push(row);
        }
        row = [];
        continue;
      }

      field += char;
      i++;
    }

    if (field.length > 0 || row.length > 0) {
      row.push(field.trim());
      if (row.some(c => c.length > 0)) {
        rows.push(row);
      }
    }

    return rows;
  }

  function parseCSVQuestions(csvText) {
    if (!csvText || typeof csvText !== 'string') return [];
    const rows = splitCsvRows(csvText);
    if (rows.length === 0) return [];

    const firstRow = rows[0];
    const firstRowStr = firstRow.join(' ').toLowerCase();
    const hasHeader = /question|prompt|item|option|answer|key/i.test(firstRowStr);

    let colQuestion = 0;
    let colOptA = 1;
    let colOptB = 2;
    let colOptC = 3;
    let colOptD = 4;
    let colOptE = -1;
    let colOptF = -1;
    let colAnswer = -1;
    let colExplanation = -1;

    let startIdx = 0;

    if (hasHeader) {
      startIdx = 1;
      firstRow.forEach((colName, idx) => {
        const h = colName.toLowerCase().trim();
        if (/question|prompt|item/i.test(h) && colQuestion === 0) colQuestion = idx;
        else if (/^(option\s*a|opt\s*a|^a$)/i.test(h)) colOptA = idx;
        else if (/^(option\s*b|opt\s*b|^b$)/i.test(h)) colOptB = idx;
        else if (/^(option\s*c|opt\s*c|^c$)/i.test(h)) colOptC = idx;
        else if (/^(option\s*d|opt\s*d|^d$)/i.test(h)) colOptD = idx;
        else if (/^(option\s*e|opt\s*e|^e$)/i.test(h)) colOptE = idx;
        else if (/^(option\s*f|opt\s*f|^f$)/i.test(h)) colOptF = idx;
        else if (/^(correct|answer|key|ans)/i.test(h)) colAnswer = idx;
        else if (/explanation|rationale|feedback|reason|why/i.test(h)) colExplanation = idx;
      });
    }

    const questions = [];

    for (let r = startIdx; r < rows.length; r++) {
      const cols = rows[r];
      if (!cols || cols.length < 2) continue;

      let questionText = '';
      let optA = '', optB = '', optC = '', optD = '', optE = '', optF = '';
      let correctAns = 'A';
      let explanation = '';

      if (hasHeader && (colAnswer !== -1 || colOptA !== -1)) {
        questionText = cols[colQuestion] || '';
        optA = colOptA !== -1 ? (cols[colOptA] || '') : '';
        optB = colOptB !== -1 ? (cols[colOptB] || '') : '';
        optC = colOptC !== -1 ? (cols[colOptC] || '') : '';
        optD = colOptD !== -1 ? (cols[colOptD] || '') : '';
        optE = colOptE !== -1 ? (cols[colOptE] || '') : '';
        optF = colOptF !== -1 ? (cols[colOptF] || '') : '';
        correctAns = colAnswer !== -1 ? (cols[colAnswer] || 'A') : 'A';
        explanation = colExplanation !== -1 ? (cols[colExplanation] || '') : '';
      } else {
        // Positional schema
        questionText = cols[0] || '';
        if (cols.length >= 8) {
          // [Question, OptA, OptB, OptC, OptD, OptE, OptF, Key, Explanation]
          optA = cols[1] || '';
          optB = cols[2] || '';
          optC = cols[3] || '';
          optD = cols[4] || '';
          optE = cols[5] || '';
          optF = cols[6] || '';
          correctAns = cols[7] || 'A';
          explanation = cols[8] || '';
        } else if (cols.length === 7) {
          // Traditional 7-column schema: [Question, OptA, OptB, OptC, OptD, Key, Explanation]
          optA = cols[1] || '';
          optB = cols[2] || '';
          optC = cols[3] || '';
          optD = cols[4] || '';
          correctAns = cols[5] || 'A';
          explanation = cols[6] || '';
        } else if (cols.length === 6) {
          // 6-column schema: [Question, OptA, OptB, OptC, OptD, Key]
          optA = cols[1] || '';
          optB = cols[2] || '';
          optC = cols[3] || '';
          optD = cols[4] || '';
          correctAns = cols[5] || 'A';
        } else {
          optA = cols[1] || '';
          optB = cols[2] || '';
          optC = cols[3] || '';
          correctAns = cols[4] || 'A';
        }
      }

      if (!questionText.trim()) continue;

      const options = [optA, optB, optC, optD, optE, optF]
        .map(o => (o ? o.trim() : ''))
        .filter(o => o.length > 0);

      // Normalize correct answer key
      let cleanKey = (correctAns || 'A').trim();
      const letterMatch = cleanKey.match(/^Option\s*([A-F])/i) || cleanKey.match(/^([A-F])[\.\:\)]/i) || cleanKey.match(/^([A-F])$/i);
      if (letterMatch) {
        cleanKey = letterMatch[1].toUpperCase();
      } else {
        // If answer was written as full option text
        const matchedIdx = options.findIndex(o => o.toLowerCase() === cleanKey.toLowerCase());
        if (matchedIdx !== -1) {
          cleanKey = 'ABCDEF'[matchedIdx];
        } else {
          cleanKey = 'A';
        }
      }

      const isCR = options.length === 0;

      questions.push({
        id: `Q_CSV_${r}_` + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
        question: questionText.trim(),
        options: isCR ? ['Constructed Written Response Required'] : options,
        correctAnswer: isCR ? 'Constructed Response' : cleanKey,
        explanation: explanation.trim(),
        isCR
      });
    }

    return questions;
  }

  function parseAikenQuestions(aikenText) {
    const questions = [];
    const blocks = aikenText.split(/\r?\n\s*\r?\n/);

    blocks.forEach((block, bIdx) => {
      const lines = block.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
      if (lines.length < 2) return;

      let questionText = '';
      const options = [];
      let correctAnswer = 'A';
      let explanation = '';

      lines.forEach(line => {
        const answerMatch = line.match(/^ANSWER:\s*([A-F])/i);
        const expMatch = line.match(/^FEEDBACK:\s*(.*)/i) || line.match(/^EXPLANATION:\s*(.*)/i);
        const optMatch = line.match(/^([A-F])[\.\)]\s*(.*)/i);

        if (answerMatch) {
          correctAnswer = answerMatch[1].toUpperCase();
        } else if (expMatch) {
          explanation = expMatch[1].trim();
        } else if (optMatch) {
          options.push(optMatch[2].trim());
        } else if (!questionText) {
          questionText = line;
        } else {
          questionText += ' ' + line;
        }
      });

      if (questionText) {
        questions.push({
          id: `Q_AIKEN_${bIdx + 1}_` + Date.now().toString(36),
          question: questionText,
          options: options.length > 0 ? options : ['Essay / Written Response'],
          correctAnswer: options.length > 0 ? correctAnswer : 'Constructed Response',
          explanation,
          isCR: options.length === 0
        });
      }
    });

    return questions;
  }

  function renderCsvPreview() {
    if (!csvPreviewContainer || !csvPreviewTbody) return;
    csvCountBadge.textContent = parsedQuestions.length;
    csvPreviewContainer.style.display = 'block';

    csvPreviewTbody.innerHTML = parsedQuestions.map((q, idx) => {
      const optCount = Array.isArray(q.options) ? q.options.length : 0;
      return `
        <tr>
          <td><strong>${idx + 1}</strong></td>
          <td style="word-break: break-word;">${escapeHtml(q.question)}</td>
          <td><span class="badge-status badge-active-locked">${q.correctAnswer}</span></td>
          <td><span style="font-size:0.75rem; color:var(--text-muted);">${optCount} opts</span></td>
        </tr>
      `;
    }).join('');
  }

  // ==========================================
  // CSV & EXCEL EXPORT HELPERS
  // ==========================================
  function downloadFile(content, fileName, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);
  }

  function exportQuestionsToCSV() {
    if (parsedQuestions.length === 0) {
      alert('No questions loaded to export. Please parse or add questions first.');
      return;
    }

    const headers = ['Question', 'Option A', 'Option B', 'Option C', 'Option D', 'Option E', 'Option F', 'Correct Answer', 'Explanation'];
    const rows = parsedQuestions.map(q => {
      const opts = Array.isArray(q.options) ? q.options : [];
      return [
        `"${(q.question || '').replace(/"/g, '""')}"`,
        `"${(opts[0] || '').replace(/"/g, '""')}"`,
        `"${(opts[1] || '').replace(/"/g, '""')}"`,
        `"${(opts[2] || '').replace(/"/g, '""')}"`,
        `"${(opts[3] || '').replace(/"/g, '""')}"`,
        `"${(opts[4] || '').replace(/"/g, '""')}"`,
        `"${(opts[5] || '').replace(/"/g, '""')}"`,
        `"${(q.correctAnswer || 'A').replace(/"/g, '""')}"`,
        `"${(q.explanation || '').replace(/"/g, '""')}"`
      ].join(',');
    });

    const csvData = [headers.join(','), ...rows].join('\r\n');
    const mod = activeModuleCode || 'CIPS';
    downloadFile(csvData, `${mod}_Quiz_Questions_Export.csv`, 'text/csv;charset=utf-8;');
  }

  function exportQuestionsToExcel() {
    if (parsedQuestions.length === 0) {
      alert('No questions loaded to export.');
      return;
    }

    // Export as tab-delimited file (.xls format recognized by Microsoft Excel)
    const headers = ['Question', 'Option A', 'Option B', 'Option C', 'Option D', 'Option E', 'Option F', 'Correct Answer', 'Explanation'];
    const rows = parsedQuestions.map(q => {
      const opts = Array.isArray(q.options) ? q.options : [];
      return [
        (q.question || '').replace(/\t/g, ' '),
        (opts[0] || '').replace(/\t/g, ' '),
        (opts[1] || '').replace(/\t/g, ' '),
        (opts[2] || '').replace(/\t/g, ' '),
        (opts[3] || '').replace(/\t/g, ' '),
        (opts[4] || '').replace(/\t/g, ' '),
        (opts[5] || '').replace(/\t/g, ' '),
        q.correctAnswer || 'A',
        (q.explanation || '').replace(/\t/g, ' ')
      ].join('\t');
    });

    const tsvData = [headers.join('\t'), ...rows].join('\r\n');
    const mod = activeModuleCode || 'CIPS';
    downloadFile(tsvData, `${mod}_Quiz_Questions_Excel.xls`, 'application/vnd.ms-excel;charset=utf-8;');
  }

  if (btnPanelExportCsv) btnPanelExportCsv.addEventListener('click', exportQuestionsToCSV);
  if (btnExcelExportCsv) btnExcelExportCsv.addEventListener('click', () => {
    harvestExcelModalRows();
    exportQuestionsToCSV();
  });

  if (btnPanelExportExcel) btnPanelExportExcel.addEventListener('click', exportQuestionsToExcel);
  if (btnExcelExportExcel) btnExcelExportExcel.addEventListener('click', () => {
    harvestExcelModalRows();
    exportQuestionsToExcel();
  });

  // ==========================================
  // LMS SYNC PIPELINE & LIVE PROGRESS FLOW
  // ==========================================
  async function triggerLmsSyncFlow() {
    if (excelModal && excelModal.classList.contains('active')) {
      harvestExcelModalRows();
    }

    if (parsedQuestions.length === 0) {
      const text = pasteTextarea ? pasteTextarea.value.trim() : '';
      const file = csvFileInput ? csvFileInput.files[0] : null;
      if (text || file) {
        parseInputSourceAndRender();
      }
    }

    if (parsedQuestions.length === 0) {
      alert('Please load or parse quiz questions first before syncing to LMS.');
      return;
    }

    const targetModule = activeModuleCode || (selectModule ? selectModule.value : '') || 'L4M1';

    // Show Progress Modal
    if (progressModal) {
      progressModal.classList.add('active');
    }

    const platform = activeLmsConfig.platform || 'Canvas';
    if (lmsProgressTitle) lmsProgressTitle.textContent = `🚀 Syncing Question Bank to ${platform}...`;
    if (lmsProgressBadge) lmsProgressBadge.textContent = `${platform} LMS`;
    if (lmsUploadSuccessCard) lmsUploadSuccessCard.style.display = 'none';
    if (btnCloseLmsProgress) btnCloseLmsProgress.style.display = 'none';

    updateProgressUi(15, 'Validating question schema and credentials...');
    clearTerminalLogs();
    appendTerminalLog(`[LMS Sync] Initialized transmission pipeline for ${targetModule}.`, 'info');
    appendTerminalLog(`[LMS Sync] Preparing ${parsedQuestions.length} questions for ${platform} question bank API...`, 'info');
    appendTerminalLog(`[Endpoint] Host: ${activeLmsConfig.baseUrl} | Course: ${activeLmsConfig.targetCourseId || '42'} | Bank: ${activeLmsConfig.targetQuizId || '101'}`, 'info');

    try {
      await sleep(350);
      updateProgressUi(35, `Mapping Question & Options A through F into ${platform} format...`);
      appendTerminalLog(`[Transform] Aligned Options A-F, Answer Keys & Explanations to ${platform} specifications.`, 'success');

      await sleep(350);
      updateProgressUi(55, 'Paginating batches to safeguard LMS rate limits...');
      appendTerminalLog(`[Rate Limit] Configured batch size: ${activeLmsConfig.batchSize || 10} questions per packet with rate limit pacing.`, 'info');

      await sleep(300);
      updateProgressUi(70, `Transmitting question batches to ${platform} API...`);

      const payload = {
        moduleCode: targetModule,
        quizTitle: `${targetModule} Exam Question Bank`,
        lmsConfig: activeLmsConfig,
        questions: parsedQuestions
      };

      const response = await apiConfig.exportToLms(payload);

      // Render backend status messages into terminal
      if (Array.isArray(response.statusMessages)) {
        response.statusMessages.forEach(msg => {
          appendTerminalLog(msg, msg.includes('✅') ? 'success' : (msg.includes('Rate') ? 'warn' : 'info'));
        });
      }

      updateProgressUi(100, `Successfully synced ${response.exportedCount || parsedQuestions.length} questions!`);
      appendTerminalLog(`[Done] ${response.message || 'LMS question bank updated successfully.'}`, 'success');

      // Populate Success Panel
      if (lmsUploadSuccessCard) {
        lmsUploadSuccessCard.style.display = 'block';
      }
      if (lmsSuccessSummaryText) {
        lmsSuccessSummaryText.textContent = `Successfully exported ${response.exportedCount || parsedQuestions.length} questions into ${platform} (Course ID: ${response.targetCourseId || activeLmsConfig.targetCourseId}, Quiz ID: ${response.targetQuizId || activeLmsConfig.targetQuizId}).`;
      }

      if (lmsDirectQuizLink) {
        const directUrl = response.directLmsUrl || activeLmsConfig.baseUrl || '#';
        lmsDirectQuizLink.href = directUrl;
        lmsDirectQuizLink.textContent = `🔗 Open Created Quiz in ${platform} ↗`;
        lmsDirectQuizLink.setAttribute('data-url', directUrl);
      }

      if (btnCloseLmsProgress) {
        btnCloseLmsProgress.style.display = 'inline-block';
      }

      // Sync with internal preview
      renderCsvPreview();
    } catch (err) {
      updateProgressUi(100, 'Sync halted due to error');
      appendTerminalLog(`[Error] LMS Export failed: ${err.message}`, 'warn');
      if (btnCloseLmsProgress) {
        btnCloseLmsProgress.style.display = 'inline-block';
      }
    }
  }

  function updateProgressUi(percent, statusText) {
    if (lmsProgressFill) lmsProgressFill.style.width = `${percent}%`;
    if (lmsProgressPercent) lmsProgressPercent.textContent = `${percent}%`;
    if (lmsProgressStatusText) lmsProgressStatusText.textContent = statusText;
  }

  function clearTerminalLogs() {
    if (lmsProgressTerminal) {
      lmsProgressTerminal.innerHTML = '';
    }
  }

  function appendTerminalLog(text, level = 'info') {
    if (!lmsProgressTerminal) return;
    const time = new Date().toLocaleTimeString();
    const line = document.createElement('div');
    line.className = `lms-terminal-line ${level}`;
    line.textContent = `[${time}] ${text}`;
    lmsProgressTerminal.appendChild(line);
    lmsProgressTerminal.scrollTop = lmsProgressTerminal.scrollHeight;
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Copy Direct LMS URL Button
  if (btnCopyLmsLink && lmsDirectQuizLink) {
    btnCopyLmsLink.addEventListener('click', () => {
      const url = lmsDirectQuizLink.href;
      if (url && url !== '#') {
        navigator.clipboard.writeText(url).then(() => {
          btnCopyLmsLink.textContent = '✅ Copied to Clipboard!';
          setTimeout(() => {
            btnCopyLmsLink.textContent = '📋 Copy Direct Quiz Link';
          }, 2500);
        });
      }
    });
  }

  if (btnCloseLmsProgress && progressModal) {
    btnCloseLmsProgress.addEventListener('click', () => {
      progressModal.classList.remove('active');
    });
  }

  // Wire Sync triggers
  if (btnQuickSyncLms) btnQuickSyncLms.addEventListener('click', triggerLmsSyncFlow);
  if (btnPreviewSyncLms) btnPreviewSyncLms.addEventListener('click', triggerLmsSyncFlow);
  if (btnExcelSyncLms) btnExcelSyncLms.addEventListener('click', triggerLmsSyncFlow);

  // Initialize LMS settings on page load
  initLmsSettings();

  function parseCSVQuestions(csvText) {
    const lines = csvText.split(/\r?\n/).filter(line => line.trim() !== '');
    if (lines.length <= 1) return [];

    const questions = [];
    // Skip header line (line 0)
    for (let i = 1; i < lines.length; i++) {
      const cols = parseCsvLine(lines[i]);
      if (cols.length < 2) continue;

      const questionText = cols[0] ? cols[0].trim() : '';
      const optA = cols[1] ? cols[1].trim() : '';
      const optB = cols[2] ? cols[2].trim() : '';
      const optC = cols[3] ? cols[3].trim() : '';
      const optD = cols[4] ? cols[4].trim() : '';
      const correctAns = cols[5] ? cols[5].trim() : 'A';
      const explanation = cols[6] ? cols[6].trim() : '';

      const options = [optA, optB, optC, optD].filter(o => o.length > 0);
      const isCR = options.length === 0;

      if (questionText) {
        questions.push({
          id: `Q_${i}_` + Math.random().toString(36).substring(2, 7),
          question: questionText,
          options: isCR ? ['Constructed Written Response Required'] : options,
          correctAnswer: isCR ? 'Constructed Response' : correctAns,
          explanation: explanation,
          isCR: isCR
        });
      }
    }
    return questions;
  }

  function parseCsvLine(line) {
    const result = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(cur);
        cur = '';
      } else {
        cur += char;
      }
    }
    result.push(cur);
    return result;
  }

  function renderCsvPreview() {
    if (!csvPreviewContainer || !csvPreviewTbody) return;
    csvCountBadge.textContent = parsedQuestions.length;
    csvPreviewContainer.style.display = 'block';

    csvPreviewTbody.innerHTML = parsedQuestions.map((q, idx) => `
      <tr>
        <td><strong>${idx + 1}</strong></td>
        <td>${q.question}</td>
        <td><span class="badge-status badge-active-locked">${q.correctAnswer}</span></td>
      </tr>
    `).join('');
  }

  function populateModuleDropdown(modulesData) {
    if (!selectModule) return;
    selectModule.innerHTML = '<option value="">-- Select CIPS Module Code --</option>';

    for (let lvl = 2; lvl <= 6; lvl++) {
      const levelKey = `level${lvl}`;
      const levelObj = modulesData[levelKey];
      if (levelObj && levelObj.modules) {
        const group = document.createElement('optgroup');
        group.label = levelObj.title || `Level ${lvl}`;
        levelObj.modules.forEach(m => {
          const opt = document.createElement('option');
          opt.value = m.code;
          opt.textContent = `${m.code} - ${m.name}`;
          group.appendChild(opt);
        });
        selectModule.appendChild(group);
      }
    }
  }

  async function loadModuleContent(moduleCode) {
    try {
      const data = await apiConfig.getModuleContent(moduleCode, 'admin@cips.edu');
      activeModuleContent = {
        books: data.books || [],
        recordings: data.recordings || [],
        previousExams: data.previousExams || [],
        notes: data.notes || []
      };
      renderBooks();
      renderRecordings();
      renderExams();
      renderNotes();
    } catch (e) {
      console.warn('Loading default content structure:', e);
    }
  }

  function renderBooks() {
    if (!booksContainer) return;
    booksContainer.innerHTML = activeModuleContent.books.map((b, idx) => `
      <div style="background: var(--bg-main); border: 1px solid var(--border-light); padding: 0.75rem; border-radius: var(--radius-sm); margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
        <div style="flex: 1;">
          <input type="text" class="form-input" value="${b.title}" onchange="updateMaterial('books', ${idx}, 'title', this.value)" style="margin-bottom: 0.35rem; font-weight: 700;" />
          <input type="text" class="form-input" value="${b.embedUrl}" onchange="updateMaterial('books', ${idx}, 'embedUrl', this.value)" style="font-size: 0.8rem;" />
        </div>
        <button class="btn btn-secondary btn-action-sm" onclick="removeMaterial('books', ${idx})" style="margin-left: 0.5rem; color: var(--cips-red);">❌</button>
      </div>
    `).join('');
  }

  function renderRecordings() {
    if (!recordingsContainer) return;
    recordingsContainer.innerHTML = activeModuleContent.recordings.map((r, idx) => `
      <div style="background: var(--bg-main); border: 1px solid var(--border-light); padding: 0.75rem; border-radius: var(--radius-sm); margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
        <div style="flex: 1;">
          <input type="text" class="form-input" value="${r.title}" onchange="updateMaterial('recordings', ${idx}, 'title', this.value)" style="margin-bottom: 0.35rem; font-weight: 700;" />
          <input type="text" class="form-input" value="${r.videoUrl || r.embedUrl}" onchange="updateMaterial('recordings', ${idx}, 'videoUrl', this.value)" style="font-size: 0.8rem;" />
        </div>
        <button class="btn btn-secondary btn-action-sm" onclick="removeMaterial('recordings', ${idx})" style="margin-left: 0.5rem; color: var(--cips-red);">❌</button>
      </div>
    `).join('');
  }

  function renderExams() {
    if (!examsContainer) return;
    examsContainer.innerHTML = activeModuleContent.previousExams.map((e, idx) => `
      <div style="background: var(--bg-main); border: 1px solid var(--border-light); padding: 0.75rem; border-radius: var(--radius-sm); margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
        <div style="flex: 1;">
          <input type="text" class="form-input" value="${e.title}" onchange="updateMaterial('previousExams', ${idx}, 'title', this.value)" style="margin-bottom: 0.35rem; font-weight: 700;" />
          <input type="text" class="form-input" value="${e.embedUrl}" onchange="updateMaterial('previousExams', ${idx}, 'embedUrl', this.value)" style="font-size: 0.8rem;" />
        </div>
        <button class="btn btn-secondary btn-action-sm" onclick="removeMaterial('previousExams', ${idx})" style="margin-left: 0.5rem; color: var(--cips-red);">❌</button>
      </div>
    `).join('');
  }

  function renderNotes() {
    if (!notesContainer) return;
    notesContainer.innerHTML = activeModuleContent.notes.map((n, idx) => `
      <div style="background: var(--bg-main); border: 1px solid var(--border-light); padding: 0.75rem; border-radius: var(--radius-sm); margin-bottom: 0.5rem;">
        <input type="text" class="form-input" value="${n.title}" onchange="updateMaterial('notes', ${idx}, 'title', this.value)" style="margin-bottom: 0.35rem; font-weight: 700;" />
        <textarea class="form-textarea" rows="2" onchange="updateMaterial('notes', ${idx}, 'content', this.value)">${n.content}</textarea>
        <button class="btn btn-secondary btn-action-sm" onclick="removeMaterial('notes', ${idx})" style="margin-top: 0.35rem; color: var(--cips-red);">❌ Remove Note</button>
      </div>
    `).join('');
  }

  window.updateMaterial = (type, idx, key, val) => {
    if (activeModuleContent[type] && activeModuleContent[type][idx]) {
      activeModuleContent[type][idx][key] = val;
    }
  };

  window.removeMaterial = (type, idx) => {
    if (activeModuleContent[type]) {
      activeModuleContent[type].splice(idx, 1);
      if (type === 'books') renderBooks();
      else if (type === 'recordings') renderRecordings();
      else if (type === 'previousExams') renderExams();
      else if (type === 'notes') renderNotes();
    }
  };
});
