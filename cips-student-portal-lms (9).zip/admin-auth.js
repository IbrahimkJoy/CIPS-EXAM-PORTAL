import { apiConfig } from './api-config.js';

document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('admin-login-form');
  const alertBox = document.getElementById('admin-login-alert');
  const alertText = document.getElementById('admin-login-alert-text');
  const btnSubmit = document.getElementById('btn-submit-admin-login');

  const modal = document.getElementById('change-password-modal');
  const changePwdForm = document.getElementById('change-password-form');
  const changeAlertBox = document.getElementById('change-pwd-alert');
  const changeAlertText = document.getElementById('change-pwd-alert-text');
  const currentPwdInput = document.getElementById('currentPassword');
  const newPwdInput = document.getElementById('newPassword');
  const confirmPwdInput = document.getElementById('confirmPassword');

  const adminUserInput = document.getElementById('adminUsername');
  const adminPassInput = document.getElementById('adminPassword');
  const btnToggleAdminPass = document.getElementById('btn-toggle-admin-pass');
  const deviceInfoLabel = document.getElementById('device-info-label');

  let activeLoginData = null;

  // Display device fingerprint details
  if (deviceInfoLabel) {
    const fp = apiConfig.getDeviceFingerprint();
    deviceInfoLabel.textContent = `🔒 Active Device: ${fp.browser} on ${fp.os} (ID: ${fp.deviceToken.substring(0, 8)}...) • CIPS LMS v4.2`;
  }

  // Floating label sync for input boxes
  document.querySelectorAll('.auth-panel-wrapper .input-box input').forEach(input => {
    const updateHasValue = () => {
      if (input.value && input.value.length > 0) {
        input.parentElement.classList.add('has-value');
      } else {
        input.parentElement.classList.remove('has-value');
      }
    };
    input.addEventListener('input', updateHasValue);
    input.addEventListener('change', updateHasValue);
    updateHasValue();
  });

  // Password visibility toggle
  if (btnToggleAdminPass && adminPassInput) {
    btnToggleAdminPass.addEventListener('click', () => {
      const isPass = adminPassInput.type === 'password';
      adminPassInput.type = isPass ? 'text' : 'password';
      btnToggleAdminPass.style.opacity = isPass ? '1' : '0.65';
    });
  }

  // Global Admin Demo Fill Handler
  window.fillAdminDemo = (username, password) => {
    if (adminUserInput && adminPassInput) {
      adminUserInput.value = username;
      adminPassInput.value = password;
      adminUserInput.dispatchEvent(new Event('input', { bubbles: true }));
      adminPassInput.dispatchEvent(new Event('input', { bubbles: true }));
      adminUserInput.dispatchEvent(new Event('change', { bubbles: true }));
      adminPassInput.dispatchEvent(new Event('change', { bubbles: true }));
      hideAlert();
    }
  };

  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      hideAlert();

      const username = adminUserInput ? adminUserInput.value.trim() : '';
      const password = adminPassInput ? adminPassInput.value.trim() : '';

      if (!username || !password) {
        showAlert('Please enter both admin username and password.');
        return;
      }

      try {
        if (btnSubmit) {
          btnSubmit.disabled = true;
          btnSubmit.textContent = 'Authenticating...';
        }

        const data = await apiConfig.adminLogin(username, password);

        activeLoginData = {
          username,
          password,
          isFirstLogin: data.isFirstLogin
        };

        if (data.isFirstLogin) {
          // Force first-login password change modal
          if (currentPwdInput) currentPwdInput.value = password;
          if (modal) modal.classList.add('active');
        } else {
          // Proceed to Student Management page
          window.location.href = 'student-management.html';
        }
      } catch (err) {
        showAlert(err.message || 'Invalid admin credentials');
      } finally {
        if (btnSubmit) {
          btnSubmit.disabled = false;
          btnSubmit.textContent = 'Login for Admin';
        }
      }
    });
  }

  if (changePwdForm) {
    changePwdForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (changeAlertBox) changeAlertBox.style.display = 'none';

      const currentPassword = currentPwdInput ? currentPwdInput.value.trim() : '';
      const newPassword = newPwdInput ? newPwdInput.value.trim() : '';
      const confirmPassword = confirmPwdInput ? confirmPwdInput.value.trim() : '';

      if (newPassword.length < 8) {
        showChangeAlert('New password must be at least 8 characters long.');
        return;
      }

      if (newPassword !== confirmPassword) {
        showChangeAlert('New passwords do not match.');
        return;
      }

      try {
        const username = activeLoginData ? activeLoginData.username : 'admincipsadmin';
        await apiConfig.changeAdminPassword(username, currentPassword, newPassword);

        alert('Password updated successfully! Redirecting to Administrator Dashboard...');
        window.location.href = 'student-management.html';
      } catch (err) {
        showChangeAlert(err.message || 'Failed to update password');
      }
    });
  }

  function showAlert(msg) {
    if (alertText && alertBox) {
      alertText.textContent = msg;
      alertBox.style.display = 'flex';
    }
  }

  function hideAlert() {
    if (alertBox) {
      alertBox.style.display = 'none';
    }
  }

  function showChangeAlert(msg) {
    if (changeAlertText && changeAlertBox) {
      changeAlertText.textContent = msg;
      changeAlertBox.style.display = 'block';
    }
  }
});
