import { apiConfig } from './api-config.js';

export async function loadSecurityAlertsFeed(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  try {
    const data = await apiConfig.getAdminAlerts();
    const alerts = data.securityAlerts || [];
    const deviceEvents = (data.deviceEvents || []).filter(e => e.status === 'BLOCKED');

    const combined = [
      ...alerts.map(a => ({
        id: a.id,
        email: a.studentEmail,
        moduleCode: a.moduleCode,
        type: a.type || 'DEVTOOLS_DETECTION',
        details: a.details || 'DevTools or Screenshot Key Attempt Detected',
        timestamp: a.timestamp
      })),
      ...deviceEvents.map(d => ({
        id: d.id,
        email: d.studentEmail,
        moduleCode: 'LOGIN',
        type: 'UNAUTHORIZED_DEVICE_LOCK',
        details: `Active device conflict: ${d.attemptedDeviceInfo}`,
        timestamp: d.timestamp
      }))
    ];

    combined.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    if (combined.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; color: var(--text-muted); padding: 2rem; background: #ffffff; border-radius: var(--radius-sm); border: 1px dashed var(--border-light);">
          🛡️ No security alerts logged. All proctored sessions are normal.
        </div>
      `;
      return;
    }

    container.innerHTML = combined.map(item => `
      <div class="alert-feed-card">
        <div>
          <div>
            <span class="alert-type-badge">${item.type}</span>
            <span class="alert-info-title">${item.email}</span>
            <span style="font-size: 0.8rem; font-weight: 700; color: var(--cips-accent); margin-left: 0.5rem;">[${item.moduleCode}]</span>
          </div>
          <div class="alert-meta">
            ${item.details} &bull; <strong>${new Date(item.timestamp).toLocaleString()}</strong>
          </div>
        </div>
        <div>
          <button class="btn btn-danger btn-action-sm btn-revoke-session" data-email="${item.email}">
            ⛔ Revoke Access
          </button>
        </div>
      </div>
    `).join('');

    // Attach click listeners to Revoke Access buttons
    document.querySelectorAll('.btn-revoke-session').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const email = e.currentTarget.getAttribute('data-email');
        if (confirm(`Revoke active session device token for ${email}? This forces immediate re-authentication.`)) {
          try {
            await apiConfig.revokeStudentAccess(email);
            alert(`Active session for ${email} revoked.`);
            loadSecurityAlertsFeed(containerId);
          } catch (err) {
            alert('Failed to revoke access: ' + err.message);
          }
        }
      });
    });
  } catch (err) {
    container.innerHTML = `<p style="color: var(--cips-red);">Error loading alerts feed: ${err.message}</p>`;
  }
}
