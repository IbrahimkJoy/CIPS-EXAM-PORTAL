/**
 * Google Apps Script Sheets Database Client
 * 
 * Provides a robust CRUD interface to interact with a deployed Google Apps Script
 * Web App endpoint acting as a cloud spreadsheet database for the CIPS LMS Portal.
 */

export interface GoogleSheetsRequest<T = any> {
  action: 'CREATE' | 'READ' | 'UPDATE' | 'DELETE' | 'PING' | 'BULK_SYNC' | 'BULK_MIGRATE' | 'STUDENT_CREATE' | 'STUDENT_UPDATE' | 'STUDENT_UPSERT' | 'STUDENT_DELETE' | 'ACCESS_UPDATE' | 'NEW_STUDENT_REGISTRATION' | 'QUIZ_RESULT' | 'LOGIN' | 'SECURITY_ALERT';
  table?: 'Student Records' | 'Access Control' | 'New Student Registration' | 'Exam Results' | 'Login & Security Audit' | 'Students' | 'ExamResults' | 'Inquiries' | string;
  data?: T;
  keyField?: string;
  keyValue?: string | number;
  query?: Record<string, any>;
  source?: string;
}

export interface GoogleSheetsResponse<T = any> {
  status: 'success' | 'error';
  message?: string;
  action?: string;
  table?: string;
  data?: T;
  count?: number;
  timestamp?: string;
  spreadsheetName?: string;
  tables?: string[];
}

export interface StudentRecord {
  studentId: string;
  name: string;
  email: string;
  approvedLevels?: string[] | string;
  approvedModules?: string[] | string;
  accessStatus?: 'ENABLED' | 'REVOKED';
  quizAccessLocked?: boolean;
  lastLogin?: string;
  createdAt?: string;
}

export interface ExamResultRecord {
  id?: string;
  receiptId?: string;
  submittedAt?: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  moduleCode: string;
  moduleTitle?: string;
  examType?: string;
  score: number;
  totalQuestions: number;
  passed: boolean;
  durationSeconds?: number;
  autoSubmitted?: boolean;
}

export interface InquiryRecord {
  name: string;
  email: string;
  phone?: string;
  countryCode?: string;
  level?: string;
  notes?: string;
  submittedAt?: string;
  status?: string;
}

/**
 * Resolves the Google Apps Script Webhook URL from available environment sources
 */
export function getWebhookUrl(explicitUrl?: string): string {
  if (explicitUrl && explicitUrl.trim()) {
    return explicitUrl.trim();
  }

  // Check Node environment
  if (typeof process !== 'undefined' && process.env) {
    if (process.env.GOOGLE_SHEET_WEBHOOK_URL) {
      return process.env.GOOGLE_SHEET_WEBHOOK_URL;
    }
  }

  // Check Vite client environment
  try {
    // @ts-ignore
    if (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GOOGLE_SHEET_WEBHOOK_URL) {
      // @ts-ignore
      return import.meta.env.VITE_GOOGLE_SHEET_WEBHOOK_URL;
    }
  } catch (e) {
    // ignore
  }

  return '';
}

/**
 * Core fetch function to interact with Google Apps Script Web App
 * Handles CORS, redirects, JSON serialization, and error trapping
 */
export async function executeSheetsApi<T = any>(
  request: GoogleSheetsRequest,
  customEndpoint?: string
): Promise<GoogleSheetsResponse<T>> {
  const endpoint = getWebhookUrl(customEndpoint);

  if (!endpoint) {
    throw new Error(
      'Google Apps Script Webhook URL is not configured. Please provide an endpoint or set GOOGLE_SHEET_WEBHOOK_URL.'
    );
  }

  try {
    const payload = {
      ...request,
      timestamp: new Date().toISOString(),
      source: request.source || 'CIPS Student Portal LMS'
    };

    // Google Apps Script requires standard POST with text/plain or application/json, following 302 redirects
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8' // avoids preflight CORS restrictions in Google Apps Script
      },
      body: JSON.stringify(payload),
      redirect: 'follow'
    });

    const responseText = await response.text();
    let result: GoogleSheetsResponse<T>;

    try {
      result = JSON.parse(responseText);
    } catch {
      result = {
        status: response.ok ? 'success' : 'error',
        message: responseText.substring(0, 500)
      };
    }

    if (result.status === 'error') {
      throw new Error(result.message || 'Google Sheets API returned an error status');
    }

    return result;
  } catch (error: any) {
    console.error(`[Google Sheets API Error] [${request.action}] [${request.table}]:`, error.message);
    throw error;
  }
}

// -------------------------------------------------------------
// CONVENIENCE CRUD OPERATIONS
// -------------------------------------------------------------

/**
 * Test connectivity to the Google Apps Script Web App endpoint
 */
export async function testConnection(endpoint?: string): Promise<GoogleSheetsResponse> {
  return executeSheetsApi({ action: 'PING', table: 'System' }, endpoint);
}

/**
 * CREATE: Insert a new record into a table
 */
export async function createRecord<T = any>(
  table: GoogleSheetsRequest['table'],
  data: T,
  endpoint?: string
): Promise<GoogleSheetsResponse<T>> {
  return executeSheetsApi<T>({ action: 'CREATE', table, data }, endpoint);
}

/**
 * READ: Fetch records from a table with optional filter query
 */
export async function readRecords<T = any>(
  table: GoogleSheetsRequest['table'],
  query?: Record<string, any>,
  endpoint?: string
): Promise<GoogleSheetsResponse<T[]>> {
  return executeSheetsApi<T[]>({ action: 'READ', table, query }, endpoint);
}

/**
 * UPDATE: Update an existing record matched by a key field
 */
export async function updateRecord<T = any>(
  table: GoogleSheetsRequest['table'],
  keyField: string,
  keyValue: string | number,
  data: Partial<T>,
  endpoint?: string
): Promise<GoogleSheetsResponse<T>> {
  return executeSheetsApi<T>({ action: 'UPDATE', table, keyField, keyValue, data }, endpoint);
}

/**
 * DELETE: Remove a record matched by a key field
 */
export async function deleteRecord(
  table: GoogleSheetsRequest['table'],
  keyField: string,
  keyValue: string | number,
  endpoint?: string
): Promise<GoogleSheetsResponse> {
  return executeSheetsApi({ action: 'DELETE', table, keyField, keyValue }, endpoint);
}

/**
 * BULK SYNC: Export full database snapshot in a single batch
 */
export async function bulkSyncData(
  allData: {
    students?: StudentRecord[];
    examResults?: ExamResultRecord[];
    inquiries?: InquiryRecord[];
    logins?: any[];
    securityAlerts?: any[];
  },
  endpoint?: string
): Promise<GoogleSheetsResponse> {
  return executeSheetsApi({ action: 'BULK_SYNC', table: 'All', data: allData }, endpoint);
}

// -------------------------------------------------------------
// DOMAIN-SPECIFIC LMS HELPERS
// -------------------------------------------------------------

export const googleSheetsLMS = {
  // Students
  createStudent: (student: StudentRecord, endpoint?: string) =>
    executeSheetsApi({ action: 'STUDENT_CREATE', table: 'Student Records', data: student }, endpoint),
  
  getStudents: (endpoint?: string) =>
    readRecords<StudentRecord>('Student Records', {}, endpoint),
  
  updateStudent: (email: string, updateData: Partial<StudentRecord>, endpoint?: string) =>
    executeSheetsApi({ action: 'STUDENT_UPDATE', table: 'Student Records', keyField: 'Email Address', keyValue: email, data: { ...updateData, email } }, endpoint),

  // Access Control
  updateAccessControl: (email: string, accessStatus: string, quizAccessStatus?: string, endpoint?: string) =>
    executeSheetsApi({ action: 'ACCESS_UPDATE', table: 'Access Control', data: { email, accessStatus, quizAccessStatus } }, endpoint),

  // New Student Registration
  saveNewStudentRegistration: (registration: InquiryRecord, endpoint?: string) =>
    executeSheetsApi({ action: 'NEW_STUDENT_REGISTRATION', table: 'New Student Registration', data: registration }, endpoint),

  // Exam Results
  recordExamResult: (result: ExamResultRecord, endpoint?: string) =>
    executeSheetsApi({ action: 'QUIZ_RESULT', table: 'Exam Results', data: result }, endpoint),
  
  getExamResults: (studentEmail?: string, endpoint?: string) =>
    readRecords<ExamResultRecord>('Exam Results', studentEmail ? { 'Candidate Email': studentEmail } : {}, endpoint),

  // Legacy mappings for backwards compatibility
  saveInquiry: (inquiry: InquiryRecord, endpoint?: string) =>
    executeSheetsApi({ action: 'NEW_STUDENT_REGISTRATION', table: 'New Student Registration', data: inquiry }, endpoint),

  getInquiries: (endpoint?: string) =>
    readRecords<InquiryRecord>('New Student Registration', {}, endpoint)
};

export default {
  executeSheetsApi,
  testConnection,
  createRecord,
  readRecords,
  updateRecord,
  deleteRecord,
  bulkSyncData,
  googleSheetsLMS
};
