// student-kpi-details.js
// Handles interactive filtering, timestamp formatting, timeline audits, and CSV exports
import { apiConfig } from './api-config.js';

document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const tabButtons = document.querySelectorAll('.kpi-tab-btn');
  const bannerIcon = document.getElementById('banner-icon');
  const bannerTitle = document.getElementById('banner-title');
  const bannerDesc = document.getElementById('banner-desc');
  const tableBody = document.getElementById('kpi-table-body');
  const searchInput = document.getElementById('kpi-search-input');
  const sortSelect = document.getElementById('kpi-sort-select');
  const btnRefresh = document.getElementById('btn-refresh-kpi');
  const btnExportCsv = document.getElementById('btn-export-kpi-csv');

  // Timeline Modal Elements
  const timelineModal = document.getElementById('student-timeline-modal');
  const btnCloseTimeline = document.getElementById('btn-close-timeline-modal');
  const btnCloseTimelineBottom = document.getElementById('btn-close-timeline-modal-bottom');
  const tlModalAvatar = document.getElementById('tl-modal-avatar');
  const tlModalName = document.getElementById('tl-modal-name');
  const tlModalEmail = document.getElementById('tl-modal-email');
  const tlEventsContainer = document.getElementById('tl-events-container');

  // Confirmation Modal Elements
  const confirmModal = document.getElementById('confirm-action-modal');
  const btnCloseConfirmModal = document.getElementById('btn-close-confirm-modal');
  const btnCancelAction = document.getElementById('btn-cancel-action');
  const btnExecuteAction = document.getElementById('btn-execute-action');
  const confirmModalTitle = document.getElementById('confirm-modal-title');
  const confirmModalDesc = document.getElementById('confirm-modal-desc');
  const confirmModalIcon = document.getElementById('confirm-modal-icon');
  const confirmStudentAvatar = document.getElementById('confirm-student-avatar');
  const confirmStudentName = document.getElementById('confirm-student-name');
  const confirmStudentEmail = document.getElementById('confirm-student-email');
  const confirmStudentId = document.getElementById('confirm-student-id');
  const confirmWarningCallout = document.getElementById('confirm-warning-callout');
  const confirmWarningText = document.getElementById('confirm-warning-text');

  // Toast feedback
  const toastEl = document.getElementById('admin-toast-feedback');
  const toastMsg = document.getElementById('admin-toast-msg');
  const toastIcon = document.getElementById('admin-toast-icon');

  // State
  let allStudents = [];
  let allQuizResults = [];
  let currentFilter = 'enrolled';
  let pendingActionCallback = null;

  // Filter definitions
  const filterMeta = {
    'enrolled': {
      icon: '👥',
      title: 'Total Enrolled Students',
      desc: 'Complete registry of all registered students, creation timestamps, and authentication audit logs.'
    },
    'device-lock': {
      icon: '🔒',
      title: 'Device Lock Protection',
      desc: 'Hardware device-bound student profiles, hardware tokens, and device authorization timestamps.'
    },
    'portal-active': {
      icon: '🟢',
      title: 'Portal Access Active',
      desc: 'Students with active portal authentication permissions, login counts, and latest session activity times.'
    },
    'quiz-access': {
      icon: '🎯',
      title: 'Quiz Engine Access',
      desc: 'Students authorized for examination and mock test attempts, with score histories and submission timestamps.'
    }
  };

  // 1. Parse filter from URL Query Parameters
  function initFilterFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const filterParam = params.get('filter');
    if (filterParam && filterMeta[filterParam]) {
      currentFilter = filterParam;
    } else {
      currentFilter = 'enrolled';
    }
    updateTabStyles();
  }

  function updateTabStyles() {
    tabButtons.forEach(btn => {
      const f = btn.getAttribute('data-filter');
      if (f === currentFilter) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    const meta = filterMeta[currentFilter] || filterMeta['enrolled'];
    if (bannerIcon) bannerIcon.textContent = meta.icon;
    if (bannerTitle) bannerTitle.textContent = meta.title;
    if (bannerDesc) bannerDesc.textContent = meta.desc;
  }

  // Toast Helper
  function showToast(message, type = 'success') {
    if (!toastEl) return;
    toastMsg.textContent = message;
    toastEl.className = `admin-toast-notification toast-${type} show`;
    if (type === 'success') toastIcon.textContent = '✓';
    else if (type === 'danger') toastIcon.textContent = '✕';
    else if (type === 'warning') toastIcon.textContent = '⚠️';
    else toastIcon.textContent = 'ℹ️';

    setTimeout(() => {
      toastEl.classList.remove('show');
    }, 4000);
  }

  // Format Helpers
  function formatExactTime(isoString) {
    if (!isoString) return 'Not recorded';
    try {
      const d = new Date(isoString);
      if (isNaN(d.getTime())) return isoString;
      return d.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
      });
    } catch {
      return isoString;
    }
  }

  function formatRelativeTime(isoString) {
    if (!isoString) return '';
    try {
      const d = new Date(isoString);
      const now = new Date();
      const diffMs = now.getTime() - d.getTime();
      const diffSecs = Math.floor(diffMs / 1000);
      const diffMins = Math.floor(diffSecs / 60);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffSecs < 60) return 'Just now';
      if (diffMins < 60) return `${diffMins} min${diffMins > 1 ? 's' : ''} ago`;
      if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
      if (diffDays === 1) return 'Yesterday';
      if (diffDays < 30) return `${diffDays} days ago`;
      return `${Math.floor(diffDays / 30)} month(s) ago`;
    } catch {
      return '';
    }
  }

  function getInitials(name, fallback) {
    if (!name && !fallback) return 'ST';
    const source = (name || fallback || '').trim();
    const parts = source.split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return source.substring(0, 2).toUpperCase();
  }

  // Data Loading
  async function loadData() {
    try {
      tableBody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 2rem; color: var(--text-muted);">
            🔄 Loading verified student records &amp; timestamps...
          </td>
        </tr>
      `;

      // Fetch students
      allStudents = await apiConfig.getAllStudents();

      // Fetch quiz results for enriched timestamp history
      try {
        const res = await fetch('/api/admin/quiz-results');
        if (res.ok) {
          const quizData = await res.json();
          allQuizResults = Array.isArray(quizData) ? quizData : (quizData.results || []);
        }
      } catch (e) {
        console.warn('Quiz results endpoint notice:', e);
      }

      updateTabCounts();
      renderTable();
    } catch (err) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 2rem; color: #ef4444;">
            Failed to load student data: ${err.message || 'Server error'}
          </td>
        </tr>
      `;
    }
  }

  function updateTabCounts() {
    const enrolledCount = allStudents.length;
    const deviceLockedCount = allStudents.filter(s => s.activeDeviceToken || s.isDeviceBlocked).length;
    const portalActiveCount = allStudents.filter(s => s.accessStatus !== 'DENIED').length;
    const quizAccessCount = allStudents.filter(s => s.quizAccessStatus !== 'DENIED').length;

    const elEnrolled = document.getElementById('tab-count-enrolled');
    const elDevice = document.getElementById('tab-count-device-lock');
    const elPortal = document.getElementById('tab-count-portal-active');
    const elQuiz = document.getElementById('tab-count-quiz-access');

    if (elEnrolled) elEnrolled.textContent = enrolledCount;
    if (elDevice) elDevice.textContent = deviceLockedCount;
    if (elPortal) elPortal.textContent = portalActiveCount;
    if (elQuiz) elQuiz.textContent = quizAccessCount;
  }

  function getFilteredStudents() {
    let list = [...allStudents];

    // Filter by active section
    if (currentFilter === 'device-lock') {
      list = list.filter(s => s.activeDeviceToken || s.isDeviceBlocked);
    } else if (currentFilter === 'portal-active') {
      list = list.filter(s => s.accessStatus !== 'DENIED');
    } else if (currentFilter === 'quiz-access') {
      list = list.filter(s => s.quizAccessStatus !== 'DENIED');
    }
    // 'enrolled' returns all

    // Filter by search query
    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    if (query) {
      list = list.filter(s => 
        (s.name && s.name.toLowerCase().includes(query)) ||
        (s.email && s.email.toLowerCase().includes(query)) ||
        (s.studentId && s.studentId.toLowerCase().includes(query)) ||
        (s.activeDeviceToken && s.activeDeviceToken.toLowerCase().includes(query)) ||
        (s.activeDeviceInfo && s.activeDeviceInfo.toLowerCase().includes(query))
      );
    }

    // Sort
    const sortVal = sortSelect ? sortSelect.value : 'reg-desc';
    list.sort((a, b) => {
      if (sortVal === 'reg-desc') {
        return new Date(b.registeredAt || 0).getTime() - new Date(a.registeredAt || 0).getTime();
      } else if (sortVal === 'reg-asc') {
        return new Date(a.registeredAt || 0).getTime() - new Date(b.registeredAt || 0).getTime();
      } else if (sortVal === 'login-desc') {
        return new Date(b.lastLogin || 0).getTime() - new Date(a.lastLogin || 0).getTime();
      } else if (sortVal === 'name-asc') {
        return (a.name || a.studentId || '').localeCompare(b.name || b.studentId || '');
      } else if (sortVal === 'quiz-desc') {
        return (b.quizAttemptsCount || 0) - (a.quizAttemptsCount || 0);
      }
      return 0;
    });

    return list;
  }

  function renderTable() {
    const students = getFilteredStudents();

    if (!students || students.length === 0) {
      let emptyMsg = 'No student records match the current filter or search.';
      if (currentFilter === 'device-lock') {
        emptyMsg = 'No students are currently bound to a single device hardware lock.';
      }
      tableBody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 3rem 1.5rem; color: var(--text-muted);">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">🔍</div>
            <div style="font-weight: 700; color: var(--text-main); font-size: 1rem;">${emptyMsg}</div>
            <div style="font-size: 0.85rem; margin-top: 0.25rem;">Try clearing your search query or switching tabs.</div>
          </td>
        </tr>
      `;
      return;
    }

    tableBody.innerHTML = students.map(s => {
      const initials = getInitials(s.name, s.studentId);
      const isPortalEnabled = s.accessStatus !== 'DENIED';
      const isQuizEnabled = s.quizAccessStatus !== 'DENIED';

      // Device badge
      let deviceBadgeHtml = '<span class="badge-status badge-unlocked">UNLOCKED</span>';
      if (s.isDeviceBlocked) {
        deviceBadgeHtml = '<span class="badge-status badge-blocked">BLOCKED (2ND DEVICE)</span>';
      } else if (s.activeDeviceToken) {
        deviceBadgeHtml = '<span class="badge-status badge-active-locked">LOCKED TO DEVICE</span>';
      }

      // Time strings
      const regExact = formatExactTime(s.registeredAt);
      const regRel = formatRelativeTime(s.registeredAt);

      const loginExact = s.lastLogin ? formatExactTime(s.lastLogin) : 'Never logged in';
      const loginRel = s.lastLogin ? formatRelativeTime(s.lastLogin) : 'No sessions recorded';

      // Quiz info
      const attemptsCount = s.quizAttemptsCount || 0;
      let quizTimeHtml = '';
      if (s.lastQuizAttemptAt) {
        quizTimeHtml = `
          <div style="font-size: 0.8rem; font-weight: 700; color: #0284c7;">
            ${s.lastQuizModule || 'Exam'} &bull; ${s.lastQuizScore !== null ? s.lastQuizScore + ' pts' : 'Completed'}
          </div>
          <div class="time-relative">${formatRelativeTime(s.lastQuizAttemptAt)}</div>
          <div style="font-size: 0.725rem; color: var(--text-muted); font-family: var(--font-mono);">${formatExactTime(s.lastQuizAttemptAt)}</div>
        `;
      } else if (attemptsCount > 0) {
        quizTimeHtml = `<div style="font-size: 0.8rem; color: var(--text-muted);">${attemptsCount} attempt(s) recorded</div>`;
      } else {
        quizTimeHtml = `<span style="font-size: 0.8rem; color: var(--text-muted);">No quiz attempts yet</span>`;
      }

      return `
        <tr>
          <!-- 1. Student Identity -->
          <td>
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <div class="student-avatar">${initials}</div>
              <div>
                <div style="font-weight: 800; color: var(--cips-navy); font-size: 0.95rem;">${s.name || s.studentId}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.4rem; margin-top: 1px;">
                  <span>${s.email}</span> &bull; 
                  <span style="font-family: var(--font-mono); font-size: 11px; background: #eef2ff; color: #4338ca; padding: 1px 5px; border-radius: 4px; font-weight: 700;">${s.studentId}</span>
                </div>
              </div>
            </div>
          </td>

          <!-- 2. Access Authorizations -->
          <td>
            <div style="display: flex; flex-direction: column; gap: 0.35rem; align-items: flex-start;">
              <span class="badge-status ${isPortalEnabled ? 'badge-active' : 'badge-blocked'}" style="font-size: 11px; padding: 2px 8px;">
                ${isPortalEnabled ? '🟢 PORTAL ENABLED' : '🔴 PORTAL DENIED'}
              </span>
              <span class="badge-status ${isQuizEnabled ? 'badge-quiz-allowed' : 'badge-quiz-denied'}" style="font-size: 11px; padding: 2px 8px;">
                ${isQuizEnabled ? '🔵 QUIZ ALLOWED' : '🟡 QUIZ DENIED'}
              </span>
            </div>
          </td>

          <!-- 3. Registration Time -->
          <td>
            <div class="time-badge">📅 ${regExact}</div>
            <div class="time-relative">${regRel}</div>
          </td>

          <!-- 4. Last Portal Login Time -->
          <td>
            <div class="time-badge">
              🔑 ${loginExact}
            </div>
            <div class="time-relative">${loginRel} &bull; ${s.loginCount || 0} login(s)</div>
          </td>

          <!-- 5. Device Status & Hardware Info -->
          <td>
            <div style="display: flex; flex-direction: column; gap: 0.25rem;">
              <div>${deviceBadgeHtml}</div>
              ${s.activeDeviceInfo ? `
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--text-main);">
                  💻 ${s.activeDeviceInfo}
                </div>
              ` : ''}
              ${s.activeDeviceToken ? `
                <div style="font-size: 0.725rem; font-family: var(--font-mono); color: var(--text-muted); word-break: break-all;">
                  Token: ${s.activeDeviceToken.substring(0, 18)}...
                </div>
              ` : '<div style="font-size: 0.75rem; color: var(--text-muted);">No hardware token bound</div>'}
            </div>
          </td>

          <!-- 6. Quiz Engine Activity & Times -->
          <td>
            ${quizTimeHtml}
          </td>

          <!-- 7. Actions -->
          <td style="text-align: right;">
            <div style="display: flex; gap: 0.4rem; justify-content: flex-end; flex-wrap: wrap;">
              <button type="button" class="btn btn-secondary btn-action-sm btn-view-timeline" data-email="${s.email}" title="View chronological activity & timestamp history">
                ⏱️ Timeline
              </button>
              ${s.activeDeviceToken || s.isDeviceBlocked ? `
                <button type="button" class="btn btn-secondary btn-action-sm btn-kpi-reset-device" data-email="${s.email}" title="Reset hardware device lock">
                  🔄 Reset Lock
                </button>
              ` : ''}
              <button type="button" class="btn btn-secondary btn-action-sm btn-kpi-toggle-portal" data-email="${s.email}" data-status="${isPortalEnabled ? 'DENIED' : 'ENABLED'}" title="Toggle portal LMS login">
                ${isPortalEnabled ? '🔒 Lock' : '🔓 Unlock'}
              </button>
              <a href="student-management.html" class="btn btn-secondary btn-action-sm" title="Edit credentials & modules in Student Management">
                ✏️ Edit
              </a>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    attachRowActionListeners();
  }

  function attachRowActionListeners() {
    // View Timeline Modal
    document.querySelectorAll('.btn-view-timeline').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const email = e.currentTarget.getAttribute('data-email');
        openStudentTimeline(email);
      });
    });

    // Reset Device
    document.querySelectorAll('.btn-kpi-reset-device').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const email = e.currentTarget.getAttribute('data-email');
        const student = allStudents.find(s => s.email.toLowerCase() === email.toLowerCase());
        if (!student) return;

        openConfirmationModal({
          title: 'Reset Hardware Device Lock',
          description: `Clear the hardware device lock token for ${student.name || student.email}.`,
          icon: '🔄',
          theme: 'amber',
          warningText: 'The student will be permitted to authenticate from a new computer or browser on their next login.',
          actionButtonText: 'Confirm Device Reset',
          student: student,
          onConfirm: async () => {
            await apiConfig.approveDeviceLock(student.email, null);
            showToast(`Hardware device lock cleared for ${student.email}`, 'success');
            await loadData();
          }
        });
      });
    });

    // Toggle Portal Access
    document.querySelectorAll('.btn-kpi-toggle-portal').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const email = e.currentTarget.getAttribute('data-email');
        const nextStatus = e.currentTarget.getAttribute('data-status');
        const student = allStudents.find(s => s.email.toLowerCase() === email.toLowerCase());
        if (!student) return;

        const isLocking = nextStatus === 'DENIED';
        openConfirmationModal({
          title: isLocking ? 'Revoke Portal LMS Access' : 'Grant Portal LMS Access',
          description: `Change portal login authorization for ${student.name || student.email}.`,
          icon: isLocking ? '🔒' : '🔓',
          theme: isLocking ? 'red' : 'green',
          warningText: isLocking 
            ? 'The student will immediately be locked out from accessing study modules and taking exams.'
            : 'The student will be allowed to log into the LMS portal normally.',
          actionButtonText: isLocking ? 'Revoke Portal Access' : 'Enable Portal Access',
          student: student,
          onConfirm: async () => {
            await apiConfig.toggleStudentAccess(student.email, nextStatus);
            showToast(`Portal access ${nextStatus} for ${student.email}`, isLocking ? 'danger' : 'success');
            await loadData();
          }
        });
      });
    });
  }

  // Chronological Activity Timeline Modal
  function openStudentTimeline(email) {
    const student = allStudents.find(s => s.email.toLowerCase() === email.toLowerCase());
    if (!student || !timelineModal) return;

    if (tlModalAvatar) tlModalAvatar.textContent = getInitials(student.name, student.studentId);
    if (tlModalName) tlModalName.textContent = student.name || student.studentId;
    if (tlModalEmail) tlModalEmail.textContent = `${student.email} • ID: ${student.studentId}`;

    // Collect all chronological events
    const events = [];

    // 1. Registration Event
    if (student.registeredAt) {
      events.push({
        type: 'registered',
        title: 'Account Registration Created',
        time: student.registeredAt,
        details: `Student account created with User ID: ${student.studentId}. Assigned initial qualification permissions.`,
        statusClass: 'success'
      });
    }

    // 2. Last Login Event
    if (student.lastLogin) {
      events.push({
        type: 'login',
        title: 'Portal LMS Authentication Session',
        time: student.lastLogin,
        details: `Logged into Student Portal. Device detected: ${student.activeDeviceInfo || 'Standard browser'}. Total lifetime logins: ${student.loginCount || 1}.`,
        statusClass: 'success'
      });
    }

    // 3. Device Binding
    if (student.activeDeviceToken) {
      events.push({
        type: 'device',
        title: 'Hardware Device Lock Enforced',
        time: student.lastLogin || student.registeredAt,
        details: `Bound to hardware token (${student.activeDeviceToken}). Single-device policy active. Device: ${student.activeDeviceInfo || 'Detected Client'}.`,
        statusClass: 'warning'
      });
    }

    // 4. Quiz Attempt Events
    const studentQuizzes = allQuizResults.filter(
      q => q.studentEmail && q.studentEmail.toLowerCase() === student.email.toLowerCase()
    );
    studentQuizzes.forEach(q => {
      const scorePct = q.totalQuestions ? Math.round((q.score / q.totalQuestions) * 100) : 0;
      events.push({
        type: 'quiz',
        title: `Exam Submission: ${q.moduleCode}`,
        time: q.timestamp || student.registeredAt,
        details: `Completed ${q.moduleCode} assessment. Score: ${q.score}/${q.totalQuestions || 20} (${scorePct}%). Result: ${q.passed ? 'PASSED' : 'NOT PASSED'}. Duration: ${q.durationSeconds ? Math.floor(q.durationSeconds / 60) + 'm ' + (q.durationSeconds % 60) + 's' : 'Standard'}.`,
        statusClass: q.passed ? 'success' : 'danger'
      });
    });

    // Sort descending by time
    events.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());

    if (events.length === 0) {
      tlEventsContainer.innerHTML = '<div style="color: var(--text-muted); font-size: 0.85rem;">No activity timestamps recorded yet.</div>';
    } else {
      tlEventsContainer.innerHTML = events.map(ev => `
        <div class="timeline-item">
          <div class="timeline-dot ${ev.statusClass}"></div>
          <div class="timeline-content">
            <div class="timeline-title">
              <span>${ev.title}</span>
              <span class="timeline-time">${formatRelativeTime(ev.time)}</span>
            </div>
            <div style="font-size: 0.75rem; font-family: var(--font-mono); color: var(--text-muted); margin-bottom: 0.35rem;">
              ${formatExactTime(ev.time)}
            </div>
            <div style="font-size: 0.825rem; color: var(--text-main); line-height: 1.45;">
              ${ev.details}
            </div>
          </div>
        </div>
      `).join('');
    }

    timelineModal.classList.add('active');
  }

  function closeTimelineModal() {
    if (timelineModal) timelineModal.classList.remove('active');
  }

  if (btnCloseTimeline) btnCloseTimeline.addEventListener('click', closeTimelineModal);
  if (btnCloseTimelineBottom) btnCloseTimelineBottom.addEventListener('click', closeTimelineModal);
  if (timelineModal) {
    timelineModal.addEventListener('click', (e) => {
      if (e.target === timelineModal) closeTimelineModal();
    });
  }

  // Confirmation Modal
  function openConfirmationModal(config) {
    if (!confirmModal) return;
    const { title, description, icon, theme, warningText, actionButtonText, student, onConfirm } = config;

    if (confirmModalTitle) confirmModalTitle.textContent = title;
    if (confirmModalDesc) confirmModalDesc.textContent = description;
    if (confirmModalIcon) confirmModalIcon.textContent = icon || '⚠️';

    if (student) {
      if (confirmStudentAvatar) confirmStudentAvatar.textContent = getInitials(student.name, student.studentId);
      if (confirmStudentName) confirmStudentName.textContent = student.name || student.studentId;
      if (confirmStudentEmail) confirmStudentEmail.textContent = student.email;
      if (confirmStudentId) confirmStudentId.textContent = student.studentId;
    }

    if (confirmWarningCallout && confirmWarningText) {
      confirmWarningText.textContent = warningText;
      confirmWarningCallout.className = `confirm-warning-box theme-${theme || 'amber'}`;
    }

    if (btnExecuteAction) {
      btnExecuteAction.textContent = actionButtonText || 'Confirm';
      btnExecuteAction.className = `btn confirm-action-btn theme-${theme || 'amber'}`;
    }

    pendingActionCallback = onConfirm;
    confirmModal.classList.add('active');
  }

  function closeConfirmationModal() {
    if (confirmModal) confirmModal.classList.remove('active');
    pendingActionCallback = null;
  }

  if (btnCloseConfirmModal) btnCloseConfirmModal.addEventListener('click', closeConfirmationModal);
  if (btnCancelAction) btnCancelAction.addEventListener('click', closeConfirmationModal);
  if (btnExecuteAction) {
    btnExecuteAction.addEventListener('click', async () => {
      if (typeof pendingActionCallback === 'function') {
        const cb = pendingActionCallback;
        closeConfirmationModal();
        try {
          await cb();
        } catch (err) {
          showToast(err.message || 'Action failed', 'danger');
        }
      }
    });
  }

  // Tab Button Click Handlers
  tabButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const filter = btn.getAttribute('data-filter');
      currentFilter = filter;
      
      // Update browser URL without reloading
      const newUrl = `${window.location.pathname}?filter=${filter}`;
      window.history.pushState({ path: newUrl }, '', newUrl);

      updateTabStyles();
      renderTable();
    });
  });

  // Search & Sort Event Handlers
  if (searchInput) {
    searchInput.addEventListener('input', () => renderTable());
  }
  if (sortSelect) {
    sortSelect.addEventListener('change', () => renderTable());
  }
  if (btnRefresh) {
    btnRefresh.addEventListener('click', () => loadData());
  }

  // CSV Export
  if (btnExportCsv) {
    btnExportCsv.addEventListener('click', () => {
      const students = getFilteredStudents();
      if (!students || students.length === 0) {
        showToast('No student records to export', 'warning');
        return;
      }

      const headers = [
        'Student ID',
        'Student Name',
        'Email',
        'Portal Access',
        'Quiz Access',
        'Registration Date & Time',
        'Last Login Date & Time',
        'Login Count',
        'Device Status',
        'Hardware Device Token',
        'Hardware Device Info',
        'Quiz Attempts Count',
        'Latest Quiz Module',
        'Latest Quiz Timestamp'
      ];

      const rows = students.map(s => [
        `"${s.studentId || ''}"`,
        `"${s.name || ''}"`,
        `"${s.email || ''}"`,
        `"${s.accessStatus || 'ENABLED'}"`,
        `"${s.quizAccessStatus || 'ENABLED'}"`,
        `"${s.registeredAt ? new Date(s.registeredAt).toISOString() : ''}"`,
        `"${s.lastLogin ? new Date(s.lastLogin).toISOString() : 'Never'}"`,
        s.loginCount || 0,
        `"${s.deviceStatus || (s.activeDeviceToken ? 'LOCKED' : 'UNLOCKED')}"`,
        `"${s.activeDeviceToken || 'None'}"`,
        `"${s.activeDeviceInfo || 'None'}"`,
        s.quizAttemptsCount || 0,
        `"${s.lastQuizModule || 'N/A'}"`,
        `"${s.lastQuizAttemptAt ? new Date(s.lastQuizAttemptAt).toISOString() : 'N/A'}"`
      ]);

      const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', `CIPS_Students_${currentFilter}_${new Date().toISOString().slice(0,10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast(`Exported ${students.length} student records with timestamps to CSV`, 'success');
    });
  }

  // Admin Logout Button
  const adminLogoutBtn = document.getElementById('admin-logout-btn') || document.getElementById('btn-admin-logout');
  if (adminLogoutBtn) {
    adminLogoutBtn.addEventListener('click', () => {
      localStorage.removeItem('cips_admin_session');
      localStorage.removeItem('cips_admin_user');
      window.location.href = 'admin-login.html';
    });
  }

  // Keyboard escape
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeTimelineModal();
      closeConfirmationModal();
    }
  });

  // Initialize
  const adminUser = localStorage.getItem('cips_admin_user') || 'admincipsadmin';
  const adminLabel = document.getElementById('admin-user-label') || document.getElementById('admin-user-display');
  if (adminLabel) adminLabel.textContent = adminUser;

  initFilterFromUrl();
  await loadData();
});
